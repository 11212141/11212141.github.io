export function renderLiveStudio() {
  return document.createDocumentFragment();
}

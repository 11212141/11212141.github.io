import { el, sectionTitle } from "../utils/dom.js";

export function renderPhonicsGame({
  challenge,
  longShortState,
  longAState,
  freeBlendState,
  onChooseLongShort,
  onRevealLongShort,
  onNextLongShort,
  onResetLongShort,
  onSelectLongAPattern,
  onSetLongAPractice,
  onUpdateLongACustom,
  onNextLongAWord,
  onPreviousLongAWord,
  onSetFreeBlendLength,
  onSelectFreeBlendSlot,
  onChooseFreeBlendLetter,
  onClearFreeBlend,
}) {
  const section = el("section", { className: "panel", attrs: { id: "phonics-game" } });

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle("母音練習", ""),
      renderLongShortComparison({
        challenge: challenge.longShortComparison,
        state: longShortState,
        onChooseLongShort,
        onRevealLongShort,
        onNextLongShort,
        onResetLongShort,
      }),
      renderLongAWorkshop({
        challenge: challenge.longAWorkshop,
        state: longAState,
        onSelectLongAPattern,
        onSetLongAPractice,
        onUpdateLongACustom,
        onNextLongAWord,
        onPreviousLongAWord,
      }),
      renderFreeBlendGame({
        state: freeBlendState,
        onSetFreeBlendLength,
        onSelectFreeBlendSlot,
        onChooseFreeBlendLetter,
        onClearFreeBlend,
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderFreeBlendGame({
  state,
  onSetFreeBlendLength,
  onSelectFreeBlendSlot,
  onChooseFreeBlendLetter,
  onClearFreeBlend,
}) {
  const vowels = ["a", "e", "i", "o", "u"];
  const consonants = ["b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "v", "w", "y", "z"];
  const activeSlot = Math.min(state.activeSlot, state.length - 1);
  const activeLetters = activeSlot === 1 ? vowels : consonants;
  const word = state.letters.slice(0, state.length).join("");

  return el("section", {
    className: "phonics-extra-card phonics-extra-card--free-blend",
    attrs: { id: "phonics-free-blend" },
    children: [
      el("div", {
        className: "phonics-extra-head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: "自由拼音" }),
              el("h3", { text: "任二／任三字母練習發音" }),
            ],
          }),
          el("span", { className: "pill", text: "第 2 格一定是母音" }),
        ],
      }),
      el("div", {
        className: "phonics-free-blend-layout",
        children: [
          el("div", {
            className: "phonics-free-word-card",
            children: [
              el("div", {
                className: "phonics-free-word",
                children: state.letters.slice(0, state.length).map((letter, index) =>
                  el("button", {
                    className: `phonics-free-slot${index === activeSlot ? " is-active" : ""}${index === 1 ? " is-vowel" : ""}`,
                    attrs: { type: "button" },
                    on: { click: () => onSelectFreeBlendSlot(index) },
                    children: [
                      el("span", { text: index === 1 ? "母音" : `第 ${index + 1} 格` }),
                      el("strong", { text: letter }),
                    ],
                  }),
                ),
              }),
              el("p", {
                text: state.length === 2 ? `${word}：先念第 1 個字母，再接母音。` : `${word}：子音、母音、尾音一起念。`,
              }),
            ],
          }),
          el("div", {
            className: "phonics-free-controls",
            children: [
              el("div", {
                className: "phonics-pattern-tabs",
                children: [
                  { length: 2, label: "任二字母" },
                  { length: 3, label: "任三字母" },
                ].map((mode) =>
                  el("button", {
                    className: `button ${state.length === mode.length ? "button--primary" : "button--secondary"}`,
                    text: mode.label,
                    attrs: { type: "button" },
                    on: { click: () => onSetFreeBlendLength(mode.length) },
                  }),
                ),
              }),
              el("div", {
                className: "phonics-letter-bank",
                children: [
                  el("span", { text: activeSlot === 1 ? "選母音" : "選字母" }),
                  el("div", {
                    className: "phonics-letter-bank__grid",
                    children: activeLetters.map((letter) =>
                      el("button", {
                        className: `phonics-letter-tile${state.letters[activeSlot] === letter ? " is-active" : ""}`,
                        text: letter,
                        attrs: { type: "button" },
                        on: { click: () => onChooseFreeBlendLetter(letter) },
                      }),
                    ),
                  }),
                ],
              }),
              el("button", {
                className: "button button--secondary",
                text: "回到 bat",
                attrs: { type: "button" },
                on: { click: onClearFreeBlend },
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderLongShortComparison({
  challenge,
  state,
  onChooseLongShort,
  onRevealLongShort,
  onNextLongShort,
  onResetLongShort,
}) {
  const pair = challenge.pairs[state.index] ?? challenge.pairs[0];
  const choices = [
    { id: "short", label: "short", word: pair.shortWord, sound: pair.shortSound },
    { id: "long", label: "long", word: pair.longWord, sound: pair.longSound },
  ];

  return el("section", {
    className: "phonics-extra-card phonics-extra-card--compare",
    attrs: { id: "phonics-long-short" },
    children: [
      el("div", {
        className: "phonics-extra-head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: "長短音比較" }),
              el("h3", { text: challenge.title }),
            ],
          }),
          el("span", { className: "pill", text: `${state.index + 1} / ${challenge.pairs.length}` }),
        ],
      }),
      el("div", {
        className: "phonics-compare-stage",
        children: [
          renderCompareWordCard("short", pair.shortWord, pair.shortSound, state),
          el("div", {
            className: "phonics-vs",
            children: [el("strong", { text: pair.vowel }), el("span", { text: "VS" })],
          }),
          renderCompareWordCard("long", pair.longWord, pair.longSound, state),
        ],
      }),
      el("div", {
        className: "phonics-compare-actions",
        children: choices.map((choice) =>
          el("button", {
            className: getLongShortButtonClass(choice.id, state),
            text: choice.label,
            attrs: { type: "button", disabled: state.revealed ? "disabled" : null },
            on: { click: () => onChooseLongShort(choice.id) },
          }),
        ),
      }),
      state.selected
        ? el("div", {
            className: "phonics-teacher-reveal",
            children: [
              el("span", { text: "老師揭曉：" }),
              ...choices.map((choice) =>
                el("button", {
                  className: `button ${state.answer === choice.id ? "button--primary" : "button--secondary"}`,
                  text: `${choice.label} - ${choice.word}`,
                  attrs: { type: "button", disabled: state.revealed ? "disabled" : null },
                  on: { click: () => onRevealLongShort(choice.id) },
                }),
              ),
            ],
          })
        : null,
      renderLongShortFeedback(pair, state),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "重選",
            attrs: { type: "button" },
            on: { click: onResetLongShort },
          }),
          el("button", {
            className: "button button--primary",
            text: "下一組",
            attrs: { type: "button" },
            on: { click: onNextLongShort },
          }),
        ],
      }),
    ],
  });
}

function renderCompareWordCard(type, word, sound, state) {
  const isAnswer = state.revealed && state.answer === type;
  const isPicked = state.selected === type;

  return el("article", {
    className: `phonics-compare-word phonics-compare-word--${type}${isPicked ? " is-picked" : ""}${isAnswer ? " is-answer" : ""}`,
    children: [
      el("span", { text: type }),
      el("strong", { text: word }),
      el("p", { text: sound }),
    ],
  });
}

function renderLongShortFeedback(pair, state) {
  if (!state.selected) {
    return el("p", { className: "phonics-feedback phonics-feedback--info", text: "老師念其中一個單字，學生先選 short 或 long。" });
  }

  if (!state.revealed) {
    return el("p", { className: "phonics-feedback phonics-feedback--info", text: `學生選了 ${state.selected}，接著請老師點剛剛念的是哪一個。` });
  }

  const answerWord = state.answer === "short" ? pair.shortWord : pair.longWord;
  const correct = state.selected === state.answer;

  return el("p", {
    className: `phonics-feedback ${correct ? "is-success" : "is-retry"}`,
    text: correct ? `答對了，是 ${state.answer} sound in ${answerWord}。` : `這次是 ${state.answer} sound in ${answerWord}。`,
  });
}

function getLongShortButtonClass(choiceId, state) {
  let className = "phonics-long-short-button";

  if (state.selected === choiceId) {
    className += " is-selected";
  }

  if (state.revealed && state.answer === choiceId) {
    className += " is-correct";
  }

  if (state.revealed && state.selected === choiceId && state.answer !== choiceId) {
    className += " is-wrong";
  }

  return className;
}

function renderLongAWorkshop({
  challenge,
  state,
  onSelectLongAPattern,
  onSetLongAPractice,
  onUpdateLongACustom,
  onNextLongAWord,
  onPreviousLongAWord,
}) {
  const activePattern = challenge.patterns.find((pattern) => pattern.id === state.patternId) ?? challenge.patterns[0];
  const practiceMode = state.practiceMode ?? "front";
  const activeWords = activePattern.practice?.[practiceMode] ?? activePattern.words;
  const indexKey = `${activePattern.id}-${practiceMode}`;
  const word = activeWords[state.wordIndexes[indexKey] ?? 0] ?? activeWords[0];
  const customParts = state.customLetters?.[activePattern.id] ?? getDefaultLongAParts(activePattern, word);
  const displayWord = buildLongAWord(activePattern, customParts);
  const practiceLabel = practiceMode === "front" ? "換前面字母" : "換中間字母";
  const activeFamily = getLongVowelFamily(activePattern.sound);
  const soundFamily = activeFamily.badge;
  const familyIcon = activeFamily.letter;

  return el("section", {
    className: "phonics-extra-card phonics-extra-card--long-a",
    attrs: { id: "phonics-long-vowel" },
    children: [
      el("div", {
        className: "phonics-extra-head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: soundFamily }),
              el("h3", { text: challenge.title }),
            ],
          }),
          el("span", { className: "pill", text: `${activePattern.label}｜${activePattern.position}` }),
        ],
      }),
      renderLongVowelFamilyBoard(challenge.patterns, activePattern, onSelectLongAPattern),
      el("div", {
        className: "phonics-pattern-tabs phonics-practice-tabs",
        children: [
          { id: "front", label: "換前面字母" },
          { id: "middle", label: "換中間字母" },
        ].map((mode) =>
          el("button", {
            className: `button ${practiceMode === mode.id ? "button--primary" : "button--secondary"}`,
            text: mode.label,
            attrs: { type: "button" },
            on: { click: () => onSetLongAPractice(mode.id) },
          }),
        ),
      }),
      el("div", {
        className: "phonics-long-a-stage",
        children: [
          el("div", {
            className: "phonics-long-a-showcase",
            children: [
              el("span", { className: "phonics-vowel-orb", text: familyIcon }),
              el("div", {
                className: "phonics-long-a-word",
                children: renderLongAWord(displayWord, activePattern.label),
              }),
              renderLongVowelWordRail(activeWords, word, activePattern),
            ],
          }),
          el("div", {
            className: "phonics-long-a-detail",
            children: [
              el("span", { className: "badge badge--live", text: activePattern.sound }),
              el("strong", { text: activePattern.hint }),
              el("div", {
                className: "phonics-pattern-example",
                children: [
                  el("span", { text: "例字" }),
                  ...activePattern.words.slice(0, 4).map((example) => el("strong", { text: example })),
                ],
              }),
              el("div", {
                className: "phonics-sound-steps",
                children: [
                  el("span", { text: "1 看組合" }),
                  el("span", { text: "2 念長音" }),
                  el("span", { text: "3 合成單字" }),
                ],
              }),
              el("p", { text: `${practiceLabel}：換一格，再一起念出整個單字。` }),
            ],
          }),
        ],
      }),
      renderLongACustomBuilder(activePattern, customParts, onUpdateLongACustom),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "上一個字",
            attrs: { type: "button" },
            on: { click: onPreviousLongAWord },
          }),
          el("button", {
            className: "button button--primary",
            text: "換下一個字",
            attrs: { type: "button" },
            on: { click: onNextLongAWord },
          }),
        ],
      }),
    ],
  });
}

function renderLongVowelFamilyBoard(patterns, activePattern, onSelectLongAPattern) {
  const familyOrder = ["long a", "long e", "long i", "long o", "long u", "long oo", "short oo"];
  const families = familyOrder
    .filter((id) => patterns.some((pattern) => pattern.sound === id))
    .map((id) => getLongVowelFamily(id));

  return el("div", {
    className: "phonics-vowel-family-grid",
    children: families.map((family) =>
      el("article", {
        className: `phonics-vowel-family-card phonics-vowel-family-card--${family.tone}${activePattern.sound === family.id ? " is-active" : ""}`,
        children: [
          el("div", {
            className: "phonics-vowel-family-card__head",
            children: [
              el("strong", { text: family.label }),
              el("span", { text: family.hint }),
            ],
          }),
          el("div", {
            className: "phonics-vowel-chip-row",
            children: patterns
              .filter((pattern) => pattern.sound === family.id)
              .map((pattern) =>
                el("button", {
                  className: `phonics-vowel-chip${pattern.id === activePattern.id ? " is-active" : ""}`,
                  text: pattern.label,
                  attrs: { type: "button" },
                  on: { click: () => onSelectLongAPattern(pattern.id) },
                }),
              ),
          }),
        ],
      }),
    ),
  });
}

function getLongVowelFamily(sound) {
  const families = {
    "long a": { id: "long a", label: "長 A", badge: "長 a 音", hint: "像字母 A 的名字", tone: "a", letter: "A" },
    "long e": { id: "long e", label: "長 E", badge: "長 e 音", hint: "像字母 E 的名字", tone: "e", letter: "E" },
    "long i": { id: "long i", label: "長 I", badge: "長 i 音", hint: "像字母 I 的名字", tone: "i", letter: "I" },
    "long o": { id: "long o", label: "長 O", badge: "長 o 音", hint: "像字母 O 的名字", tone: "o", letter: "O" },
    "long u": { id: "long u", label: "長 U", badge: "長 u 音", hint: "像字母 U 的名字", tone: "u", letter: "U" },
    "long oo": { id: "long oo", label: "長 OO", badge: "long oo", hint: "像 moon / food", tone: "oo-long", letter: "OO" },
    "short oo": { id: "short oo", label: "短 OO", badge: "short oo", hint: "像 book / foot", tone: "oo-short", letter: "OO" },
  };

  return families[sound] ?? families["long a"];
}

function renderLongVowelWordRail(words, activeWord, pattern) {
  return el("div", {
    className: "phonics-word-rail",
    children: words.slice(0, 8).map((item) =>
      el("span", {
        className: item === activeWord ? "is-active" : "",
        children: renderLongAWord(item, pattern.label),
      }),
    ),
  });
}

function renderLongACustomBuilder(pattern, parts, onUpdateLongACustom) {
  const isSplitPattern = isSplitVowelPattern(pattern.label);
  const fields =
    isSplitPattern
      ? [
          { key: "before", label: "前面字母" },
          { key: "middle", label: "中間字母" },
          { key: "after", label: "後面字母" },
        ]
      : [
          { key: "before", label: "前面字母" },
          { key: "after", label: "後面字母" },
        ];

  return el("div", {
    className: "phonics-letter-builder",
    children: [
      el("div", {
        className: "phonics-letter-builder__head",
        children: [
          el("strong", { text: "自由替換字母" }),
          el("span", { className: "pill", text: pattern.label }),
        ],
      }),
      el("div", {
        className: "phonics-letter-builder__row",
        children: fields.map((field) =>
          el("label", {
            className: "phonics-letter-field",
            children: [
              el("span", { text: field.label }),
              el("input", {
                dataset: { field: field.key },
                attrs: {
                  type: "text",
                  value: parts[field.key] ?? "",
                  maxlength: "5",
                  inputmode: "latin",
                  autocomplete: "off",
                  spellcheck: "false",
                },
                on: {
                  input: (event) => {
                    onUpdateLongACustom(pattern.id, field.key, event.target.value);
                    updateLongVowelPreview(event.currentTarget, pattern);
                  },
                },
              }),
            ],
          }),
        ),
      }),
    ],
  });
}

function updateLongVowelPreview(input, pattern) {
  const card = input.closest(".phonics-extra-card--long-a");
  if (!card) return;

  const values = { before: "", middle: "", after: "" };
  card.querySelectorAll(".phonics-letter-field input").forEach((fieldInput) => {
    values[fieldInput.dataset.field] = fieldInput.value.replace(/[^a-z]/gi, "").toLowerCase();
  });

  const preview = card.querySelector(".phonics-long-a-word");
  if (!preview) return;
  preview.replaceChildren(...renderLongAWord(buildLongAWord(pattern, values), pattern.label));
}

function buildLongAWord(pattern, parts) {
  if (isSplitVowelPattern(pattern.label)) {
    const [firstLetter, lastLetter] = pattern.label.split("_");
    return `${parts.before ?? ""}${firstLetter}${parts.middle ?? ""}${lastLetter}${parts.after ?? ""}`;
  }

  return `${parts.before ?? ""}${pattern.label}${parts.after ?? ""}`;
}

function getDefaultLongAParts(pattern, word) {
  if (isSplitVowelPattern(pattern.label)) {
    const [firstLetter, lastLetter] = pattern.label.split("_");
    const firstIndex = word.toLowerCase().indexOf(firstLetter);
    const lastIndex = word.toLowerCase().lastIndexOf(lastLetter);

    if (firstIndex === -1 || lastIndex === -1 || lastIndex <= firstIndex) {
      return { before: "", middle: "", after: "" };
    }

    return {
      before: word.slice(0, firstIndex),
      middle: word.slice(firstIndex + 1, lastIndex),
      after: word.slice(lastIndex + 1),
    };
  }

  const patternIndex = word.toLowerCase().indexOf(pattern.label);

  if (patternIndex === -1) {
    return { before: "", middle: "", after: "" };
  }

  return {
    before: word.slice(0, patternIndex),
    middle: "",
    after: word.slice(patternIndex + pattern.label.length),
  };
}

function renderLongAWord(word, patternLabel) {
  if (isSplitVowelPattern(patternLabel)) {
    const [firstLetter, lastLetter] = patternLabel.split("_");
    const lowerWord = word.toLowerCase();
    const firstIndex = lowerWord.indexOf(firstLetter);
    const lastIndex = lowerWord.lastIndexOf(lastLetter);

    return word.split("").map((letter, index) =>
      el("span", {
        className: index === firstIndex || index === lastIndex ? "is-long-a" : "",
        text: letter,
      }),
    );
  }

  const patternIndex = word.toLowerCase().indexOf(patternLabel);

  if (patternIndex === -1) {
    return [el("span", { text: word })];
  }

  const parts = [
    word.slice(0, patternIndex),
    patternLabel,
    word.slice(patternIndex + patternLabel.length),
  ];

  return parts.filter(Boolean).map((part) =>
    el("span", {
      className: part.toLowerCase() === patternLabel ? "is-long-a" : "",
      text: part,
    }),
  );
}

function isSplitVowelPattern(patternLabel) {
  return patternLabel.includes("_");
}

function renderPlayerBoard(gameState, currentRound, onSelectPlayer) {
  const lockBoard = Boolean(gameState.selectedChoiceId || gameState.isAnswered);

  return el("div", {
    className: "phonics-player-board",
    children: [
      el("div", {
        className: "phonics-board-head",
        children: [
          el("strong", { text: "四位學生輪流區" }),
          el("span", { className: "pill", text: `第 ${Math.min(gameState.roundIndex + 1, gameState.totalRounds)} 題` }),
        ],
      }),
      el("div", {
        className: "phonics-round-badge",
        children: [
          el("span", { className: "badge badge--warm", text: currentRound.modeLabel }),
          el("strong", { text: currentRound.title }),
          el("p", { text: currentRound.tip }),
        ],
      }),
      el("div", {
        className: "phonics-player-list",
        children: gameState.players.map((player, index) =>
          el("button", {
            className: `phonics-player-card${index === gameState.activePlayerIndex ? " is-active" : ""}`,
            attrs: {
              type: "button",
              disabled: lockBoard ? "disabled" : null,
            },
            on: {
              click: () => onSelectPlayer(index),
            },
            children: [
              el("div", {
                className: "phonics-player-meta",
                children: [
                  el("strong", { text: player.name }),
                  el("span", {
                    text:
                      index === gameState.activePlayerIndex
                        ? "本題作答"
                        : gameState.lastResult?.playerId === player.id
                          ? "上一題作答"
                          : "等待中",
                  }),
                ],
              }),
              el("span", { className: "phonics-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderRoundStage({
  challenge,
  gameState,
  currentRound,
  activePlayer,
  selectedChoice,
  revealedChoice,
  onChooseOption,
  onRevealAnswer,
  onResetSelection,
  onNextRound,
  onResetGame,
}) {
  return el("div", {
    className: "phonics-stage",
    attrs: { style: `--round-accent:${currentRound.accent};` },
    children: [
      el("div", {
        className: "phonics-stage__header",
        children: [
          el("div", {
            className: "phonics-stage__headline",
            children: [
              el("span", { className: "badge badge--live", text: `輪到 ${activePlayer.name}` }),
              el("h3", { text: currentRound.title }),
              el("p", { text: currentRound.prompt }),
            ],
          }),
          el("div", {
            className: "button-row",
            children: [
              el("button", {
                className: "button button--ghost",
                text: "重新開始",
                attrs: { type: "button" },
                on: { click: onResetGame },
              }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "phonics-mission-grid",
        children: [
          renderMissionCard({
            title: "本題玩法",
            badge: currentRound.modeLabel,
            body: currentRound.prompt,
            footer: currentRound.tip,
          }),
          renderListenCard(currentRound),
          renderStatusCard({
            selectedChoice,
            revealedChoice,
            isAnswered: gameState.isAnswered,
            activePlayer,
          }),
        ],
      }),
      el("div", {
        className: "phonics-choice-grid",
        children: challenge.answerChoices.map((choice) =>
          renderChoiceButton({
            choice,
            gameState,
            revealedChoiceId: revealedChoice?.id ?? "",
            onChooseOption,
          }),
        ),
      }),
      renderRevealPanel({
        challenge,
        gameState,
        selectedChoice,
        revealedChoice,
        onRevealAnswer,
      }),
      renderFeedback({
        gameState,
        selectedChoice,
        revealedChoice,
        activePlayer,
      }),
      el("div", {
        className: "phonics-actions",
        children: [
          !gameState.isAnswered && selectedChoice
            ? el("button", {
                className: "button button--secondary",
                text: "重選學生答案",
                attrs: { type: "button" },
                on: { click: onResetSelection },
              })
            : null,
          gameState.isAnswered
            ? el("button", {
                className: "button button--primary",
                text: gameState.roundIndex === gameState.totalRounds - 1 ? "看結果" : "下一題",
                attrs: { type: "button" },
                on: { click: onNextRound },
              })
            : null,
        ],
      }),
    ],
  });
}

function renderMissionCard({ title, badge, body, footer }) {
  return el("article", {
    className: "phonics-mission-card phonics-mission-card--accent",
    children: [
      el("div", {
        className: "phonics-mission-card__head",
        children: [
          el("strong", { text: title }),
          el("span", { className: "pill", text: badge }),
        ],
      }),
      el("p", { text: body }),
      el("span", { className: "phonics-mission-card__note", text: footer }),
    ],
  });
}

function renderListenCard(round) {
  return el("article", {
    className: "phonics-mission-card",
    children: [
      el("div", {
        className: "phonics-mission-card__head",
        children: [el("strong", { text: "聽音任務" })],
      }),
      el("div", {
        className: "phonics-wave",
        children: Array.from({ length: 5 }, (_, index) =>
          el("span", {
            attrs: { style: `--wave-delay:${index * 0.12}s;` },
          }),
        ),
      }),
      el("div", {
        className: "phonics-beat-row",
        children: round.beats.map((beat) =>
          el("span", {
            className: "phonics-beat",
            text: beat,
          }),
        ),
      }),
    ],
  });
}

function renderStatusCard({ selectedChoice, revealedChoice, isAnswered, activePlayer }) {
  if (!selectedChoice) {
    return el("article", {
      className: "phonics-mission-card phonics-status-card",
      children: [
        el("strong", { text: "作答狀態" }),
        el("p", { text: `${activePlayer.name} 準備中，先聽老師念，再選一張聲音卡。` }),
      ],
    });
  }

  if (!isAnswered) {
    return el("article", {
      className: "phonics-mission-card phonics-status-card",
      children: [
        el("strong", { text: "學生已作答" }),
        renderChoicePreview(selectedChoice, "學生目前選了"),
        el("p", { text: "接下來請老師點剛剛真正念到的短母音。" }),
      ],
    });
  }

  return el("article", {
    className: "phonics-mission-card phonics-status-card",
    children: [
      el("strong", { text: "答案揭曉" }),
      renderChoicePreview(revealedChoice, "老師剛剛念的是"),
      el("p", { text: `${revealedChoice.label} ${revealedChoice.sound} in ${revealedChoice.word}` }),
    ],
  });
}

function renderChoiceButton({ choice, gameState, revealedChoiceId, onChooseOption }) {
  const isSelected = gameState.selectedChoiceId === choice.id;
  const isCorrect = gameState.isAnswered && revealedChoiceId === choice.id;
  const isWrong = gameState.isAnswered && isSelected && revealedChoiceId !== choice.id;

  let className = "phonics-choice";

  if (isSelected && !gameState.isAnswered) {
    className += " is-active";
  }

  if (isCorrect) {
    className += " is-correct";
  } else if (isWrong) {
    className += " is-wrong";
  }

  return el("button", {
    className,
    attrs: {
      type: "button",
      disabled: gameState.isAnswered ? "disabled" : null,
      style: `--swatch:${choice.swatch};`,
    },
    on: {
      click: () => onChooseOption(choice.id),
    },
    children: [
      el("span", { className: "phonics-choice__letter", text: choice.letter }),
      el("strong", { text: choice.label }),
      el("span", { className: "phonics-choice__sound", text: choice.sound }),
      el("p", { text: choice.word }),
    ],
  });
}

function renderRevealPanel({ challenge, gameState, selectedChoice, revealedChoice, onRevealAnswer }) {
  if (!selectedChoice) {
    return null;
  }

  return el("article", {
    className: "phonics-reveal-card",
    children: [
      el("div", {
        className: "phonics-reveal-card__head",
        children: [
          el("strong", { text: "老師揭曉答案" }),
          el("span", {
            className: "pill",
            text: gameState.isAnswered ? "已揭曉" : "請點正確短母音",
          }),
        ],
      }),
      el("p", {
        text: gameState.isAnswered
          ? "這一題的正確短母音已經公布。"
          : "學生選好之後，請老師點剛剛真正念到的短母音。",
      }),
      el("div", {
        className: "phonics-reveal-grid",
        children: challenge.answerChoices.map((choice) =>
          renderRevealButton({
            choice,
            gameState,
            revealedChoice,
            onRevealAnswer,
          }),
        ),
      }),
    ],
  });
}

function renderRevealButton({ choice, gameState, revealedChoice, onRevealAnswer }) {
  const isSelected = revealedChoice?.id === choice.id;

  return el("button", {
    className: `phonics-reveal-button${isSelected ? " is-active" : ""}`,
    attrs: {
      type: "button",
      disabled: gameState.isAnswered ? "disabled" : null,
      style: `--swatch:${choice.swatch};`,
    },
    on: {
      click: () => onRevealAnswer(choice.id),
    },
    children: [
      el("span", { className: "phonics-choice__letter", text: choice.letter }),
      el("strong", { text: choice.label }),
      el("span", { className: "phonics-choice__sound", text: choice.sound }),
    ],
  });
}

function renderFeedback({ gameState, selectedChoice, revealedChoice, activePlayer }) {
  if (!selectedChoice) {
    return el("div", {
      className: "phonics-feedback",
      children: [el("p", { text: `${activePlayer.name} 聽完後，請選一張聲音卡。` })],
    });
  }

  if (!gameState.isAnswered || !revealedChoice) {
    return el("div", {
      className: "phonics-feedback phonics-feedback--info",
      children: [
        el("strong", { text: "學生已選好" }),
        el("p", { text: `${activePlayer.name} 選了 ${selectedChoice.label}，現在請老師揭曉正確答案。` }),
      ],
    });
  }

  if (gameState.lastResult?.isCorrect) {
    return el("div", {
      className: "phonics-feedback is-success",
      children: [
        el("strong", { text: "答對了" }),
        el("p", { text: `這題是 ${revealedChoice.label} ${revealedChoice.sound} in ${revealedChoice.word}。` }),
      ],
    });
  }

  return el("div", {
    className: "phonics-feedback is-retry",
    children: [
      el("strong", { text: "這題揭曉了" }),
      el("p", {
        text: `${activePlayer.name} 選的是 ${selectedChoice.label}，正確答案是 ${revealedChoice.label} ${revealedChoice.sound} in ${revealedChoice.word}。`,
      }),
    ],
  });
}

function renderFinishedState(gameState, onResetGame) {
  const winner = [...gameState.players].sort((left, right) => right.score - left.score)[0];

  return el("div", {
    className: "phonics-stage",
    children: [
      el("div", {
        className: "phonics-finish-card",
        children: [
          el("span", { className: "badge badge--warm", text: "挑戰完成" }),
          el("h3", { text: "聽短母音闖關完成了" }),
          el("p", { text: `${winner.name} 目前 ${winner.score} 分` }),
        ],
      }),
      el("div", {
        className: "phonics-result-grid",
        children: gameState.players.map((player) =>
          el("div", {
            className: "phonics-result-card",
            children: [
              el("strong", { text: player.name }),
              el("span", { className: "phonics-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--primary",
            text: "再玩一次",
            attrs: { type: "button" },
            on: { click: onResetGame },
          }),
        ],
      }),
    ],
  });
}

function renderChoicePreview(choice, prefix) {
  return el("div", {
    className: "phonics-picked-card",
    attrs: { style: `--swatch:${choice.swatch};` },
    children: [
      el("span", { text: prefix }),
      el("strong", { text: choice.label }),
      el("p", { text: `${choice.sound} in ${choice.word}` }),
    ],
  });
}

function findChoice(challenge, choiceId) {
  return challenge.answerChoices.find((choice) => choice.id === choiceId) ?? null;
}

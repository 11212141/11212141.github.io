import { el, sectionTitle } from "../utils/dom.js";

export function renderMathConceptGame({ challenge, state, onSetMode, onChooseAnswer, onNextRound }) {
  const activeMode = challenge.modes.find((mode) => mode.id === state.mode) ?? challenge.modes[0];
  const roundIndex = state.roundIndexes[activeMode.id] ?? 0;
  const round = activeMode.rounds[roundIndex];
  const selected = state.selectedAnswers[activeMode.id] ?? "";
  const result = state.results[activeMode.id] ?? null;

  const section = el("section", { className: "panel", attrs: { id: "math-concept-game" } });
  section.append(
    el("div", {
      className: "panel__content",
      children: [
        sectionTitle(challenge.title, "", el("span", { className: "badge badge--live", text: challenge.badge })),
        challenge.modes.length > 1 ? renderModeTabs(challenge.modes, activeMode.id, onSetMode) : null,
        renderConceptCard(activeMode),
        activeMode.detailCards ? renderDetailCards(activeMode.detailCards) : null,
        renderRoundCard({
          mode: activeMode,
          round,
          index: roundIndex,
          total: activeMode.rounds.length,
          selected,
          result,
          onChooseAnswer,
          onNextRound,
        }),
      ],
    }),
  );

  return section;
}

function renderDetailCards(cards) {
  return el("div", {
    className: "math-concept-detail-grid",
    children: cards.map((card) =>
      el("div", {
        className: "math-concept-detail-card",
        children: [
          el("span", { text: card.kicker }),
          el("strong", { text: card.title }),
          el("p", { text: card.text }),
        ],
      }),
    ),
  });
}

function renderModeTabs(modes, activeModeId, onSetMode) {
  return el("div", {
    className: "decimal-mode-switch math-concept-tabs",
    children: modes.map((mode) =>
      el("button", {
        className: `button ${activeModeId === mode.id ? "button--primary" : "button--secondary"}`,
        text: mode.label,
        attrs: { type: "button" },
        on: { click: () => onSetMode(mode.id) },
      }),
    ),
  });
}

function renderConceptCard(mode) {
  return el("div", {
    className: "math-concept-strip",
    children: [
      el("span", { className: "badge badge--warm", text: mode.label }),
      el("strong", { text: mode.concept }),
    ],
  });
}

function renderRoundCard({ mode, round, index, total, selected, result, onChooseAnswer, onNextRound }) {
  return el("article", {
    className: "math-concept-card",
    children: [
      el("div", {
        className: "math-concept-card__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: `第 ${index + 1} / ${total} 題` }),
              el("h3", { text: mode.label }),
            ],
          }),
        ],
      }),
      el("div", {
        className: `math-concept-prompt math-concept-prompt--${mode.id}`,
        children: [
          el("strong", { text: round.prompt }),
          round.subPrompt ? el("span", { text: round.subPrompt }) : null,
        ],
      }),
      el("div", {
        className: "math-concept-options",
        children: round.options.map((option) =>
          el("button", {
            className: getOptionClass(option, round.answer, selected, result),
            text: option,
            attrs: { type: "button", disabled: result ? "disabled" : null },
            on: { click: () => onChooseAnswer(option) },
          }),
        ),
      }),
      renderFeedback(result, round.answer),
      el("div", {
        className: "number-game-actions",
        children: [
          el("button", {
            className: "button button--primary",
            text: index === total - 1 ? "回到第一題" : "下一題",
            attrs: { type: "button", disabled: result ? null : "disabled" },
            on: { click: onNextRound },
          }),
        ],
      }),
    ],
  });
}

function renderFeedback(result, answer) {
  if (!result) {
    return el("p", { className: "decimal-feedback", text: "選一個答案。" });
  }

  return el("p", {
    className: `decimal-feedback ${result.isCorrect ? "is-correct" : "is-wrong"}`,
    text: result.isCorrect ? "答對了。" : `再想想，答案是 ${answer}。`,
  });
}

function getOptionClass(option, answer, selected, result) {
  const isSelected = option === selected;
  const isCorrect = result && option === answer;
  const isWrong = result && isSelected && option !== answer;
  return `math-concept-option${isSelected ? " is-selected" : ""}${isCorrect ? " is-correct" : ""}${isWrong ? " is-wrong" : ""}`;
}

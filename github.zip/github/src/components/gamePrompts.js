import { el, sectionTitle } from "../utils/dom.js";

export function renderGamePrompts({ decks, activeMode }) {
  const section = el("section", { className: "panel", attrs: { id: "cards" } });

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(
        "自我介紹遊戲題卡",
        "挑 2 到 3 張就能完成今天的認識彼此活動；孩子比較安靜時用安心版，氣氛熱起來時切到接龍版。",
        el("span", { className: "badge badge--warm", text: activeMode.label }),
      ),
      el("div", {
        className: "prompt-grid",
        children: decks.map((deck) => renderPromptCard(deck, activeMode)),
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderPromptCard(deck, activeMode) {
  const prompt = deck.promptByMode[activeMode.id] ?? deck.promptByMode.gentle;
  const coach = deck.coachByMode[activeMode.id] ?? deck.coachByMode.gentle;

  return el("article", {
    className: "prompt-card",
    children: [
      el("div", {
        className: "prompt-card__header",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: deck.phase }),
              el("h3", { text: deck.title }),
            ],
          }),
          el("span", { className: "pill", text: deck.time }),
        ],
      }),
      el("p", { className: "prompt-line", text: prompt }),
      el("div", {
        className: "prompt-ways",
        children: deck.replyWays.map((way) => el("span", { className: "chip", text: way })),
      }),
      el("div", {
        className: "prompt-note",
        children: [el("strong", { text: "老師可以這樣帶" }), el("p", { text: coach })],
      }),
      el("div", {
        className: "prompt-goal",
        html: `<span>想看到的回應</span><strong>${deck.goal}</strong>`,
      }),
    ],
  });
}

import { el, sectionTitle } from "../utils/dom.js";

const ALPHABET = "abcdefghijklmnopqrstuvwxyz".split("");

export function renderWordGuessGame({
  state,
  onUpdateSetup,
  onStartGame,
  onSelectPlayer,
  onGuessLetter,
  onToggleHint,
  onNewRound,
  onResetScores,
}) {
  return el("section", {
    className: "panel word-guess-panel",
    attrs: { id: "word-guess-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("猜單字遊戲", "", el("span", { className: "badge badge--warm", text: "英文遊戲" })),
          el("div", {
            className: "word-guess-layout",
            children: [
              renderWordGuessPlayerBoard(state, onSelectPlayer, onResetScores),
              state.status === "setup"
                ? renderWordGuessSetup(state, onUpdateSetup, onStartGame)
                : renderWordGuessPlay(state, onGuessLetter, onToggleHint, onNewRound),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderWordGuessPlayerBoard(state, onSelectPlayer, onResetScores) {
  return el("aside", {
    className: "word-guess-player-board",
    children: [
      el("div", {
        className: "phonics-board-head",
        children: [
          el("strong", { text: "學生輪流區" }),
          el("span", { className: "pill", text: `第 ${state.roundNumber} 局` }),
        ],
      }),
      el("div", {
        className: "word-guess-player-list",
        children: state.players.map((player, index) =>
          el("button", {
            className: `word-guess-player-card${index === state.activePlayerIndex ? " is-active" : ""}`,
            attrs: { type: "button", disabled: state.status === "playing" ? "disabled" : null },
            on: { click: () => onSelectPlayer(index) },
            children: [
              el("div", {
                children: [
                  el("strong", { text: player.name }),
                  el("span", { text: index === state.activePlayerIndex ? "本局挑戰" : "等待中" }),
                ],
              }),
              el("span", { className: "phonics-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("button", {
        className: "button button--secondary",
        text: "分數歸零",
        attrs: { type: "button" },
        on: { click: onResetScores },
      }),
    ],
  });
}

function renderWordGuessSetup(state, onUpdateSetup, onStartGame) {
  return el("article", {
    className: "word-guess-setup-card",
    children: [
      el("div", {
        className: "word-guess-setup-title",
        children: [
          el("span", { className: "badge badge--live", text: `輪到 ${state.players[state.activePlayerIndex].name}` }),
          el("h3", { text: "老師設定本局單字" }),
        ],
      }),
      el("div", {
        className: "word-guess-setup-grid",
        children: [
          renderSetupField("單字", "word", state.setup.word, "例如 apple", onUpdateSetup),
          renderSetupField("提示", "hint", state.setup.hint, "例如 fruit", onUpdateSetup),
          renderSetupField("最多錯幾次", "maxWrong", String(state.setup.maxWrong), "", onUpdateSetup, "number"),
        ],
      }),
      el("div", {
        className: "word-guess-rule-strip",
        children: [
          el("span", { text: "開始後會把單字遮起來。" }),
          el("span", { text: "學生每猜錯一個字母，就扣一次機會。" }),
          el("span", { text: "猜完整個單字可得分。" }),
        ],
      }),
      el("button", {
        className: "button button--primary word-guess-start",
        text: "開始猜",
        attrs: { type: "button" },
        on: { click: onStartGame },
      }),
    ],
  });
}

function renderSetupField(label, key, value, placeholder, onUpdateSetup, type = "text") {
  return el("label", {
    className: "phonics-word-field",
    children: [
      el("span", { text: label }),
      el("input", {
        attrs: {
          type,
          value,
          placeholder,
          min: type === "number" ? "1" : null,
          max: type === "number" ? "12" : null,
          autocomplete: "off",
          spellcheck: "false",
        },
        on: { input: (event) => onUpdateSetup(key, event.target.value) },
      }),
    ],
  });
}

function renderWordGuessPlay(state, onGuessLetter, onToggleHint, onNewRound) {
  const guessed = new Set(state.guessedLetters);
  const wrongLetters = getWrongLetters(state);
  const wrongCount = wrongLetters.length;
  const gameEnded = state.status === "won" || state.status === "lost";
  const remaining = Math.max(0, state.maxWrong - wrongCount);

  return el("article", {
    className: "word-guess-play-card",
    children: [
      el("div", {
        className: "word-guess-topline",
        children: [
          el("span", { className: "badge badge--warm", text: `輪到 ${state.players[state.activePlayerIndex].name}` }),
          el("span", { className: "pill", text: `剩 ${remaining} 次` }),
        ],
      }),
      renderWordMask(state.targetWord, guessed, gameEnded),
      renderChanceTrack(state.maxWrong, wrongCount),
      state.hint
        ? el("div", {
            className: `word-guess-hint${state.hintVisible ? " is-visible" : ""}`,
            children: [
              el("strong", { text: state.hintVisible ? state.hint : "提示先藏起來" }),
              el("button", {
                className: "button button--secondary",
                text: state.hintVisible ? "收起提示" : "打開提示",
                attrs: { type: "button" },
                on: { click: onToggleHint },
              }),
            ],
          })
        : null,
      renderWordGuessFeedback(state, wrongLetters),
      el("div", {
        className: "phonics-word-bank",
        children: ALPHABET.map((letter) =>
          el("button", {
            className: getLetterClass(letter, state, guessed),
            text: letter,
            attrs: { type: "button", disabled: guessed.has(letter) || gameEnded ? "disabled" : null },
            on: { click: () => onGuessLetter(letter) },
          }),
        ),
      }),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--primary",
            text: gameEnded ? "下一局" : "重新設定",
            attrs: { type: "button" },
            on: { click: onNewRound },
          }),
        ],
      }),
    ],
  });
}

function renderWordMask(word, guessed, gameEnded) {
  return el("div", {
    className: "phonics-word-mask word-guess-mask",
    children: word.split("").map((letter) =>
      el("span", {
        className: guessed.has(letter) || gameEnded ? "is-revealed" : "",
        text: guessed.has(letter) || gameEnded ? letter : "",
      }),
    ),
  });
}

function renderChanceTrack(maxWrong, wrongCount) {
  return el("div", {
    className: "word-guess-chances",
    children: Array.from({ length: maxWrong }, (_, index) =>
      el("span", {
        className: index < wrongCount ? "is-used" : "",
        text: index < wrongCount ? "x" : "",
      }),
    ),
  });
}

function renderWordGuessFeedback(state, wrongLetters) {
  if (state.status === "won") {
    return el("p", { className: "word-guess-feedback is-won", text: "猜對了，這局得 1 分。" });
  }

  if (state.status === "lost") {
    return el("p", { className: "word-guess-feedback is-lost", text: `機會用完，答案是 ${state.targetWord}。` });
  }

  return el("p", {
    className: "word-guess-feedback",
    text: wrongLetters.length ? `猜錯的字母：${wrongLetters.join(" ")}` : "還沒有猜錯，先選一個字母。",
  });
}

function getLetterClass(letter, state, guessed) {
  let className = "phonics-letter-tile";

  if (!guessed.has(letter)) {
    return className;
  }

  className += " is-active";
  className += state.targetWord.includes(letter) ? " is-correct" : " is-wrong";
  return className;
}

function getWrongLetters(state) {
  return state.guessedLetters.filter((letter) => !state.targetWord.includes(letter));
}

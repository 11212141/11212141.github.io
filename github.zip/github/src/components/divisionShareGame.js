import { el, sectionTitle } from "../utils/dom.js";

export function renderDivisionShareGame({
  challenge,
  gameState,
  onSelectPlayer,
  onSetPrediction,
  onPlaceItem,
  onShareCycle,
  onUndoMove,
  onResetRound,
  onSubmitRound,
  onNextRound,
  onResetGame,
}) {
  const section = el("section", { className: "panel", attrs: { id: "division-game" } });
  const currentRound = challenge.rounds[gameState.roundIndex];
  const activePlayer = gameState.players[gameState.activePlayerIndex];

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(challenge.title, "", el("span", { className: "badge badge--warm", text: challenge.badge })),
      el("div", {
        className: "division-layout",
        children: [
          renderPlayerBoard(gameState, onSelectPlayer),
          gameState.finished
            ? renderFinishedState(gameState, onResetGame)
            : renderRoundStage({
                challenge,
                gameState,
                currentRound,
                activePlayer,
                onSetPrediction,
                onPlaceItem,
                onShareCycle,
                onUndoMove,
                onResetRound,
                onSubmitRound,
                onNextRound,
                onResetGame,
              }),
        ],
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderPlayerBoard(gameState, onSelectPlayer) {
  return el("div", {
    className: "division-player-board",
    children: [
      el("div", {
        className: "division-board-head",
        children: [
          el("strong", { text: "四位學生輪流區" }),
          el("span", { className: "pill", text: `第 ${Math.min(gameState.roundIndex + 1, gameState.totalRounds)} 題` }),
        ],
      }),
      el("div", {
        className: "division-player-list",
        children: gameState.players.map((player, index) =>
          el("button", {
            className: `division-player-card${index === gameState.activePlayerIndex ? " is-active" : ""}`,
            attrs: { type: "button" },
            on: {
              click: () => onSelectPlayer(index),
            },
            children: [
              el("div", {
                className: "division-player-meta",
                children: [
                  el("strong", { text: player.name }),
                  el("span", { text: index === gameState.activePlayerIndex ? "目前作答" : "等待中" }),
                ],
              }),
              el("span", { className: "division-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderRoundStage({
  challenge,
  gameState,
  currentRound,
  activePlayer,
  onSetPrediction,
  onPlaceItem,
  onShareCycle,
  onUndoMove,
  onResetRound,
  onSubmitRound,
  onNextRound,
  onResetGame,
}) {
  const predictionOptions = buildPredictionOptions(currentRound.targetPerGroup);
  const hasPrediction = gameState.predictedPerGroup !== null;
  const predictionCorrect = gameState.predictedPerGroup === currentRound.targetPerGroup;

  return el("div", {
    className: "division-stage",
    children: [
      el("div", {
        className: "division-stage__header",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: `輪到 ${activePlayer.name}` }),
              el("h3", { text: currentRound.prompt }),
            ],
          }),
          el("div", {
            className: "button-row",
            children: [
              el("button", {
                className: "button button--ghost",
                text: "重新開始",
                attrs: { type: "button" },
                on: { click: onResetGame },
              }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "division-target-card",
        children: [
          el("span", { className: "badge badge--warm", text: `第 ${gameState.roundIndex + 1} 題` }),
          el("strong", { text: `${currentRound.total} 個 ${currentRound.itemName}` }),
          el("p", { text: currentRound.mission ?? "" }),
        ],
      }),
      el("div", {
        className: "division-status-row",
        children: [
          el("span", { className: "pill", text: "平均分配" }),
          el("span", { className: "pill", text: hasPrediction ? `先猜每份 ${gameState.predictedPerGroup}` : "先猜每份幾個" }),
          el("span", { className: "pill", text: `剩下 ${gameState.remaining} 個` }),
          el("span", { className: "pill", text: `共有 ${currentRound.groups} 份` }),
          el("span", { className: "pill", text: `${currentRound.itemName} 分配中` }),
          el("span", { className: "pill", text: `${currentRound.total} ÷ ${currentRound.groups} = ?` }),
        ],
      }),
      el("div", {
        className: "division-mission-strip",
        children: [
          missionStep("1", "看總數", `${currentRound.total} 個 ${currentRound.itemName}`),
          missionStep("2", "看份數", `平均分給 ${currentRound.groups} 個${currentRound.groupLabel}`),
          missionStep("3", "猜每份", hasPrediction ? `你猜每份 ${gameState.predictedPerGroup} 個` : "先選每份應該有幾個"),
        ],
      }),
      el("div", {
        className: "division-meta",
        children: [
          metaCard("除法式", `${currentRound.total} ÷ ${currentRound.groups}`),
          metaCard("每份目標", `${currentRound.targetPerGroup} 個`),
          metaCard("份數", `${currentRound.groups} 份`),
          metaCard("乘法驗算", `${currentRound.groups} × ${currentRound.targetPerGroup}`),
        ],
      }),
      el("div", {
        className: "division-guess-panel",
        children: [
          el("strong", { text: "第一關：先猜每份會有幾個" }),
          el("div", {
            className: "division-guess-grid",
            children: predictionOptions.map((value) =>
              el("button", {
                className: `division-guess-card${gameState.predictedPerGroup === value ? " is-active" : ""}${
                  gameState.lastResult && value === currentRound.targetPerGroup ? " is-correct" : ""
                }`,
                attrs: { type: "button", disabled: gameState.solved ? "disabled" : null },
                on: { click: () => onSetPrediction(value) },
                children: [
                  el("span", { className: "pill", text: `選項 ${value}` }),
                  el("strong", { text: `${value} 個` }),
                  el("p", { text: `每份 ${value} 個` }),
                ],
              }),
            ),
          }),
          hasPrediction
            ? el("p", {
                className: "division-guess-note",
                text: predictionCorrect
                  ? "猜對了，現在把每份都分到一樣多。"
                  : "先照你的預測動手分，等等再用乘法檢查看看。",
              })
            : el("p", { className: "division-guess-note", text: "先猜每份數量，遊戲才會開始。" }),
        ],
      }),
      el("div", {
        className: "division-basket-grid",
        children: gameState.allocations.map((count, index) =>
          el("button", {
            className: "division-basket-card",
            attrs: {
              type: "button",
              disabled: gameState.solved || gameState.remaining === 0 || !hasPrediction ? "disabled" : null,
            },
            on: {
              click: () => onPlaceItem(index),
            },
            children: [
              el("div", {
                className: "division-basket-card__header",
                children: [
                  el("strong", { text: `第 ${index + 1} 個${currentRound.groupLabel}` }),
                  el("span", { className: "division-basket-count", text: `${count} 個` }),
                ],
              }),
              el("div", {
                className: "division-basket-card__item",
                children: [
                  el("span", { className: "division-basket-emoji", text: currentRound.itemEmoji ?? "📦" }),
                  el("span", {
                    className: "division-basket-label",
                    text:
                      count === currentRound.targetPerGroup
                        ? "剛剛好"
                        : count < currentRound.targetPerGroup
                          ? `還差 ${currentRound.targetPerGroup - count} 個`
                          : `多了 ${count - currentRound.targetPerGroup} 個`,
                  }),
                ],
              }),
              el("div", {
                className: "division-dot-grid",
                children:
                  count > 0
                    ? Array.from({ length: count }, (_, dotIndex) =>
                        el("span", {
                          className: "division-dot",
                        }),
                      )
                    : [],
              }),
            ],
          }),
        ),
      }),
      renderFeedback(challenge, gameState, currentRound),
      el("div", {
        className: "division-actions",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "平均補貨一輪",
            attrs: {
              type: "button",
              disabled: gameState.solved || gameState.remaining === 0 || !hasPrediction ? "disabled" : null,
            },
            on: { click: onShareCycle },
          }),
          el("button", {
            className: "button button--secondary",
            text: "收回一步",
            attrs: {
              type: "button",
              disabled: gameState.solved || gameState.moveHistory.length === 0 ? "disabled" : null,
            },
            on: { click: onUndoMove },
          }),
          el("button", {
            className: "button button--ghost",
            text: "清空重分",
            attrs: {
              type: "button",
              disabled:
                gameState.solved || (gameState.moveHistory.length === 0 && gameState.remaining === currentRound.total)
                  ? "disabled"
                  : null,
            },
            on: { click: onResetRound },
          }),
          el("button", {
            className: "button button--primary",
            text: "送出答案",
            attrs: {
              type: "button",
              disabled: gameState.solved || gameState.moveHistory.length === 0 ? "disabled" : null,
            },
            on: { click: onSubmitRound },
          }),
          el("button", {
            className: "button button--secondary",
            text: gameState.roundIndex === gameState.totalRounds - 1 ? "看結果" : "下一題",
            attrs: {
              type: "button",
              disabled: gameState.solved ? null : "disabled",
            },
            on: { click: onNextRound },
          }),
        ],
      }),
    ],
  });
}

function renderFeedback(challenge, gameState, currentRound) {
  if (!gameState.lastResult) {
    return null;
  }

  if (gameState.lastResult.isCorrect) {
    return el("div", {
      className: "division-feedback is-success",
      children: [
        el("strong", { text: "分對了" }),
        el("p", { text: `你先猜 ${gameState.predictedPerGroup} 個，${gameState.predictedPerGroup === currentRound.targetPerGroup ? "猜對了" : "最後也修正成功了"}` }),
        el("p", { text: `每份有 ${currentRound.targetPerGroup} 個 ${currentRound.itemName}` }),
        el("p", { text: `${currentRound.total} ÷ ${currentRound.groups} = ${currentRound.targetPerGroup}` }),
        el("p", { text: `${currentRound.groups} × ${currentRound.targetPerGroup} = ${currentRound.total}` }),
      ],
    });
  }

  return el("div", {
    className: "division-feedback is-retry",
    children: [
      el("strong", { text: "再試一次" }),
      el(
        "p",
        {
          text:
            gameState.predictedPerGroup === null
              ? "先猜每份幾個，才能開始這一關。"
              :
            gameState.lastResult.reason === "remaining"
              ? `還剩下 ${gameState.lastResult.remaining} 個沒有分完`
              : "每份還沒有一樣多",
        },
      ),
      el("p", { text: `想一想：${currentRound.total} ÷ ${currentRound.groups} 應該是多少？` }),
    ],
  });
}

function renderFinishedState(gameState, onResetGame) {
  const winner = [...gameState.players].sort((left, right) => right.score - left.score)[0];

  return el("div", {
    className: "division-stage",
    children: [
      el("div", {
        className: "division-finish-card",
        children: [
          el("span", { className: "badge badge--warm", text: "挑戰完成" }),
          el("h3", { text: "平均分東西完成了" }),
          el("p", { text: `${winner.name} ${winner.score} 分` }),
        ],
      }),
      el("div", {
        className: "division-result-grid",
        children: gameState.players.map((player) =>
          el("div", {
            className: "division-result-card",
            children: [
              el("strong", { text: player.name }),
              el("span", { className: "division-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--primary",
            text: "再玩一次",
            attrs: { type: "button" },
            on: { click: onResetGame },
          }),
        ],
      }),
    ],
  });
}

function metaCard(label, value) {
  return el("div", {
    className: "mini-card",
    html: `<strong>${value}</strong><p>${label}</p>`,
  });
}

function missionStep(step, title, text) {
  return el("article", {
    className: "division-mission-step",
    children: [
      el("span", { className: "badge badge--warm", text: `第 ${step} 步` }),
      el("strong", { text: title }),
      el("p", { text }),
    ],
  });
}

function buildPredictionOptions(answer) {
  const options = new Set([answer, Math.max(1, answer - 1), answer + 1]);
  return Array.from(options).sort((left, right) => left - right);
}

import { el, sectionTitle } from "../utils/dom.js";

export function renderColorMixLab({
  challenge,
  gameState,
  mixedColor,
  onSelectRole,
  onChoosePrimary,
  onSubmitAnswer,
  onNextRound,
  onResetGame,
}) {
  const section = el("section", { className: "panel", attrs: { id: "color-mix-lab" } });

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(challenge.title, "", el("span", { className: "badge badge--warm", text: challenge.badge })),
      el("div", {
        className: "color-lab-layout",
        children: [
          renderPlayerBoard(gameState),
          renderLabStage({
            challenge,
            gameState,
            mixedColor,
            onSelectRole,
            onChoosePrimary,
            onSubmitAnswer,
            onNextRound,
            onResetGame,
          }),
        ],
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderPlayerBoard(gameState) {
  return el("aside", {
    className: "color-lab-player-board",
    children: [
      el("div", {
        className: "color-lab-player-board__head",
        children: [
          el("strong", { text: "回合看板" }),
          el("span", { className: "pill", text: `第 ${gameState.roundNumber} 回合` }),
        ],
      }),
      el("div", {
        className: "color-lab-player-list",
        children: gameState.players.map((player, index) =>
          el("div", {
            className: "color-lab-player-card",
            children: [
              el("div", {
                className: "color-lab-player-card__top",
                children: [
                  el("strong", { text: player.name }),
                  el("span", { className: "color-lab-score", text: `${player.score} 分` }),
                ],
              }),
              el("div", {
                className: "color-lab-role-tags",
                children: [
                  gameState.pickerOneIndex === index
                    ? el("span", { className: "pill", text: "選色 A" })
                    : null,
                  gameState.pickerTwoIndex === index
                    ? el("span", { className: "pill", text: "選色 B" })
                    : null,
                  gameState.answererIndex === index
                    ? el("span", { className: "pill", text: "回答" })
                    : null,
                ],
              }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderLabStage({
  challenge,
  gameState,
  mixedColor,
  onSelectRole,
  onChoosePrimary,
  onSubmitAnswer,
  onNextRound,
  onResetGame,
}) {
  const pickerOne = gameState.players[gameState.pickerOneIndex];
  const pickerTwo = gameState.players[gameState.pickerTwoIndex];
  const answerer = gameState.players[gameState.answererIndex];
  const colorOne = challenge.primaryColors.find((color) => color.id === gameState.pickerOneColorId) ?? null;
  const colorTwo = challenge.primaryColors.find((color) => color.id === gameState.pickerTwoColorId) ?? null;
  const isRevealed = Boolean(gameState.lastResult && mixedColor);

  return el("div", {
    className: "color-lab-stage",
    children: [
      el("div", {
        className: "color-lab-role-grid",
        children: [
          renderRoleCard({
            title: "選色 A",
            subtitle: pickerOne.name,
            students: gameState.players,
            selectedIndex: gameState.pickerOneIndex,
            disabledIndexes: [gameState.pickerTwoIndex],
            onSelect: (playerIndex) => onSelectRole("pickerOne", playerIndex),
            extra: renderPrimarySelector({
              challenge,
              selectedColorId: gameState.pickerOneColorId,
              selectedLabel: "已選 A",
              onPick: (colorId) => onChoosePrimary("pickerOne", colorId),
            }),
          }),
          renderRoleCard({
            title: "選色 B",
            subtitle: pickerTwo.name,
            students: gameState.players,
            selectedIndex: gameState.pickerTwoIndex,
            disabledIndexes: [gameState.pickerOneIndex],
            onSelect: (playerIndex) => onSelectRole("pickerTwo", playerIndex),
            extra: renderPrimarySelector({
              challenge,
              selectedColorId: gameState.pickerTwoColorId,
              selectedLabel: "已選 B",
              onPick: (colorId) => onChoosePrimary("pickerTwo", colorId),
            }),
          }),
          renderRoleCard({
            title: "誰來回答？",
            subtitle: answerer.name,
            students: gameState.players,
            selectedIndex: gameState.answererIndex,
            disabledIndexes: [],
            onSelect: (playerIndex) => onSelectRole("answerer", playerIndex),
            extra: el("p", { text: "請用英文說出混合後的顏色。" }),
          }),
        ],
      }),
      renderReactionCard({
        colorOne,
        colorTwo,
        mixedColor,
        isRevealed,
      }),
      renderAnswerPanel({
        challenge,
        mixedColor,
        gameState,
        onSubmitAnswer,
        onNextRound,
        onResetGame,
      }),
    ],
  });
}

function renderRoleCard({ title, subtitle, students, selectedIndex, disabledIndexes, onSelect, extra }) {
  return el("article", {
    className: "color-lab-role-card",
    children: [
      el("div", {
        className: "color-lab-role-card__head",
        children: [
          el("strong", { text: title }),
          el("span", { className: "pill", text: subtitle }),
        ],
      }),
      el("div", {
        className: "color-lab-student-grid",
        children: students.map((student, index) =>
          el("button", {
            className: `color-lab-student-chip${index === selectedIndex ? " is-active" : ""}`,
            attrs: {
              type: "button",
              disabled: disabledIndexes.includes(index) ? "disabled" : null,
            },
            on: {
              click: () => onSelect(index),
            },
            text: student.name,
          }),
        ),
      }),
      extra,
    ],
  });
}

function renderPrimarySelector({ challenge, selectedColorId, selectedLabel, onPick }) {
  const selectedColor = challenge.primaryColors.find((color) => color.id === selectedColorId) ?? null;

  return el("div", {
    className: "color-lab-primary-picker",
    children: [
      el("div", {
        className: `color-lab-selected-color${selectedColor ? " has-color" : ""}`,
        attrs: selectedColor ? { style: `--swatch:${selectedColor.swatch};` } : {},
        children: selectedColor
          ? [
              el("span", { text: selectedLabel }),
              el("strong", { text: selectedColor.label }),
            ]
          : [el("span", { text: selectedLabel }), el("strong", { text: "選一個顏色" })],
      }),
      el("div", {
        className: "color-lab-primary-grid",
        children: challenge.primaryColors.map((color) =>
          el("button", {
            className: `color-lab-color-button${color.id === selectedColorId ? " is-active" : ""}`,
            attrs: {
              type: "button",
              style: `--swatch:${color.swatch};`,
            },
            on: {
              click: () => onPick(color.id),
            },
            children: [
              el("span", { className: "color-lab-color-dot" }),
              el("strong", { text: color.label }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderReactionCard({ colorOne, colorTwo, mixedColor, isRevealed }) {
  const hasMix = Boolean(colorOne && colorTwo && mixedColor);

  return el("article", {
    className: `color-lab-reaction${hasMix ? " is-ready" : ""}${isRevealed ? " is-revealed" : ""}`,
    children: [
      el("div", {
        className: "color-lab-mixer",
        children: [
          renderBeaker("顏色 A", colorOne),
          el("span", { className: "color-lab-math", text: "+" }),
          renderBeaker("顏色 B", colorTwo),
          el("span", { className: "color-lab-math", text: "=" }),
          renderResultBeaker({
            mixedColor,
            isRevealed,
            isWaitingAnswer: hasMix && !isRevealed,
          }),
        ],
      }),
      el("div", {
        className: "color-lab-reaction__caption",
        children: [
          colorOne || colorTwo
            ? el("strong", {
                text: `${colorOne?.label ?? "?"} + ${colorTwo?.label ?? "?"}`,
              })
            : el("strong", { text: "先選兩個三原色。" }),
          isRevealed ? el("span", { className: "pill", text: `結果 = ${mixedColor.label}` }) : null,
          hasMix && !isRevealed
            ? el("p", { text: "先用英文猜猜看混合後的顏色。" })
            : isRevealed
              ? el("p", { text: "現在可以看結果了。" })
            : el("p", { text: "先選 Red、Yellow 或 Blue 開始混色。" }),
        ],
      }),
    ],
  });
}

function renderBeaker(label, color) {
  return el("div", {
    className: "color-lab-beaker",
    children: [
      el("span", { className: "color-lab-beaker__label", text: label }),
      el("div", {
        className: `color-lab-liquid${color ? " has-color" : ""}`,
        attrs: {
          style: color ? `--liquid:${color.swatch}; background-color:${color.swatch};` : "",
        },
      }),
      el("strong", {
        className: `color-lab-beaker__value${color ? " has-color" : ""}`,
        text: color ? color.label : "未選",
      }),
    ],
  });
}

function renderResultBeaker({ mixedColor, isRevealed, isWaitingAnswer }) {
  return el("div", {
    className: `color-lab-result${isRevealed ? " has-color" : ""}${isWaitingAnswer ? " is-hidden" : ""}`,
    attrs: {
      style: isRevealed && mixedColor ? `--liquid:${mixedColor.swatch};` : "",
    },
    children: [
      el("span", { className: "color-lab-beaker__label", text: "混合結果" }),
      el("div", {
        className: "color-lab-result__liquid",
        attrs: {
          style:
            isRevealed && mixedColor
              ? `--liquid:${mixedColor.swatch}; background-color:${mixedColor.swatch};`
              : "",
        },
      }),
      el("strong", {
        className: `color-lab-beaker__value${isRevealed && mixedColor ? " has-color" : ""}`,
        text: isRevealed && mixedColor ? mixedColor.label : isWaitingAnswer ? "先猜" : "?",
      }),
      isWaitingAnswer
        ? el("div", {
            className: "color-lab-result__cover",
            children: [el("span", { text: "?" })],
          })
        : null,
      isRevealed && mixedColor
        ? el("div", {
            className: "color-lab-bubbles",
            children: Array.from({ length: 6 }, (_, index) =>
              el("span", {
                className: "color-lab-bubble",
                attrs: { style: `--bubble-delay:${index * 0.18}s;` },
              }),
            ),
          })
        : null,
    ],
  });
}

function renderAnswerPanel({ challenge, mixedColor, gameState, onSubmitAnswer, onNextRound, onResetGame }) {
  return el("article", {
    className: "color-lab-answer-card",
    children: [
      el("div", {
        className: "color-lab-answer-card__head",
        children: [
          el("strong", { text: "請用英文作答" }),
          el("span", { className: "pill", text: gameState.players[gameState.answererIndex].name }),
        ],
      }),
      el("div", {
        className: "color-lab-answer-grid",
        children: challenge.answerColors.map((color) =>
          el("button", {
            className: `color-lab-answer-button color-lab-answer-button--plain${gameState.answerChoiceId === color.id ? " is-active" : ""}`,
            attrs: {
              type: "button",
              disabled: !mixedColor || gameState.lastResult ? "disabled" : null,
            },
            on: {
              click: () => onSubmitAnswer(color.id),
            },
            children: [
              el("strong", { text: color.label }),
            ],
          }),
        ),
      }),
      renderFeedback(gameState, mixedColor),
      el("div", {
        className: "color-lab-actions",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "下一回合",
            attrs: {
              type: "button",
              disabled: gameState.lastResult ? null : "disabled",
            },
            on: {
              click: onNextRound,
            },
          }),
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button" },
            on: {
              click: onResetGame,
            },
          }),
        ],
      }),
    ],
  });
}

function renderFeedback(gameState, mixedColor) {
  if (!gameState.lastResult || !mixedColor) {
    return el("div", {
      className: "color-lab-feedback",
      children: [el("p", { text: "先選英文顏色答案，答完才會打開混合結果。" })],
    });
  }

  if (gameState.lastResult.isCorrect) {
    return el("div", {
      className: "color-lab-feedback is-success",
      children: [
        el("strong", { text: "答對了！" }),
        el("p", { text: `答案是 ${mixedColor.label}。` }),
      ],
    });
  }

  return el("div", {
    className: "color-lab-feedback is-retry",
    children: [
      el("strong", { text: "再想想看。" }),
      el("p", { text: `混合後的顏色是 ${mixedColor.label}。` }),
    ],
  });
}

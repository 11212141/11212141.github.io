import { el } from "../utils/dom.js";

export function renderPageLead({
  id,
  eyebrow,
  title,
  description,
  badge,
  modes = [],
  activeModeId,
  onModeChange,
  stats = [],
  actions = [],
}) {
  const section = el("section", { className: "hero", attrs: { id } });
  const container = el("div", { className: "container" });
  const panel = el("section", {
    className: "panel",
    children: [
      el("div", {
        className: "panel__content page-lead",
        children: [
          el("div", {
            className: "page-lead__top",
            children: [
              el("div", {
                children: [
                  eyebrow
                    ? el("div", {
                        className: "eyebrow",
                        text: eyebrow,
                      })
                    : null,
                  el("h1", { text: title }),
                  description ? el("p", { text: description }) : null,
                ],
              }),
              badge ? el("span", { className: "badge badge--warm", text: badge }) : null,
            ],
          }),
          modes.length > 0 && onModeChange
            ? el("div", {
                className: "tab-list",
                children: modes.map((mode) =>
                  el("button", {
                    className: mode.id === activeModeId ? "is-active" : "",
                    text: mode.label,
                    on: {
                      click: () => onModeChange(mode.id),
                    },
                  }),
                ),
              })
            : null,
          stats.length > 0
            ? el("div", {
                className: "hero-metrics",
                children: stats.map((item) =>
                  el("div", {
                    className: "metric",
                    html: `<strong>${item.value}</strong><span>${item.label}</span>`,
                  }),
                ),
              })
            : null,
          actions.length > 0
            ? el("div", {
                className: "button-row",
                children: actions.map((action) =>
                  el(action.onClick ? "button" : "a", {
                    className: `button ${action.variant ?? "button--secondary"}`,
                    text: action.label,
                    attrs: action.onClick ? { type: "button" } : { href: action.href },
                    on: action.onClick ? { click: action.onClick } : {},
                  }),
                ),
              })
            : null,
        ],
      }),
    ],
  });

  container.append(panel);
  section.append(container);
  return section;
}

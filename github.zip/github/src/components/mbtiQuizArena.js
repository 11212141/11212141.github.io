import { el, sectionTitle } from "../utils/dom.js";

export function renderMbtiQuizArena({
  quiz,
  profiles,
  state,
  onSelectPlayer,
  onAnswer,
  onResetPlayer,
  onShowType,
}) {
  const section = el("section", { className: "panel", attrs: { id: "mbti-quiz" } });
  const activePlayer = state.players[state.activePlayerIndex];
  const currentQuestion = quiz.questions.find((question) => !activePlayer.answers[question.id]) ?? null;
  const resultProfile = profiles.find((profile) => profile.id === activePlayer.resultType) ?? null;
  const completedCount = state.players.filter((player) => player.completed).length;

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(quiz.title, quiz.summary, el("span", { className: "badge badge--warm", text: quiz.badge })),
      el("div", {
        className: "mbti-quiz-layout",
        children: [
          renderPlayerBoard(state, quiz, completedCount, onSelectPlayer),
          renderStage({
            quiz,
            activePlayer,
            currentQuestion,
            resultProfile,
            onAnswer,
            onResetPlayer,
            onShowType,
          }),
        ],
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderPlayerBoard(state, quiz, completedCount, onSelectPlayer) {
  return el("aside", {
    className: "mbti-player-board",
    children: [
      el("div", {
        className: "mbti-player-board__head",
        children: [
          el("strong", { text: "四位學生" }),
          el("span", { className: "pill", text: `${completedCount} / ${state.players.length} 完成` }),
        ],
      }),
      el("div", {
        className: "mbti-player-list",
        children: state.players.map((player, index) =>
          el("button", {
            className: `mbti-player-card${index === state.activePlayerIndex ? " is-active" : ""}`,
            attrs: { type: "button" },
            on: { click: () => onSelectPlayer(index) },
            children: [
              el("div", {
                className: "mbti-player-card__top",
                children: [
                  el("strong", { text: player.name }),
                  player.resultType
                    ? el("span", { className: "pill", text: player.resultType })
                    : el("span", {
                        className: "pill",
                        text: `${Object.keys(player.answers).length} / ${quiz.questions.length}`,
                      }),
                ],
              }),
              el("p", {
                text: player.completed ? "已完成，可看結果" : index === state.activePlayerIndex ? "目前作答" : "等待中",
              }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderStage({
  quiz,
  activePlayer,
  currentQuestion,
  resultProfile,
  onAnswer,
  onResetPlayer,
  onShowType,
}) {
  if (activePlayer.completed && resultProfile) {
    return renderResultStage(activePlayer, resultProfile, onResetPlayer, onShowType);
  }

  const currentIndex = currentQuestion ? quiz.questions.findIndex((item) => item.id === currentQuestion.id) : 0;

  return el("article", {
    className: "mbti-stage",
    children: [
      el("div", {
        className: "mbti-stage__header",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: `輪到 ${activePlayer.name}` }),
              el("h3", { text: currentQuestion ? currentQuestion.title : "開始作答" }),
              el("p", { text: currentQuestion ? currentQuestion.prompt : "" }),
            ],
          }),
          el("button", {
            className: "button button--ghost",
            text: "清空這位學生",
            attrs: {
              type: "button",
              disabled: Object.keys(activePlayer.answers).length === 0 ? "disabled" : null,
            },
            on: {
              click: () => onResetPlayer(),
            },
          }),
        ],
      }),
      el("div", {
        className: "mbti-progress-strip",
        children: quiz.questions.map((question, index) =>
          el("div", {
            className: `mbti-progress-pill${question.id === currentQuestion?.id ? " is-active" : ""}${activePlayer.answers[question.id] ? " is-done" : ""}`,
            children: [
              el("strong", { text: `${index + 1}` }),
              el("span", { text: activePlayer.answers[question.id] ?? question.title }),
            ],
          }),
        ),
      }),
      currentQuestion
        ? el("div", {
            className: "mbti-choice-grid",
            children: currentQuestion.options.map((option) =>
              el("button", {
                className: "mbti-choice-button",
                attrs: { type: "button" },
                on: {
                  click: () => onAnswer(currentQuestion.id, option.id),
                },
                children: [el("strong", { text: option.label }), el("span", { text: option.note })],
              }),
            ),
          })
        : null,
      el("div", {
        className: "mbti-stage-footer",
        children: [
          el("span", {
            className: "pill",
            text: `第 ${Math.min(currentIndex + 1, quiz.questions.length)} 題 / 共 ${quiz.questions.length} 題`,
          }),
        ],
      }),
    ],
  });
}

function renderResultStage(activePlayer, resultProfile, onResetPlayer, onShowType) {
  return el("article", {
    className: "mbti-stage mbti-stage--result",
    children: [
      el("span", { className: "badge badge--live", text: `${activePlayer.name} 的結果` }),
      el("div", {
        className: "mbti-stage-result__head",
        children: [
          el("strong", { text: resultProfile.id }),
          el("span", { className: "pill", text: resultProfile.officialName }),
        ],
      }),
      el("p", { text: resultProfile.summary }),
      el("div", {
        className: "mbti-strength-list",
        children: resultProfile.strengths.map((strength) =>
          el("span", {
            className: "mbti-strength",
            text: strength,
          }),
        ),
      }),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--primary",
            text: "看這型分析",
            attrs: { type: "button" },
            on: { click: () => onShowType(resultProfile.id) },
          }),
          el("button", {
            className: "button button--secondary",
            text: "重新作答這位",
            attrs: { type: "button" },
            on: { click: () => onResetPlayer() },
          }),
        ],
      }),
    ],
  });
}

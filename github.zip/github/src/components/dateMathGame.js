import { el, sectionTitle } from "../utils/dom.js";

export function renderDateMathGame({
  challenge,
  state,
  rounds,
  currentRound,
  activePlayer,
  onSetMode,
  onSetVisualMode,
  onSelectPlayer,
  onChooseAnswer,
  onNextRound,
  onReset,
}) {
  return el("section", {
    className: "panel date-math-panel",
    attrs: { id: "date-math-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle(challenge.title, "", el("span", { className: "badge badge--warm", text: challenge.badge })),
          el("div", {
            className: "date-math-layout",
            children: [
              renderDateMathStage({ state, rounds, currentRound, activePlayer, onSetVisualMode, onChooseAnswer, onNextRound, onReset }),
              renderDateMathSide({ challenge, state, rounds, onSetMode, onSelectPlayer }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderDateMathSide({ challenge, state, rounds, onSetMode, onSelectPlayer }) {
  const progress = Math.round(((state.roundIndex + 1) / rounds.length) * 100);

  return el("aside", {
    className: "date-math-side",
    children: [
      el("div", {
        className: "date-math-progress",
        children: [
          el("div", {
            className: "date-math-progress__head",
            children: [
              el("strong", { text: "題目進度" }),
              el("span", { text: `${state.roundIndex + 1} / ${rounds.length}` }),
            ],
          }),
          el("div", {
            className: "date-math-progress__track",
            children: [el("span", { attrs: { style: `width:${progress}%;` } })],
          }),
        ],
      }),
      el("div", {
        className: "date-math-mode-grid",
        children: challenge.modes.map((mode) =>
          el("button", {
            className: `date-math-mode${state.mode === mode.id ? " is-active" : ""}`,
            text: mode.label,
            attrs: { type: "button" },
            on: { click: () => onSetMode(mode.id) },
          }),
        ),
      }),
      el("div", {
        className: "date-math-player-list",
        children: state.players.map((player, index) =>
          el("button", {
            className: `date-math-player${index === state.activePlayerIndex ? " is-active" : ""}`,
            attrs: { type: "button" },
            on: { click: () => onSelectPlayer(index) },
            children: [
              el("strong", { text: player.name }),
              el("span", { text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("div", {
        className: "date-math-concepts",
        children: [
          el("strong", { text: "日期小觀念" }),
          ...challenge.concepts.map((concept) => el("p", { text: concept })),
        ],
      }),
    ],
  });
}

function renderDateMathStage({ state, rounds, currentRound, activePlayer, onSetVisualMode, onChooseAnswer, onNextRound, onReset }) {
  return el("article", {
    className: "date-math-stage",
    children: [
      el("div", {
        className: "date-math-stage__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: `輪到 ${activePlayer.name}` }),
              el("h3", { text: currentRound.modeLabel }),
            ],
          }),
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button" },
            on: { click: onReset },
          }),
        ],
      }),
      el("div", {
        className: "date-math-question-grid",
        children: [
          renderDateVisual(currentRound, state, onSetVisualMode),
          el("div", {
            className: "date-math-question-card",
            children: [
              el("span", { className: "badge badge--warm", text: `第 ${state.roundIndex + 1} 題` }),
              el("h2", { text: currentRound.prompt }),
              el("div", {
                className: "date-math-option-grid",
                children: currentRound.options.map((option) =>
                  el("button", {
                    className: getDateOptionClass(option, state, currentRound),
                    text: option,
                    attrs: { type: "button", disabled: state.answered ? "disabled" : null },
                    on: { click: () => onChooseAnswer(option) },
                  }),
                ),
              }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "date-math-feedback-row",
        children: [
          el("div", {
            className: "date-math-concept-card",
            children: [
              el("strong", { text: "想法提示" }),
              el("p", { text: state.answered ? currentRound.concept : getThinkingHint(currentRound) }),
            ],
          }),
          state.result
            ? el("div", {
                className: `date-math-feedback ${state.result.isCorrect ? "is-correct" : "is-wrong"}`,
                children: [
                  el("strong", { text: state.result.isCorrect ? "答對了" : "再想一次" }),
                  el("p", { text: state.result.isCorrect ? "日期觀念掌握得很好。" : `答案是 ${currentRound.answer}。` }),
                ],
              })
            : null,
        ],
      }),
      el("div", {
        className: "date-math-actions",
        children: [
          el("button", {
            className: "button button--primary",
            text: state.roundIndex >= rounds.length - 1 ? "回到第一題" : "下一題",
            attrs: { type: "button", disabled: state.answered ? null : "disabled" },
            on: { click: onNextRound },
          }),
        ],
      }),
    ],
  });
}

function renderDateVisual(round, state, onSetVisualMode) {
  const visual = round.visual ?? {};
  const day = visual.day ?? 1;
  const month = visual.month ?? 1;
  const isRevealed = Boolean(state.answered);
  const visualMode = state.visualMode ?? "day";

  return el("div", {
    className: "date-math-visual",
    children: [
      renderVisualTabs(visualMode, onSetVisualMode),
      el("div", {
        className: "date-math-calendar",
        children: [
          el("div", {
            className: "date-math-calendar__top",
            children: [
              el("strong", { text: `${month} 月` }),
              el("span", { text: isRevealed ? visual.tag ?? round.modeLabel : "想一想" }),
            ],
          }),
          renderCalendarView({ visualMode, visual, month, day, round, isRevealed }),
        ],
      }),
      visual.move
        ? el("div", {
            className: "date-math-move",
            children: [
              el("span", { text: `${day} 日` }),
              el("strong", { text: `+ ${visual.move} 天` }),
              el("span", { text: isRevealed ? `${visual.target.month} 月 ${visual.target.day} 日` : "？月？日" }),
            ],
          })
        : null,
    ],
  });
}

function renderVisualTabs(activeMode, onSetVisualMode) {
  const modes = [
    { id: "day", label: "日曆" },
    { id: "month", label: "月曆" },
    { id: "year", label: "年曆" },
  ];

  return el("div", {
    className: "date-math-visual-tabs",
    children: modes.map((mode) =>
      el("button", {
        className: `date-math-visual-tab${activeMode === mode.id ? " is-active" : ""}`,
        text: mode.label,
        attrs: { type: "button" },
        on: { click: () => onSetVisualMode(mode.id) },
      }),
    ),
  });
}

function renderCalendarView({ visualMode, visual, month, day, isRevealed }) {
  if (visualMode === "year") {
    return renderYearView(month);
  }

  if (visualMode === "month") {
    return renderMonthView(visual, month, day, isRevealed);
  }

  return renderDayView(visual, month, day, isRevealed);
}

function renderDayView(visual, month, day, isRevealed) {
  const startDay = Math.max(1, day - 4);
  const days = Array.from({ length: 14 }, (_, index) => startDay + index)
    .filter((item) => item <= getDateMathMonthDays(month));

  return el("div", {
    className: "date-math-calendar-wrap",
    children: [
      renderWeekHeader(),
      el("div", {
        className: "date-math-calendar__grid",
        children: days.map((item) =>
          el("span", {
            className: getCalendarDayClass(item, day, visual, isRevealed),
            text: String(item),
          }),
        ),
      }),
    ],
  });
}

function renderMonthView(visual, month, day, isRevealed) {
  const totalDays = getDateMathMonthDays(month);
  const startWeekday = visual.startWeekday ?? 2;
  const cells = [
    ...Array.from({ length: startWeekday }, () => null),
    ...Array.from({ length: totalDays }, (_, index) => index + 1),
  ];

  return el("div", {
    className: "date-math-calendar-wrap",
    children: [
      renderWeekHeader(),
      el("div", {
        className: "date-math-calendar__grid date-math-calendar__grid--month",
        children: cells.map((item) =>
          item
            ? el("span", {
                className: getCalendarDayClass(item, day, visual, isRevealed),
                text: String(item),
              })
            : el("span", { className: "is-empty", text: "" }),
        ),
      }),
    ],
  });
}

function renderYearView(activeMonth) {
  return el("div", {
    className: "date-math-year-grid",
    children: Array.from({ length: 12 }, (_, index) => {
      const month = index + 1;
      return el("div", {
        className: `date-math-year-month${month === activeMonth ? " is-active" : ""}`,
        children: [
          el("strong", { text: `${month} 月` }),
          el("span", { text: `${getDateMathMonthDays(month)} 天` }),
        ],
      });
    }),
  });
}

function renderWeekHeader() {
  return el("div", {
    className: "date-math-week-row",
    children: ["日", "一", "二", "三", "四", "五", "六"].map((label) => el("span", { text: label })),
  });
}

function getCalendarDayClass(item, day, visual, isRevealed) {
  if (item === day) return "is-today";
  if (isRevealed && item === visual.target?.day) return "is-target";
  return "";
}

function getDateMathMonthDays(month) {
  return {
    1: 31,
    2: 28,
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31,
  }[month] ?? 31;
}

function getThinkingHint(round) {
  if (round.mode === "elapsed") {
    return "從開始日期往後數，注意月底後會換到下一個月。";
  }

  if (round.mode === "weekday") {
    return "星期每 7 天一圈，可以先找相差幾天。";
  }

  if (round.mode === "month") {
    return "先想這個月是大月、小月，還是 2 月。";
  }

  return "先找到題目中的年、月、日三個位置。";
}

function getDateOptionClass(option, state, round) {
  if (!state.answered) return "date-math-option";
  if (option === round.answer) return "date-math-option is-correct";
  if (option === state.selectedAnswer) return "date-math-option is-wrong";
  return "date-math-option";
}

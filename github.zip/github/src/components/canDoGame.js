import { el, sectionTitle } from "../utils/dom.js";

const RESPONSE_OPTIONS = [
  { id: "yes", label: "Yes, I can.", helper: "可以，直接回答" },
  { id: "no", label: "No, I can’t.", helper: "不可以，也能回答" },
  { id: "sentence", label: "I can ___ with ___ .", helper: "完整句挑戰" },
];

export function renderCanDoGame({
  challenge,
  state,
  onSelectPlayer,
  onPickAction,
  onPickPartner,
  onChooseAnswer,
  onNextRound,
  onResetGame,
}) {
  return el("section", {
    className: "panel can-do-panel can-do-cardplay-panel",
    attrs: { id: "can-do-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("Can 雙卡任務", "", el("span", { className: "badge badge--live", text: challenge.badge })),
          state.finished
            ? renderFinished(state, onResetGame)
            : renderCardRound({ challenge, state, onSelectPlayer, onPickAction, onPickPartner, onChooseAnswer, onNextRound, onResetGame }),
        ],
      }),
    ],
  });
}

function renderCardRound({ challenge, state, onSelectPlayer, onPickAction, onPickPartner, onChooseAnswer, onNextRound, onResetGame }) {
  const action = challenge.actions.find((item) => item.id === state.selectedActionId);
  const partner = challenge.partners.find((item) => item.id === state.selectedPartnerId);
  const activePlayer = state.players[state.activePlayerIndex];

  return el("article", {
    className: "can-do-cardplay",
    children: [
      el("div", {
        className: "can-do-adventure__top",
        children: [
          renderPlayerRow(state, onSelectPlayer),
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button" },
            on: { click: onResetGame },
          }),
        ],
      }),
      el("div", {
        className: "can-do-cardplay-layout",
        children: [
          el("section", {
            className: "can-do-card-table",
            children: [
              el("div", {
                className: "can-do-turn-card",
                children: [
                  el("span", { className: "badge badge--warm", text: `輪到 ${activePlayer.name}` }),
                  el("span", { className: "pill", text: `${activePlayer.score} 分` }),
                ],
              }),
              renderDeck("先選動作卡", state.actionOptions, state.selectedActionId, onPickAction, "action"),
              renderDeck("再選夥伴卡", state.partnerOptions, state.selectedPartnerId, onPickPartner, "partner"),
            ],
          }),
          el("aside", {
            className: "can-do-control-card",
            children: [
              renderMissionCard({ state, action, partner, onChooseAnswer, onNextRound }),
              el("p", {
                className: "can-do-progress-note",
                text: `回合 ${state.roundIndex + 1} / 16`,
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderDeck(title, options, selectedId, onPick, type) {
  return el("div", {
    className: "can-do-deck-block",
    children: [
      el("strong", { text: title }),
      el("div", {
        className: `can-do-card-grid can-do-card-grid--${type}`,
        children: options.map((item) =>
          el("button", {
            className: `can-do-pick-card${selectedId === item.id ? " is-selected" : ""}`,
            attrs: { type: "button" },
            on: { click: () => onPick(item.id) },
            children: [
              el("span", { text: item.emoji }),
              el("strong", { text: item.label }),
              el("small", { text: item.chinese }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderMissionCard({ state, action, partner, onChooseAnswer, onNextRound }) {
  if (!action || !partner) {
    return el("div", {
      className: "can-do-mission-board-card is-covered",
      children: [
        el("span", { text: "任務區" }),
        el("strong", { text: action ? "再選夥伴" : "先選動作" }),
      ],
    });
  }

  const question = `Can you ${action.label} with ${partner.label}?`;
  const sentence = `I can ${action.label} with ${partner.label}.`;
  const cannot = `I can’t ${action.label} with ${partner.label}.`;

  return el("div", {
    className: "can-do-mission-board-card",
    children: [
      el("div", {
        className: "can-do-card-headline",
        children: [
          el("span", { className: "badge badge--warm", text: "雙卡任務" }),
          el("strong", { text: "問同學會不會" }),
        ],
      }),
      el("div", {
        className: "can-do-question-bubble",
        children: [
          el("span", { text: "老師問" }),
          el("strong", { text: question }),
        ],
      }),
      el("div", {
        className: "can-do-sentence-runway",
        children: ["Can you", action.label, "with", partner.label, "?"].map((word, index) =>
          el("span", { className: index === 1 || index === 3 ? "is-keyword" : "", text: word }),
        ),
      }),
      el("div", {
        className: "can-do-answer-grid",
        children: RESPONSE_OPTIONS.map((option) =>
          el("button", {
            className: `can-do-answer${state.selectedAnswer === option.id ? " is-selected" : ""}`,
            attrs: { type: "button", disabled: state.isAnswered ? "disabled" : null },
            on: { click: () => onChooseAnswer(option.id) },
            children: [el("span", { text: option.helper }), el("strong", { text: option.label })],
          }),
        ),
      }),
      renderFeedback({ state, sentence, cannot }),
      el("button", {
        className: "button button--primary button--full",
        text: state.roundIndex >= 15 ? "看結果" : "下一組雙卡",
        attrs: { type: "button", disabled: state.isAnswered ? null : "disabled" },
        on: { click: onNextRound },
      }),
    ],
  });
}

function renderFeedback({ state, sentence, cannot }) {
  if (!state.isAnswered) {
    return el("p", { className: "can-do-feedback", text: "學生可以照自己的情況回答，重點是把英文句子說出來。" });
  }

  const line = state.selectedAnswer === "no" ? cannot : sentence;
  return el("p", { className: "can-do-feedback is-open", text: `${line} 完成口說 +${state.lastResult?.score ?? 2} 分。` });
}

function renderPlayerRow(state, onSelectPlayer) {
  return el("div", {
    className: "can-do-player-row",
    children: state.players.map((player, index) =>
      el("button", {
        className: `can-do-player${index === state.activePlayerIndex ? " is-active" : ""}`,
        attrs: { type: "button", disabled: state.selectedActionId || state.selectedPartnerId ? "disabled" : null },
        on: { click: () => onSelectPlayer(index) },
        children: [el("strong", { text: player.name }), el("span", { text: `${player.score} 分` })],
      }),
    ),
  });
}

function renderFinished(state, onResetGame) {
  return el("article", {
    className: "can-do-finished",
    children: [
      el("h3", { text: "雙卡任務完成" }),
      el("div", {
        className: "can-do-result-grid",
        children: state.players.map((player) =>
          el("div", {
            className: "can-do-result-card",
            children: [el("strong", { text: player.name }), el("span", { text: `${player.score} 分` })],
          }),
        ),
      }),
      el("button", { className: "button button--primary", text: "再玩一次", attrs: { type: "button" }, on: { click: onResetGame } }),
    ],
  });
}

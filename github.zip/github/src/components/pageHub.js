import { el, sectionTitle } from "../utils/dom.js";

export function renderPageHub({ pages }) {
  const section = el("section", { className: "panel", attrs: { id: "page-hub" } });

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle("活動頁面", ""),
      el("div", {
        className: "hub-grid",
        children: pages.map((page) =>
          el("a", {
            className: "hub-card",
            attrs: { href: page.href },
            children: [
              el("div", {
                className: "hub-card__header",
                children: [
                  el("span", { className: "badge badge--live", text: page.badge }),
                  el("span", { className: "pill", text: page.label }),
                ],
              }),
              el("h3", { text: page.label }),
              el("span", { className: "hub-card__footer", text: "進入" }),
            ],
          }),
        ),
      }),
    ],
  });

  section.append(content);
  return section;
}

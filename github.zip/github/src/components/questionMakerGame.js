import { el, sectionTitle } from "../utils/dom.js";

const typeLabels = {
  word: "文字題",
  math: "數學題",
  english: "英文題",
  choice: "選擇題",
  open: "開放回答",
};

export function renderQuestionMakerGame({
  state,
  onUpdateDraft,
  onAddQuestion,
  onPickQuestion,
  onSelectQuestion,
  onToggleAnswer,
  onMarkDone,
  onDeleteQuestion,
  onResetDraft,
}) {
  return el("section", {
    className: "panel question-maker",
    attrs: { id: "question-maker" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("應用出題", "老師輸入題目後，可以直接變成上課題卡。"),
          el("div", {
            className: "question-maker__layout",
            children: [
              renderEditor({ state, onUpdateDraft, onAddQuestion, onResetDraft }),
              renderStage({ state, onPickQuestion, onToggleAnswer, onMarkDone }),
            ],
          }),
          renderQuestionBank({ state, onSelectQuestion, onDeleteQuestion }),
        ],
      }),
    ],
  });
}

function renderEditor({ state, onUpdateDraft, onAddQuestion, onResetDraft }) {
  const { draft } = state;

  return el("article", {
    className: "question-editor",
    children: [
      el("div", {
        className: "question-editor__top",
        children: [
          el("span", { className: "badge badge--warm", text: "老師出題" }),
          el("button", {
            className: "button button--ghost",
            text: "清空",
            attrs: { type: "button" },
            on: { click: onResetDraft },
          }),
        ],
      }),
      renderField("題目類型", [
        el("div", {
          className: "question-type-grid",
          children: Object.entries(typeLabels).map(([value, label]) =>
            el("button", {
              className: draft.type === value ? "question-type is-active" : "question-type",
              text: label,
              attrs: { type: "button" },
              on: { click: () => onUpdateDraft("type", value) },
            }),
          ),
        }),
      ]),
      renderField("題目", [
        el("textarea", {
          className: "question-input question-input--main",
          text: draft.prompt,
          attrs: {
            rows: "5",
            placeholder: "例如：小明有 35 元，買鉛筆花 12 元，還剩多少元？",
          },
          on: {
            input: (event) => onUpdateDraft("prompt", event.target.value),
          },
        }),
      ]),
      renderField("選項或提示", [
        el("input", {
          className: "question-input",
          attrs: {
            type: "text",
            value: draft.choices,
            placeholder: "可留空。也可以輸入：A 23 元｜B 47 元｜C 12 元",
          },
          on: {
            input: (event) => onUpdateDraft("choices", event.target.value),
          },
        }),
      ]),
      renderField("答案或老師備註", [
        el("textarea", {
          className: "question-input",
          text: draft.answer,
          attrs: {
            rows: "3",
            placeholder: "可留空。按「顯示答案」時才會出現。",
          },
          on: {
            input: (event) => onUpdateDraft("answer", event.target.value),
          },
        }),
      ]),
      el("button", {
        className: "button button--primary question-editor__submit",
        text: "新增成題卡",
        attrs: { type: "button" },
        on: { click: onAddQuestion },
      }),
    ],
  });
}

function renderStage({ state, onPickQuestion, onToggleAnswer, onMarkDone }) {
  const current = state.questions.find((question) => question.id === state.activeQuestionId) ?? state.questions[0];
  const hasQuestion = Boolean(current);

  return el("article", {
    className: "question-stage",
    children: [
      el("div", {
        className: "question-stage__toolbar",
        children: [
          el("span", {
            className: "badge badge--live",
            text: hasQuestion ? typeLabels[current.type] ?? "題卡" : "尚未出題",
          }),
          el("div", {
            className: "button-row question-stage__actions",
            children: [
              el("button", {
                className: "button button--secondary",
                text: "抽一題",
                attrs: { type: "button", disabled: state.questions.length < 2 ? "disabled" : null },
                on: { click: onPickQuestion },
              }),
              el("button", {
                className: "button button--secondary",
                text: state.showAnswer ? "隱藏答案" : "顯示答案",
                attrs: { type: "button", disabled: !hasQuestion ? "disabled" : null },
                on: { click: onToggleAnswer },
              }),
            ],
          }),
        ],
      }),
      hasQuestion ? renderQuestionCard(current, state.showAnswer) : renderEmptyStage(),
      el("button", {
        className: "button button--primary question-stage__done",
        text: current?.done ? "取消完成" : "標記完成",
        attrs: { type: "button", disabled: !hasQuestion ? "disabled" : null },
        on: { click: onMarkDone },
      }),
    ],
  });
}

function renderQuestionCard(question, showAnswer) {
  const choices = splitChoices(question.choices);

  return el("div", {
    className: question.done ? "question-card-display is-done" : "question-card-display",
    children: [
      el("div", {
        className: "question-card-display__meta",
        children: [
          el("span", { text: question.done ? "已完成" : "挑戰中" }),
          el("strong", { text: typeLabels[question.type] ?? "題卡" }),
        ],
      }),
      el("p", { className: "question-card-display__prompt", text: question.prompt }),
      choices.length
        ? el("div", {
            className: "question-choice-list",
            children: choices.map((choice, index) =>
              el("div", {
                className: "question-choice",
                children: [
                  el("span", { text: String.fromCharCode(65 + index) }),
                  el("strong", { text: choice.replace(/^[A-D]\s*/i, "").trim() }),
                ],
              }),
            ),
          })
        : el("div", {
            className: "question-open-answer",
            text: "請學生說出想法，或在白板上寫下解法。",
          }),
      showAnswer
        ? el("div", {
            className: "question-answer",
            children: [
              el("span", { text: "答案 / 備註" }),
              el("p", { text: question.answer || "這題沒有設定標準答案，可以聽學生怎麼說。" }),
            ],
          })
        : null,
    ],
  });
}

function renderEmptyStage() {
  return el("div", {
    className: "question-card-display question-card-display--empty",
    children: [
      el("p", { className: "question-card-display__prompt", text: "先在左邊輸入一題，這裡就會變成大題卡。" }),
      el("div", { className: "question-open-answer", text: "題目會自動保留在這台電腦的瀏覽器中。" }),
    ],
  });
}

function renderQuestionBank({ state, onSelectQuestion, onDeleteQuestion }) {
  return el("article", {
    className: "question-bank",
    children: [
      sectionTitle(
        "題目庫",
        "",
        el("span", { className: "pill", text: `${state.questions.length} 題` }),
      ),
      state.questions.length
        ? el("div", {
            className: "question-bank__list",
            children: state.questions.map((question, index) =>
              el("div", {
                className: question.id === state.activeQuestionId ? "question-bank-card is-active" : "question-bank-card",
                children: [
                  el("button", {
                    className: "question-bank-card__main",
                    attrs: { type: "button" },
                    on: { click: () => onSelectQuestion(question.id) },
                    children: [
                      el("span", { text: `第 ${index + 1} 題` }),
                      el("strong", { text: question.prompt }),
                      el("small", { text: `${typeLabels[question.type] ?? "題卡"}${question.done ? " · 已完成" : ""}` }),
                    ],
                  }),
                  el("button", {
                    className: "question-bank-card__delete",
                    text: "刪除",
                    attrs: { type: "button" },
                    on: { click: () => onDeleteQuestion(question.id) },
                  }),
                ],
              }),
            ),
          })
        : el("p", {
            className: "question-bank__empty",
            text: "還沒有題目，可以先新增一張題卡。",
          }),
    ],
  });
}

function renderField(label, children) {
  return el("label", {
    className: "question-field",
    children: [el("span", { text: label }), ...children],
  });
}

function splitChoices(value) {
  return String(value || "")
    .split(/[｜|,，\n]/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 6);
}

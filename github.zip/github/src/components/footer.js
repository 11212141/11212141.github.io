import { el } from "../utils/dom.js";

export function renderFooter() {
  const footer = el("div", { className: "footer" });
  const inner = el("div", {
    className: "container footer__inner",
    children: [
      el("div", {
        className: "footer-note",
        children: [
          el("strong", { text: "AiDigital 數位學伴教學站" }),
          el("span", { text: "一起上課吧" }),
        ],
      }),
    ],
  });

  footer.append(inner);
  return footer;
}

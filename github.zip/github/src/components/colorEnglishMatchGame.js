import { el, sectionTitle } from "../utils/dom.js";

export function renderColorEnglishMatchGame({
  challenge,
  gameState,
  targetColor,
  options,
  onChooseEnglish,
  onNextRound,
  onResetGame,
}) {
  const section = el("section", { className: "panel", attrs: { id: "color-english-game" } });

  section.append(
    el("div", {
      className: "panel__content",
      children: [
        sectionTitle(challenge.englishGame.title, challenge.englishGame.subtitle, el("span", {
          className: "badge badge--warm",
          text: challenge.badge,
        })),
        el("div", {
          className: "color-quiz-layout",
          children: [
            renderPlayerBoard(gameState),
            gameState.finished
              ? renderFinish(gameState, "看顏色選英文完成", onResetGame)
              : renderEnglishStage({
                  gameState,
                  targetColor,
                  options,
                  onChooseEnglish,
                  onNextRound,
                  onResetGame,
                }),
          ],
        }),
      ],
    }),
  );

  return section;
}

function renderPlayerBoard(gameState) {
  return el("aside", {
    className: "color-quiz-board",
    children: [
      el("div", {
        className: "color-quiz-board__head",
        children: [
          el("strong", { text: "輪流學生" }),
          el("span", { className: "pill", text: "選英文" }),
        ],
      }),
      el("div", {
        className: "color-quiz-player-list",
        children: gameState.players.map((player, index) =>
          el("div", {
            className: `color-quiz-player-card${index === gameState.activePlayerIndex ? " is-active" : ""}`,
            children: [
              el("div", {
                className: "color-quiz-player-card__top",
                children: [
                  el("strong", { text: player.name }),
                  el("span", { className: "color-quiz-score", text: `${player.score} 分` }),
                ],
              }),
              el("span", {
                className: "color-quiz-player-state",
                text:
                  index === gameState.activePlayerIndex
                    ? gameState.isAnswered
                      ? "本題完成"
                      : "本題作答"
                    : "等待中",
              }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderEnglishStage({ gameState, targetColor, options, onChooseEnglish, onNextRound, onResetGame }) {
  return el("div", {
    className: "color-quiz-stage",
    children: [
      el("div", {
        className: "color-quiz-stage__header",
        children: [
          el("div", {
            className: "color-quiz-stage__copy",
            children: [
              el("span", {
                className: "badge badge--live",
                text: `輪到 ${gameState.players[gameState.activePlayerIndex].name}`,
              }),
              el("h3", { text: "請選出這個顏色的英文" }),
              el("p", { text: "先看顏色，再選正確的英文單字。" }),
            ],
          }),
          el("div", {
            className: "button-row",
            children: [
              el("button", {
                className: "button button--ghost",
                text: "重新開始",
                attrs: { type: "button" },
                on: { click: onResetGame },
              }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "color-quiz-topline",
        children: [
          renderTargetColorCard(targetColor, gameState),
          renderTaskCard(gameState),
        ],
      }),
      el("div", {
        className: "color-english-option-grid",
        children: options.map((color) =>
          renderEnglishOption({
            color,
            isSelected: gameState.selectedColorId === color.id,
            isCorrect: gameState.lastResult?.targetColorId === color.id,
            isWrong:
              gameState.isAnswered &&
              gameState.selectedColorId === color.id &&
              gameState.lastResult?.targetColorId !== color.id,
            disabled: gameState.isAnswered,
            onClick: () => onChooseEnglish(color.id),
          }),
        ),
      }),
      renderEnglishFeedback(options, gameState, targetColor),
      renderNextButton(gameState, onNextRound),
    ],
  });
}

function renderTargetColorCard(targetColor, gameState) {
  return el("article", {
    className: "color-quiz-card color-quiz-card--target",
    attrs: { style: `--swatch:${targetColor.swatch}; --swatch-border:${targetColor.border ?? "rgba(34, 106, 117, 0.08)"};` },
    children: [
      el("span", { className: "pill", text: `第 ${gameState.roundIndex + 1} 題` }),
      el("div", { className: "color-quiz-card__swatch" }),
      el("strong", { text: targetColor.chinese }),
      el("p", { text: "請選出正確英文。" }),
    ],
  });
}

function renderTaskCard(gameState) {
  return el("article", {
    className: "color-quiz-card",
    children: [
      el("span", { className: "pill", text: "英文配對" }),
      el("strong", { text: `第 ${gameState.roundIndex + 1} / ${gameState.totalRounds} 題` }),
      el("p", { text: "看色塊，選出對應的英文。" }),
    ],
  });
}

function renderEnglishOption({ color, isSelected, isCorrect, isWrong, disabled, onClick }) {
  let className = "color-english-option color-english-option--plain";

  if (isSelected && !disabled) {
    className += " is-active";
  }

  if (isCorrect && disabled) {
    className += " is-correct";
  } else if (isWrong) {
    className += " is-wrong";
  }

  return el("button", {
    className,
    attrs: {
      type: "button",
      disabled: disabled ? "disabled" : null,
    },
    on: { click: onClick },
    children: [
      el("strong", { text: color.english }),
    ],
  });
}

function renderEnglishFeedback(options, gameState, targetColor) {
  if (!gameState.isAnswered || !gameState.lastResult) {
    return el("div", {
      className: "color-quiz-feedback",
      children: [el("p", { text: "選完英文後就會揭曉答案。" })],
    });
  }

  if (gameState.lastResult.isCorrect) {
    return el("div", {
      className: "color-quiz-feedback is-success",
      children: [
        el("strong", { text: "答對了" }),
        el("p", { text: `${targetColor.chinese} 的英文是 ${targetColor.english}。` }),
      ],
    });
  }

  const selectedColor = options.find((color) => color.id === gameState.lastResult.selectedColorId) ?? null;

  return el("div", {
    className: "color-quiz-feedback is-retry",
    children: [
      el("strong", { text: "這題揭曉了" }),
      el("p", { text: `你選的是 ${selectedColor?.english ?? "這個英文"}，正確答案是 ${targetColor.english}。` }),
    ],
  });
}

function renderNextButton(gameState, onNextRound) {
  if (!gameState.isAnswered) {
    return null;
  }

  return el("div", {
    className: "color-quiz-actions",
    children: [
      el("button", {
        className: "button button--primary",
        text: gameState.roundIndex === gameState.totalRounds - 1 ? "看結果" : "下一題",
        attrs: { type: "button" },
        on: { click: onNextRound },
      }),
    ],
  });
}

function renderFinish(gameState, title, onResetGame) {
  const winner = [...gameState.players].sort((left, right) => right.score - left.score)[0];

  return el("div", {
    className: "color-quiz-stage",
    children: [
      el("div", {
        className: "color-quiz-finish",
        children: [
          el("span", { className: "badge badge--warm", text: "完成" }),
          el("h3", { text: title }),
          el("p", { text: `${winner.name} 目前 ${winner.score} 分` }),
        ],
      }),
      el("div", {
        className: "color-quiz-result-grid",
        children: gameState.players.map((player) =>
          el("div", {
            className: "color-quiz-result-card",
            children: [
              el("strong", { text: player.name }),
              el("span", { className: "color-quiz-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("button", {
        className: "button button--primary",
        text: "再玩一次",
        attrs: { type: "button" },
        on: { click: onResetGame },
      }),
    ],
  });
}

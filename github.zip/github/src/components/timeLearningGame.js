import { flattenAnswer, formatValue, renderUnitVertical } from "./capacityCalculationGame.js?v=20260509-time1";
import { el, sectionTitle } from "../utils/dom.js";

export function renderTimeLearningGame({
  challenge,
  state,
  onSetMode,
  onChooseClockDigit,
  onSelectClockSlot,
  onClearClock,
  onSubmitClock,
  onNextClock,
  onAdjustClock,
  onResetClockHands,
  onToggleClockHand,
  onSetClockTime,
  onChooseConversion,
  onNextConversion,
  onChooseCalcDigit,
  onSelectCalcSlot,
  onClearCalc,
  onSubmitCalc,
  onNextCalc,
}) {
  return el("section", {
    className: "panel",
    attrs: { id: "time-learning-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle(challenge.title, "", el("span", { className: "badge badge--live", text: challenge.badge })),
          renderModeTabs(state.mode, onSetMode),
          state.mode === "clock"
            ? renderClockGame({
                challenge,
                state,
                onChooseClockDigit,
                onSelectClockSlot,
                onClearClock,
                onSubmitClock,
                onNextClock,
                onAdjustClock,
                onResetClockHands,
                onToggleClockHand,
                onSetClockTime,
              })
            : null,
          state.mode === "conversion"
            ? renderConversionGame({ challenge, state, onChooseConversion, onNextConversion })
            : null,
          state.mode === "calculation"
            ? renderCalculationGame({ challenge, state, onChooseCalcDigit, onSelectCalcSlot, onClearCalc, onSubmitCalc, onNextCalc })
            : null,
        ],
      }),
    ],
  });
}

function renderModeTabs(activeMode, onSetMode) {
  const modes = [
    { id: "clock", label: "看時鐘" },
    { id: "conversion", label: "時間換算" },
    { id: "calculation", label: "時間直式" },
  ];

  return el("div", {
    className: "decimal-mode-switch",
    children: modes.map((mode) =>
      el("button", {
        className: `button ${activeMode === mode.id ? "button--primary" : "button--secondary"}`,
        text: mode.label,
        attrs: { type: "button" },
        on: { click: () => onSetMode(mode.id) },
      }),
    ),
  });
}

function renderClockGame({
  challenge,
  state,
  onChooseClockDigit,
  onSelectClockSlot,
  onClearClock,
  onSubmitClock,
  onNextClock,
  onAdjustClock,
  onResetClockHands,
  onToggleClockHand,
  onSetClockTime,
}) {
  const round = challenge.clockRounds[state.clockRoundIndex];
  const clockTime = state.clockTime ?? round;
  const answerParts = getClockAnswerParts(clockTime, state.clockHands);
  const answer = formatClockAnswerParts(answerParts);
  const hasVisibleHands = answerParts.length > 0;
  const canSubmit = hasVisibleHands && state.clockAnswer.every((digit) => digit !== "") && !state.clockAnswered;

  return el("article", {
    className: "length-game-card time-card",
    children: [
      renderCardHead("遊戲一：看時鐘填時間", `第 ${state.clockRoundIndex + 1} / ${challenge.clockRounds.length} 題`),
      el("div", {
        className: "time-clock-layout",
        children: [
          el("div", {
            className: "time-clock-stage",
            children: [
              renderAnalogClock(clockTime, state.clockAnswered, onSetClockTime, state.clockHands),
              renderClockHandToggles(state.clockHands, onToggleClockHand),
              renderClockControls(state.clockAnswered, onAdjustClock, onResetClockHands),
            ],
          }),
          el("div", {
            className: "time-answer-panel",
            children: [
              el("strong", { text: hasVisibleHands ? `請填出${answerParts.map((part) => part.label).join("、")}` : "請先開啟指針" }),
              renderClockSlots(state, onSelectClockSlot, answerParts),
              hasVisibleHands ? renderDigitPad(state.clockAnswered, onChooseClockDigit) : null,
            ],
          }),
        ],
      }),
      renderClockFeedback(state.clockResult, answer),
      renderActions([
        { label: "清除", style: "button--secondary", disabled: state.clockAnswered, action: onClearClock },
        { label: "確認答案", style: "button--primary", disabled: !canSubmit, action: onSubmitClock },
        {
          label: state.clockRoundIndex === challenge.clockRounds.length - 1 ? "回到第一題" : "下一題",
          style: "button--ghost",
          disabled: !state.clockAnswered,
          action: onNextClock,
        },
      ]),
    ],
  });
}

function renderClockHandToggles(clockHands = {}, onToggleClockHand) {
  const hands = [
    { key: "hour", label: "時針", tone: "hour" },
    { key: "minute", label: "分針", tone: "minute" },
    { key: "second", label: "秒針", tone: "second" },
  ];

  return el("div", {
    className: "time-hand-toggle",
    children: hands.map((hand) => {
      const isVisible = clockHands[hand.key] !== false;

      return el("button", {
        className: `time-hand-toggle__button time-hand-toggle__button--${hand.tone}${isVisible ? " is-active" : ""}`,
        attrs: {
          type: "button",
          "aria-pressed": isVisible ? "true" : "false",
        },
        children: [
          el("span", { className: "time-hand-toggle__dot" }),
          el("span", { className: "time-hand-toggle__name", text: hand.label }),
          el("span", { className: "time-hand-toggle__state", text: isVisible ? "顯示" : "隱藏" }),
        ],
        on: {
          click: (event) => {
            event.preventDefault();
            event.stopPropagation();
            onToggleClockHand(hand.key);
          },
        },
      });
    }),
  });
}

function renderClockControls(answered, onAdjustClock, onResetClockHands) {
  const controls = [
    { label: "時針 +1", unit: "hour", amount: 1 },
    { label: "分針 +5", unit: "minute", amount: 5 },
    { label: "秒針 +5", unit: "second", amount: 5 },
  ];

  return el("div", {
    className: "time-clock-controls",
    children: [
      ...controls.map((control) =>
        el("button", {
          className: "button button--secondary",
          text: control.label,
          attrs: { type: "button", disabled: answered ? "disabled" : null },
          on: { click: () => onAdjustClock(control.unit, control.amount) },
        }),
      ),
      el("button", {
        className: "button button--ghost",
        text: "重設時鐘",
        attrs: { type: "button", disabled: answered ? "disabled" : null },
        on: { click: onResetClockHands },
      }),
    ],
  });
}

function renderConversionGame({ challenge, state, onChooseConversion, onNextConversion }) {
  const round = challenge.conversionRounds[state.conversionRoundIndex];

  return el("article", {
    className: "length-game-card",
    children: [
      renderCardHead("遊戲二：小時分鐘秒鐘", `第 ${state.conversionRoundIndex + 1} / ${challenge.conversionRounds.length} 題`),
      el("div", { className: "length-prompt-card", children: [el("strong", { text: round.prompt })] }),
      el("div", {
        className: "length-choice-grid",
        children: round.options.map((option) =>
          el("button", {
            className: getChoiceClass(option, round.answer, state.conversionSelected, state.conversionResult),
            text: option,
            attrs: { type: "button", disabled: state.conversionResult ? "disabled" : null },
            on: { click: () => onChooseConversion(option) },
          }),
        ),
      }),
      renderChoiceFeedback(state.conversionResult, round.answer),
      renderActions([
        {
          label: state.conversionRoundIndex === challenge.conversionRounds.length - 1 ? "回到第一題" : "下一題",
          style: "button--primary",
          disabled: !state.conversionResult,
          action: onNextConversion,
        },
      ]),
    ],
  });
}

function renderCalculationGame({ challenge, state, onChooseCalcDigit, onSelectCalcSlot, onClearCalc, onSubmitCalc, onNextCalc }) {
  const round = challenge.calculationRounds[state.calcRoundIndex];
  const canSubmit = state.calcAnswer.every((digit) => digit !== "") && !state.calcAnswered;

  return el("article", {
    className: "length-game-card",
    children: [
      renderCardHead("遊戲三：時間直式計算", `第 ${state.calcRoundIndex + 1} / ${challenge.calculationRounds.length} 題`),
      el("div", {
        className: "length-question-board",
        children: [
          el("strong", {
            className: "length-expression",
            text: `${formatValue(round.top, challenge.columns)} ${round.operator} ${formatValue(round.bottom, challenge.columns)} = ?`,
          }),
          renderUnitVertical({
            columns: challenge.columns,
            round,
            answer: state.calcAnswered ? flattenAnswer(round.answer, challenge.columns) : state.calcAnswer,
            activeSlot: state.calcActiveSlot,
            answered: state.calcAnswered,
            onSelectSlot: onSelectCalcSlot,
          }),
        ],
      }),
      renderDigitPad(state.calcAnswered, onChooseCalcDigit),
      renderCalculationFeedback(state.calcResult, round, challenge.columns),
      renderActions([
        { label: "清除", style: "button--secondary", disabled: state.calcAnswered, action: onClearCalc },
        { label: "確認答案", style: "button--primary", disabled: !canSubmit, action: onSubmitCalc },
        {
          label: state.calcRoundIndex === challenge.calculationRounds.length - 1 ? "回到第一題" : "下一題",
          style: "button--ghost",
          disabled: !state.calcAnswered,
          action: onNextCalc,
        },
      ]),
    ],
  });
}

function renderAnalogClock(round, answered, onSetClockTime, clockHands = {}) {
  const hourAngle = ((round.hour % 12) * 30) + round.minute * 0.5 + round.second / 120;
  const minuteAngle = round.minute * 6 + round.second * 0.1;
  const secondAngle = round.second * 6;
  const readout = el("span", { className: "time-clock__readout", text: "" });
  const hourHand = el("span", {
    className: `time-clock__hand time-clock__hand--hour${clockHands.hour === false ? " is-hidden" : ""}`,
    attrs: { style: `--hand-angle:${hourAngle}deg;`, "data-hand": "hour" },
  });
  const minuteHand = el("span", {
    className: `time-clock__hand time-clock__hand--minute${clockHands.minute === false ? " is-hidden" : ""}`,
    attrs: { style: `--hand-angle:${minuteAngle}deg;`, "data-hand": "minute" },
  });
  const secondHand = el("span", {
    className: `time-clock__hand time-clock__hand--second${clockHands.second === false ? " is-hidden" : ""}`,
    attrs: { style: `--hand-angle:${secondAngle}deg;`, "data-hand": "second" },
  });

  const clock = el("div", {
    className: "time-clock",
    children: [
      ...Array.from({ length: 60 }, (_, index) =>
        el("span", {
          className: `time-clock__tick${index % 5 === 0 ? " time-clock__tick--major" : ""}`,
          attrs: { style: `--tick-angle:${index * 6}deg;` },
        }),
      ),
      ...Array.from({ length: 12 }, (_, index) => {
        const number = index + 1;
        const angle = number * 30;
        return el("span", {
          className: "time-clock__number",
          text: String(number),
          attrs: { style: `--clock-angle:${angle}deg;` },
        });
      }),
      hourHand,
      minuteHand,
      secondHand,
      el("span", { className: "time-clock__pin" }),
    ],
  });

  if (!answered) {
    enableClockDrag(clock, round, onSetClockTime, readout, { hourHand, minuteHand, secondHand }, clockHands);
  }

  return clock;
}

function enableClockDrag(clock, initialTime, onSetClockTime, readout, hands, clockHands = {}) {
  let activeHand = "";
  let currentTime = { ...initialTime };

  const updateFromPointer = (event) => {
    const angle = getClockPointerAngle(clock, event);

    if (activeHand === "hour") {
      const hour = Math.round(angle / 30) || 12;
      currentTime = { ...currentTime, hour };
    } else if (activeHand === "second") {
      currentTime = { ...currentTime, second: Math.round(angle / 6) % 60 };
    } else {
      currentTime = { ...currentTime, minute: Math.round(angle / 6) % 60 };
    }

    updateClockView(currentTime, readout, hands);
    onSetClockTime(currentTime);
  };

  clock.addEventListener("pointerdown", (event) => {
    activeHand = event.target.dataset?.hand || getDefaultClockHand(clockHands);
    if (!activeHand) {
      return;
    }

    clock.setPointerCapture(event.pointerId);
    updateFromPointer(event);
  });

  clock.addEventListener("pointermove", (event) => {
    if (!activeHand) {
      return;
    }

    updateFromPointer(event);
  });

  clock.addEventListener("pointerup", (event) => {
    activeHand = "";
    clock.releasePointerCapture(event.pointerId);
  });

  clock.addEventListener("pointercancel", () => {
    activeHand = "";
  });
}

function getDefaultClockHand(clockHands = {}) {
  if (clockHands.minute !== false) {
    return "minute";
  }

  if (clockHands.hour !== false) {
    return "hour";
  }

  if (clockHands.second !== false) {
    return "second";
  }

  return "";
}

function getClockPointerAngle(clock, event) {
  const rect = clock.getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  const radians = Math.atan2(event.clientY - centerY, event.clientX - centerX);
  return (radians * 180) / Math.PI + 90 < 0
    ? (radians * 180) / Math.PI + 450
    : (radians * 180) / Math.PI + 90;
}

function updateClockView(time, readout, { hourHand, minuteHand, secondHand }) {
  const hourAngle = ((time.hour % 12) * 30) + time.minute * 0.5 + time.second / 120;
  const minuteAngle = time.minute * 6 + time.second * 0.1;
  const secondAngle = time.second * 6;

  hourHand.style.setProperty("--hand-angle", `${hourAngle}deg`);
  minuteHand.style.setProperty("--hand-angle", `${minuteAngle}deg`);
  secondHand.style.setProperty("--hand-angle", `${secondAngle}deg`);
}

function renderClockSlots(state, onSelectClockSlot, answerParts) {
  if (!answerParts.length) {
    return el("p", { className: "decimal-feedback", text: "開啟至少一根指針後，再讓學生填時間。" });
  }

  let digitIndex = 0;

  const groups = answerParts.map((part) =>
    el("div", {
      className: "time-slot-group",
      children: [
        el("span", { className: "time-slot-group__label", text: part.label }),
        el("div", {
          className: "time-slot-group__digits",
          children: part.digits.map((expectedDigit) => {
            const currentIndex = digitIndex;
            const digit = state.clockAnswered ? expectedDigit : state.clockAnswer[currentIndex] ?? "";
            digitIndex += 1;

            return el("button", {
              className: `time-slot${state.clockActiveSlot === currentIndex && !state.clockAnswered ? " is-active" : ""}`,
              text: digit || "□",
              attrs: { type: "button", disabled: state.clockAnswered ? "disabled" : null },
              on: { click: () => onSelectClockSlot(currentIndex) },
            });
          }),
        }),
      ],
    }),
  );

  return el("div", {
    className: "time-slots time-slots--grouped",
    children: groups.flatMap((group, index) =>
      index < groups.length - 1 ? [group, el("span", { className: "time-colon time-colon--grouped", text: ":" })] : [group],
    ),
  });
}

function renderDigitPad(answered, onChooseDigit) {
  return el("div", {
    className: "decimal-digit-pad",
    children: Array.from({ length: 10 }, (_, digit) =>
      el("button", {
        className: "decimal-digit-button",
        text: String(digit),
        attrs: { type: "button", disabled: answered ? "disabled" : null },
        on: { click: () => onChooseDigit(digit) },
      }),
    ),
  });
}

function renderClockFeedback(result, answer) {
  if (!result) {
    return null;
  }

  return el("p", {
    className: `decimal-feedback ${result.isCorrect ? "is-correct" : "is-wrong"}`,
    text: result.isCorrect ? `答對了，時間是 ${answer}。` : `再看一次，時間是 ${answer}。`,
  });
}

function formatClockAnswer(time) {
  return `${String(time.hour).padStart(2, "0")}:${String(time.minute).padStart(2, "0")}:${String(time.second).padStart(2, "0")}`;
}

function getClockAnswerParts(time, clockHands = {}) {
  return [
    { key: "hour", label: "時", value: time.hour },
    { key: "minute", label: "分", value: time.minute },
    { key: "second", label: "秒", value: time.second },
  ]
    .filter((part) => clockHands[part.key] !== false)
    .map((part) => ({
      ...part,
      digits: String(part.value).padStart(2, "0").split(""),
    }));
}

function formatClockAnswerParts(parts) {
  return parts.map((part) => `${part.digits.join("")}${part.label}`).join(" ");
}

function renderChoiceFeedback(result, answer) {
  if (!result) {
    return el("p", { className: "decimal-feedback", text: "選一個答案。" });
  }

  return el("p", {
    className: `decimal-feedback ${result.isCorrect ? "is-correct" : "is-wrong"}`,
    text: result.isCorrect ? "答對了。" : `再想想，答案是 ${answer}。`,
  });
}

function renderCalculationFeedback(result, round, columns) {
  if (!result) {
    return el("p", { className: "decimal-feedback", text: "時對時、分對分、秒對秒。" });
  }

  const answer = formatValue(round.answer, columns);
  return el("p", {
    className: `decimal-feedback ${result.isCorrect ? "is-correct" : "is-wrong"}`,
    text: result.isCorrect ? `答對了，答案是 ${answer}。` : `再看一次單位，答案是 ${answer}。`,
  });
}

function renderCardHead(title, badgeText) {
  return el("div", {
    className: "length-game-card__head",
    children: [
      el("div", {
        children: [
          el("span", { className: "badge badge--warm", text: badgeText }),
          el("h3", { text: title }),
        ],
      }),
    ],
  });
}

function renderActions(actions) {
  return el("div", {
    className: "number-game-actions",
    children: actions.map((action) =>
      el("button", {
        className: `button ${action.style}`,
        text: action.label,
        attrs: { type: "button", disabled: action.disabled ? "disabled" : null },
        on: { click: action.action },
      }),
    ),
  });
}

function getChoiceClass(option, answer, selected, result) {
  const isSelected = option === selected;
  const isCorrect = result && option === answer;
  const isWrong = result && isSelected && option !== answer;
  return `length-choice-button${isSelected ? " is-selected" : ""}${isCorrect ? " is-correct" : ""}${isWrong ? " is-wrong" : ""}`;
}

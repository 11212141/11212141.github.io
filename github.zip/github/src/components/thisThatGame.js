import { el, sectionTitle } from "../utils/dom.js";

export function renderThisThatGame({
  challenge,
  state,
  onSelectPlayer,
  onPickCard,
  onChooseAnswer,
  onNextRound,
  onResetGame,
}) {
  return el("section", {
    className: "panel this-that-panel this-that-cardplay-panel",
    attrs: { id: "this-that-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("這那搜查隊", "", el("span", { className: "badge badge--live", text: challenge.badge })),
          state.finished
            ? renderFinished(state, onResetGame)
            : renderCardRound({ challenge, state, onSelectPlayer, onPickCard, onChooseAnswer, onNextRound, onResetGame }),
        ],
      }),
    ],
  });
}

function renderCardRound({ challenge, state, onSelectPlayer, onPickCard, onChooseAnswer, onNextRound, onResetGame }) {
  const round = state.currentRoundIndex === null ? null : challenge.rounds[state.currentRoundIndex] ?? challenge.rounds[0];
  const activePlayer = state.players[state.activePlayerIndex];

  return el("article", {
    className: "this-that-cardplay",
    children: [
      el("div", {
        className: "this-that-head",
        children: [
          renderPlayerRow(state, onSelectPlayer),
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button" },
            on: { click: onResetGame },
          }),
        ],
      }),
      el("div", {
        className: "this-that-cardplay-layout",
        children: [
          el("section", {
            className: "this-that-search-area",
            children: [
              el("div", {
                className: "this-that-search-title",
                children: [
                  el("span", { className: "badge badge--warm", text: `輪到 ${activePlayer.name}` }),
                  el("strong", { text: "選一張搜查卡" }),
                  el("span", { className: "pill", text: `${activePlayer.score} 分` }),
                ],
              }),
              renderSearchCards({ challenge, state, onPickCard }),
              renderPatternStrip(),
            ],
          }),
          el("aside", {
            className: "this-that-case-card",
            children: [
              renderCaseCard({ state, round, onChooseAnswer, onNextRound }),
              el("p", {
                className: "this-that-progress-note",
                text: `回合 ${state.roundIndex + 1} / 16・連續答對 ${state.correctStreak} 題`,
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderSearchCards({ challenge, state, onPickCard }) {
  const labels = ["A", "B", "C", "D"];
  return el("div", {
    className: "this-that-search-grid",
    children: state.cardOptions.map((roundIndex, index) => {
      const round = challenge.rounds[roundIndex] ?? challenge.rounds[0];
      const isSelected = state.selectedCardIndex === index;
      const isLocked = state.selectedCardIndex !== null;
      return el("button", {
        className: `this-that-search-card${isSelected ? " is-selected" : ""}${isLocked && !isSelected ? " is-muted" : ""}`,
        attrs: { type: "button", disabled: isLocked ? "disabled" : null },
        on: { click: () => onPickCard(index) },
        children: [
          el("span", { className: "this-that-search-card__label", text: labels[index] }),
          isSelected
            ? el("div", {
                className: "this-that-search-card__open",
                children: [
                  el("span", { text: round.distance === "this" ? "近" : "遠" }),
                  renderPicture(round),
                  el("strong", { text: round.distance === "this" ? "this" : "that" }),
                ],
              })
            : el("div", {
                className: "this-that-search-card__cover",
                children: [el("strong", { text: "?" }), el("span", { text: "搜查卡" })],
              }),
        ],
      });
    }),
  });
}

function renderCaseCard({ state, round, onChooseAnswer, onNextRound }) {
  if (!round) {
    return el("div", {
      className: "this-that-clue-card is-covered",
      children: [
        el("span", { text: "任務卡" }),
        el("strong", { text: "先翻搜查卡" }),
      ],
    });
  }

  const isYesRound = round.item === round.guess;
  const question = round.distance === "this" ? "What is this?" : "What is that?";
  const yesSentence = `Yes, it is. It is ${formatNoun(round.article, round.item)}.`;
  const noSentence = `No, it isn’t. It is ${formatNoun(round.article, round.item)}.`;

  return el("div", {
    className: "this-that-clue-card",
    children: [
      el("div", {
        className: "this-that-card-headline",
        children: [
          el("span", { className: "badge badge--warm", text: round.distance === "this" ? "this 近" : "that 遠" }),
          el("strong", { text: question }),
        ],
      }),
      el("div", {
        className: `this-that-picture-card is-${round.distance}`,
        children: [
          el("span", { className: "this-that-distance-chip", text: round.distance === "this" ? "this 近" : "that 遠" }),
          renderPicture(round),
        ],
      }),
      el("div", {
        className: "this-that-question-bubble",
        children: [
          el("span", { text: "再猜猜看" }),
          el("strong", { text: `Is it ${formatNoun(round.guessArticle, round.guess)}?` }),
        ],
      }),
      el("div", {
        className: "this-that-answer-grid",
        children: [
          answerButton("yes", "Yes, it is.", "是這個", state, isYesRound, onChooseAnswer),
          answerButton("no", "No, it isn’t.", "不是這個", state, isYesRound, onChooseAnswer),
        ],
      }),
      renderFeedback({ state, isYesRound, yesSentence, noSentence }),
      el("button", {
        className: "button button--primary button--full",
        text: state.roundIndex >= 15 ? "看結果" : "下一張搜查卡",
        attrs: { type: "button", disabled: state.isAnswered ? null : "disabled" },
        on: { click: onNextRound },
      }),
    ],
  });
}

function renderPicture(round) {
  if (!round.visual) {
    return el("div", { className: "this-that-picture", text: round.emoji });
  }

  return el("div", {
    className: "this-that-picture",
    children: [
      el("div", {
        className: `this-that-color-object this-that-color-object--${round.visual.shape}`,
        attrs: { style: `--object-color:${round.visual.color};` },
        children: [
          el("span", { className: "this-that-color-object__main" }),
          el("span", { className: "this-that-color-object__accent" }),
        ],
      }),
    ],
  });
}

function answerButton(value, label, doorLabel, state, isYesRound, onChooseAnswer) {
  const isSelected = state.selectedAnswer === value;
  const isCorrectChoice = (value === "yes") === isYesRound;

  return el("button", {
    className: `this-that-answer${isSelected ? " is-selected" : ""}${state.isAnswered && isCorrectChoice ? " is-correct" : ""}${state.isAnswered && isSelected && !isCorrectChoice ? " is-wrong" : ""}`,
    attrs: { type: "button", disabled: state.isAnswered ? "disabled" : null },
    on: { click: () => onChooseAnswer(value) },
    children: [
      el("span", { text: doorLabel }),
      el("strong", { text: label }),
    ],
  });
}

function renderFeedback({ state, isYesRound, yesSentence, noSentence }) {
  if (!state.isAnswered) {
    return el("p", { className: "this-that-feedback", text: "先判斷 Yes 或 No，答完再把完整句念出來。" });
  }

  const sentence = isYesRound ? yesSentence : noSentence;
  const bonus = state.lastResult?.streakBonus ? " 連續答對加 1 分。" : "";
  return el("p", {
    className: `this-that-feedback ${state.lastResult?.isCorrect ? "is-correct" : "is-wrong"}`,
    text: `${sentence}${bonus}`,
  });
}

function renderPlayerRow(state, onSelectPlayer) {
  return el("div", {
    className: "this-that-player-row",
    children: state.players.map((player, index) =>
      el("button", {
        className: `this-that-player${index === state.activePlayerIndex ? " is-active" : ""}`,
        attrs: { type: "button", disabled: state.selectedCardIndex !== null ? "disabled" : null },
        on: { click: () => onSelectPlayer(index) },
        children: [el("strong", { text: player.name }), el("span", { text: `${player.score} 分` })],
      }),
    ),
  });
}

function renderPatternStrip() {
  return el("div", {
    className: "this-that-pattern-strip",
    children: [
      el("span", { text: "What is this?" }),
      el("span", { text: "What is that?" }),
      el("span", { text: "Is it a ___ ?" }),
    ],
  });
}

function renderFinished(state, onResetGame) {
  return el("article", {
    className: "this-that-finished",
    children: [
      el("h3", { text: "搜查任務完成" }),
      el("div", {
        className: "this-that-result-grid",
        children: state.players.map((player) =>
          el("div", {
            className: "this-that-result-card",
            children: [el("strong", { text: player.name }), el("span", { text: `${player.score} 分` })],
          }),
        ),
      }),
      el("button", { className: "button button--primary", text: "再玩一次", attrs: { type: "button" }, on: { click: onResetGame } }),
    ],
  });
}

function formatNoun(article, noun) {
  return article ? `${article} ${noun}` : noun;
}

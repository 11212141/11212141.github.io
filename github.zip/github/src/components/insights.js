import { el, sectionTitle } from "../utils/dom.js";

export function renderInsights(cards) {
  const section = el("section", { className: "panel panel--compact", attrs: { id: "principles" } });

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(
        "今天帶課提醒",
        "第一次見面最重要的不是說很多，而是讓每位孩子都有舒服參與、被接住的感覺。",
      ),
      el("div", {
        className: "insight-strip",
        children: cards.map((card) =>
          el("article", {
            className: "insight-card",
            html: `<strong>${card.title}</strong><h3>${card.value}</h3><p>${card.note}</p>`,
          }),
        ),
      }),
    ],
  });

  section.append(content);
  return section;
}

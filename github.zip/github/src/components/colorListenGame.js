import { el, sectionTitle } from "../utils/dom.js";

export function renderColorListenGame({
  challenge,
  gameState,
  onChooseColor,
  onRevealColor,
  onNextRound,
  onResetGame,
}) {
  const section = el("section", { className: "panel", attrs: { id: "color-listen-game" } });

  section.append(
    el("div", {
      className: "panel__content",
      children: [
        sectionTitle(challenge.listenGame.title, challenge.listenGame.subtitle, el("span", {
          className: "badge badge--warm",
          text: challenge.badge,
        })),
        el("div", {
          className: "color-quiz-layout",
          children: [
            renderQuizPlayerBoard(gameState, "聽顏色"),
            gameState.finished
              ? renderQuizFinish(gameState, "聽顏色完成", onResetGame)
              : renderListenStage({
                  challenge,
                  gameState,
                  onChooseColor,
                  onRevealColor,
                  onNextRound,
                  onResetGame,
                }),
          ],
        }),
      ],
    }),
  );

  return section;
}

function renderQuizPlayerBoard(gameState, badgeText) {
  return el("aside", {
    className: "color-quiz-board",
    children: [
      el("div", {
        className: "color-quiz-board__head",
        children: [
          el("strong", { text: "輪流學生" }),
          el("span", { className: "pill", text: badgeText }),
        ],
      }),
      el("div", {
        className: "color-quiz-player-list",
        children: gameState.players.map((player, index) =>
          el("div", {
            className: `color-quiz-player-card${index === gameState.activePlayerIndex ? " is-active" : ""}`,
            children: [
              el("div", {
                className: "color-quiz-player-card__top",
                children: [
                  el("strong", { text: player.name }),
                  el("span", { className: "color-quiz-score", text: `${player.score} 分` }),
                ],
              }),
              el("span", {
                className: "color-quiz-player-state",
                text:
                  index === gameState.activePlayerIndex
                    ? gameState.isAnswered
                      ? "本題完成"
                      : "本題作答"
                    : "等待中",
              }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderListenStage({ challenge, gameState, onChooseColor, onRevealColor, onNextRound, onResetGame }) {
  return el("div", {
    className: "color-quiz-stage",
    children: [
      el("div", {
        className: "color-quiz-stage__header",
        children: [
          el("div", {
            className: "color-quiz-stage__copy",
            children: [
              el("span", {
                className: "badge badge--live",
                text: `輪到 ${gameState.players[gameState.activePlayerIndex].name}`,
              }),
              el("h3", { text: "請聽老師念顏色" }),
              el("p", { text: "學生先選色塊，再由老師揭曉正確顏色。" }),
            ],
          }),
          el("div", {
            className: "button-row",
            children: [
              el("button", {
                className: "button button--ghost",
                text: "重新開始",
                attrs: { type: "button" },
                on: { click: onResetGame },
              }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "color-quiz-topline",
        children: [
          renderListenPromptCard(gameState),
          renderListenStatusCard(challenge, gameState),
        ],
      }),
      el("div", {
        className: "color-quiz-color-grid",
        children: challenge.palette.map((color) =>
          renderColorTile({
            color,
            isSelected: gameState.selectedColorId === color.id,
            isCorrect: gameState.lastResult?.targetColorId === color.id,
            isWrong:
              gameState.isAnswered &&
              gameState.selectedColorId === color.id &&
              gameState.lastResult?.targetColorId !== color.id,
            disabled: gameState.isAnswered,
            onClick: () => onChooseColor(color.id),
          }),
        ),
      }),
      renderRevealPanel(challenge, gameState, onRevealColor),
      renderListenFeedback(challenge, gameState),
      renderNextButton(gameState, onNextRound),
    ],
  });
}

function renderListenPromptCard(gameState) {
  return el("article", {
    className: "color-quiz-card",
    children: [
      el("span", { className: "pill", text: `第 ${gameState.roundIndex + 1} 題` }),
      el("strong", { text: "請先聽老師口令" }),
      el("p", { text: "這一題不先顯示答案，選完後再揭曉。" }),
    ],
  });
}

function renderListenStatusCard(challenge, gameState) {
  if (!gameState.selectedColorId) {
    return el("article", {
      className: "color-quiz-card",
      children: [
        el("span", { className: "pill", text: "聽顏色" }),
        el("strong", { text: `第 ${gameState.roundIndex + 1} / ${gameState.totalRounds} 題` }),
        el("p", { text: "先聽，再選，再揭曉答案。" }),
      ],
    });
  }

  const selectedColor = challenge.palette.find((color) => color.id === gameState.selectedColorId) ?? null;
  const teacherColor = challenge.palette.find((color) => color.id === gameState.teacherColorId) ?? null;

  return el("article", {
    className: "color-quiz-card",
    children: [
      el("span", { className: "pill", text: gameState.isAnswered ? "已揭曉" : "學生已選" }),
      el("strong", { text: gameState.isAnswered ? `答案是 ${teacherColor?.chinese ?? ""}` : `學生選了 ${selectedColor?.chinese ?? ""}` }),
      el("p", {
        text: gameState.isAnswered
          ? "這一題已經公布正確顏色。"
          : "接下來請老師點剛剛真正念到的顏色。",
      }),
    ],
  });
}

function renderColorTile({ color, isSelected, isCorrect, isWrong, disabled, onClick }) {
  let className = "color-quiz-color-tile";

  if (isSelected && !disabled) {
    className += " is-active";
  }

  if (isCorrect && disabled) {
    className += " is-correct";
  } else if (isWrong) {
    className += " is-wrong";
  }

  return el("button", {
    className,
    attrs: {
      type: "button",
      disabled: disabled ? "disabled" : null,
      style: `--swatch:${color.swatch}; --swatch-border:${color.border ?? "rgba(34, 106, 117, 0.1)"};`,
    },
    on: { click: onClick },
    children: [
      el("span", { className: "color-quiz-color-tile__swatch" }),
      el("strong", { text: color.chinese }),
    ],
  });
}

function renderRevealPanel(challenge, gameState, onRevealColor) {
  if (!gameState.selectedColorId) {
    return null;
  }

  return el("article", {
    className: "color-quiz-card color-quiz-reveal-card",
    children: [
      el("div", {
        className: "color-quiz-stage__header",
        children: [
          el("strong", { text: "老師揭曉答案" }),
          el("span", { className: "pill", text: gameState.isAnswered ? "已揭曉" : "請點正確顏色" }),
        ],
      }),
      el("div", {
        className: "color-quiz-color-grid",
        children: challenge.palette.map((color) =>
          renderColorTile({
            color,
            isSelected: gameState.teacherColorId === color.id,
            isCorrect: gameState.teacherColorId === color.id,
            isWrong: false,
            disabled: gameState.isAnswered,
            onClick: () => onRevealColor(color.id),
          }),
        ),
      }),
    ],
  });
}

function renderListenFeedback(challenge, gameState) {
  if (!gameState.isAnswered || !gameState.lastResult) {
    return el("div", {
      className: "color-quiz-feedback",
      children: [el("p", { text: "先讓學生選顏色，再由老師揭曉正確答案。" })],
    });
  }

  const targetColor =
    challenge.palette.find((color) => color.id === gameState.lastResult.targetColorId) ?? null;

  if (gameState.lastResult.isCorrect) {
    return el("div", {
      className: "color-quiz-feedback is-success",
      children: [
        el("strong", { text: "答對了" }),
        el("p", { text: `這題是 ${targetColor.chinese}。` }),
      ],
    });
  }

  const selectedColor = challenge.palette.find((color) => color.id === gameState.lastResult.selectedColorId) ?? null;

  return el("div", {
    className: "color-quiz-feedback is-retry",
    children: [
      el("strong", { text: "這題揭曉了" }),
      el("p", { text: `你選的是 ${selectedColor?.chinese ?? "這個顏色"}，正確答案是 ${targetColor.chinese}。` }),
    ],
  });
}

function renderNextButton(gameState, onNextRound) {
  if (!gameState.isAnswered) {
    return null;
  }

  return el("div", {
    className: "color-quiz-actions",
    children: [
      el("button", {
        className: "button button--primary",
        text: gameState.roundIndex === gameState.totalRounds - 1 ? "看結果" : "下一題",
        attrs: { type: "button" },
        on: { click: onNextRound },
      }),
    ],
  });
}

function renderQuizFinish(gameState, title, onResetGame) {
  const winner = [...gameState.players].sort((left, right) => right.score - left.score)[0];

  return el("div", {
    className: "color-quiz-stage",
    children: [
      el("div", {
        className: "color-quiz-finish",
        children: [
          el("span", { className: "badge badge--warm", text: "完成" }),
          el("h3", { text: title }),
          el("p", { text: `${winner.name} 目前 ${winner.score} 分` }),
        ],
      }),
      el("div", {
        className: "color-quiz-result-grid",
        children: gameState.players.map((player) =>
          el("div", {
            className: "color-quiz-result-card",
            children: [
              el("strong", { text: player.name }),
              el("span", { className: "color-quiz-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("button", {
        className: "button button--primary",
        text: "再玩一次",
        attrs: { type: "button" },
        on: { click: onResetGame },
      }),
    ],
  });
}

import { el, sectionTitle } from "../utils/dom.js";

export function renderDecimalArithmeticGame({
  challenge,
  gameState,
  onSelectPlayer,
  onChooseDigit,
  onDropDigit,
  onSelectAnswerSlot,
  onSetMode,
  onClearDigits,
  onSubmitAnswer,
  onShowProcess,
  onNextProcess,
  onHideProcess,
  onNextRound,
  onSkipRound,
  onResetGame,
}) {
  const section = el("section", { className: "panel", attrs: { id: "decimal-game" } });
  section.append(
    el("div", {
      className: "panel__content",
      children: [
        sectionTitle(challenge.title, "", el("span", { className: "badge badge--live", text: challenge.badge })),
        el("div", {
          className: "decimal-layout",
          children: [
            renderTeachingCard(challenge),
            gameState.finished
              ? renderFinishedCard(gameState, onResetGame)
              : renderGameCard({
                  challenge,
                  gameState,
                  onSelectPlayer,
                  onChooseDigit,
                  onDropDigit,
                  onSelectAnswerSlot,
                  onSetMode,
                  onClearDigits,
                  onSubmitAnswer,
                  onShowProcess,
                  onNextProcess,
                  onHideProcess,
                  onNextRound,
                  onSkipRound,
                  onResetGame,
                }),
          ],
        }),
      ],
    }),
  );

  return section;
}

export function renderDecimalIntroLesson({
  lessonState,
  students = [],
  records = [],
  activeStudentId = "",
  showDashboard = false,
  onSelectDigit = () => {},
  onPlaceDigit = () => {},
  onPlaceSelectedDigit = () => {},
  onSelectStudent = () => {},
  onToggleDashboard = () => {},
  onClearRecords = () => {},
  onSubmitBuild = () => {},
  onNextRound = () => {},
  onReset = () => {},
} = {}) {
  const section = el("section", { className: "panel", attrs: { id: "decimal-intro-lesson" } });
  section.append(
    el("div", {
      className: "panel__content",
      children: [
        sectionTitle("認識小數", "", el("span", { className: "badge badge--live", text: "數學活動" })),
        el("div", {
          className: "decimal-layout decimal-layout--intro-game",
          children: [
            renderDecimalIntroGame({
              lessonState,
              students,
              records,
              activeStudentId,
              showDashboard,
              onSelectDigit,
              onPlaceDigit,
              onPlaceSelectedDigit,
              onSelectStudent,
              onToggleDashboard,
              onClearRecords,
              onSubmitBuild,
              onNextRound,
              onReset,
            }),
          ],
        }),
      ],
    }),
  );

  return section;
}

function renderDecimalIntroGame({
  lessonState,
  students,
  records,
  activeStudentId,
  showDashboard,
  onSelectDigit,
  onPlaceDigit,
  onPlaceSelectedDigit,
  onSelectStudent,
  onToggleDashboard,
  onClearRecords,
  onSubmitBuild,
  onNextRound,
  onReset,
}) {
  const isComplete = lessonState.completed >= lessonState.target;
  const round = lessonState.round;

  if (showDashboard) {
    return el("article", {
      className: "decimal-intro-game decimal-intro-game--admin",
      children: [
        el("div", {
          className: "decimal-admin-page-head",
          children: [
            el("div", {
              children: [
                el("span", { className: "badge badge--live", text: "即時後台" }),
                el("h3", { text: "學生作答總覽" }),
                el("p", { text: "此畫面會自動同步其他裝置送出的作答紀錄。" }),
              ],
            }),
            el("button", {
              className: "button button--secondary decimal-admin-button",
              text: "回到作答",
              attrs: { type: "button" },
              on: { click: onToggleDashboard },
            }),
          ],
        }),
        renderDecimalAdminDashboard({ students, records, target: lessonState.target, onClearRecords }),
      ],
    });
  }

  return el("article", {
    className: "decimal-intro-game",
    children: [
      el("div", {
        className: "decimal-intro-game__top",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: isComplete ? "完成" : "隨機小數" }),
              el("h3", {
                text: isComplete
                  ? `今天完成 ${lessonState.target} 題了`
                  : "拼小數",
              }),
            ],
          }),
          el("div", {
            className: "decimal-intro-game__tools",
            children: [
              renderDecimalIntroProgress(lessonState.completed, lessonState.target),
              el("button", {
                className: "button button--secondary decimal-admin-button",
                text: showDashboard ? "關閉後台" : "後台紀錄",
                attrs: { type: "button" },
                on: { click: onToggleDashboard },
              }),
            ],
          }),
        ],
      }),
      renderDecimalStudentPicker(students, activeStudentId, onSelectStudent),
      isComplete
        ? renderDecimalIntroComplete(onReset)
        : renderDecimalBuildRound({
            round,
            lessonState,
              onSelectDigit,
              onPlaceDigit,
              onPlaceSelectedDigit,
              onSubmitBuild,
            onNextRound,
            onReset,
          }),
    ],
  });
}

function renderDecimalStudentPicker(students, activeStudentId, onSelectStudent) {
  return el("div", {
    className: "decimal-student-picker",
    children: students.map((student) =>
      el("button", {
        className: `decimal-student-chip${student.id === activeStudentId ? " is-active" : ""}`,
        text: student.name,
        attrs: { type: "button" },
        on: { click: () => onSelectStudent(student.id) },
      }),
    ),
  });
}

function renderDecimalAdminDashboard({ students, records, target, onClearRecords }) {
  const totalAttempts = records.length;
  const totalCorrect = records.filter((record) => record.isCorrect).length;
  const totalWrong = totalAttempts - totalCorrect;

  return el("section", {
    className: "decimal-admin-dashboard",
    children: [
      el("div", {
        className: "decimal-admin-dashboard__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: "後台" }),
              el("h4", { text: "作答紀錄" }),
              el("small", { text: "跨裝置即時同步" }),
            ],
          }),
          el("button", {
            className: "button button--ghost",
            text: "清除紀錄",
            attrs: { type: "button" },
            on: { click: onClearRecords },
          }),
        ],
      }),
      el("div", {
        className: "decimal-admin-summary",
        children: [
          renderDecimalAdminSummaryItem("總作答", `${totalAttempts} 次`),
          renderDecimalAdminSummaryItem("答對", `${totalCorrect} 題`),
          renderDecimalAdminSummaryItem("錯題", `${totalWrong} 題`),
        ],
      }),
      el("div", {
        className: "decimal-admin-grid",
        children: students.map((student) => renderDecimalAdminStudentCard(student, records, target)),
      }),
    ],
  });
}

function renderDecimalAdminSummaryItem(label, value) {
  return el("div", {
    className: "decimal-admin-summary__item",
    children: [
      el("span", { text: label }),
      el("strong", { text: value }),
    ],
  });
}

function renderDecimalAdminStudentCard(student, records, target) {
  const attempts = records.filter((record) => record.studentId === student.id);
  const correctCount = attempts.filter((record) => record.isCorrect).length;
  const wrongAttempts = attempts.filter((record) => !record.isCorrect).slice(-4).reverse();
  const completion = Math.min(100, Math.round((correctCount / target) * 100));
  const accuracy = attempts.length ? Math.round((correctCount / attempts.length) * 100) : 0;

  return el("article", {
    className: "decimal-admin-card",
    children: [
      el("div", {
        className: "decimal-admin-card__top",
        children: [
          el("strong", { text: student.name }),
          el("span", { text: `${completion}%` }),
        ],
      }),
      el("div", {
        className: "decimal-admin-meter",
        children: [el("span", { attrs: { style: `width:${completion}%` } })],
      }),
      el("div", {
        className: "decimal-admin-status-grid",
        children: [
          renderDecimalAdminStatus("完成率", `${completion}%`),
          renderDecimalAdminStatus("答對", `${Math.min(correctCount, target)} / ${target}`),
          renderDecimalAdminStatus("正確率", `${accuracy}%`),
          renderDecimalAdminStatus("作答", `${attempts.length} 次`),
        ],
      }),
      el("div", {
        className: "decimal-admin-wrong-list",
        children: [
          el("span", { text: "錯題" }),
          wrongAttempts.length
            ? el("ul", {
                children: wrongAttempts.map((record) =>
                  el("li", {
                    children: [
                      el("strong", { text: record.prompt }),
                      el("span", { text: `作答 ${record.answer}` }),
                      el("span", { text: `答案 ${record.correctAnswer}` }),
                    ],
                  }),
                ),
              })
            : el("small", { text: "目前沒有錯題" }),
        ],
      }),
    ],
  });
}

function renderDecimalAdminStatus(label, value) {
  return el("div", {
    className: "decimal-admin-status",
    children: [
      el("span", { text: label }),
      el("strong", { text: value }),
    ],
  });
}

function renderDecimalIntroProgress(completed, target) {
  return el("div", {
    className: "decimal-intro-progress",
    children: Array.from({ length: target }, (_, index) =>
      el("span", {
        className: index < completed ? "is-done" : "",
        text: index < completed ? "✓" : String(index + 1),
      }),
    ),
  });
}

function renderDecimalIntroComplete(onReset) {
  return el("div", {
    className: "decimal-intro-complete",
    children: [
      el("strong", { text: "完成任務" }),
      el("span", { text: "已完成 5 題，可以換下一位學生或重新開始。" }),
      el("button", {
        className: "button button--primary",
        text: "重新開始",
        attrs: { type: "button" },
        on: { click: onReset },
      }),
    ],
  });
}

function renderDecimalPointRound({ round, lessonState, onFindPoint, onNextRound, onReset }) {
  return el("div", {
    className: "decimal-round decimal-round--point",
    children: [
      el("div", {
        className: "decimal-round-stage",
        children: [
          el("span", { className: "decimal-round-stage__label", text: "請找出小數點" }),
          el("div", {
            className: "decimal-big-number",
            children: [
              el("span", { text: String(round.ones) }),
              el("button", {
                className: `decimal-big-number__point${lessonState.isAnswered ? " is-found" : ""}`,
                text: ".",
                attrs: { type: "button", disabled: lessonState.isAnswered ? "disabled" : null },
                on: { click: onFindPoint },
              }),
              el("span", { text: String(round.tenths) }),
            ],
          }),
        ],
      }),
      renderDecimalIntroFeedback(lessonState),
      renderDecimalIntroActions({ isAnswered: lessonState.isAnswered, onNextRound, onReset }),
    ],
  });
}

function renderDecimalBuildRound({
  round,
  lessonState,
  onSelectDigit,
  onPlaceDigit,
  onPlaceSelectedDigit,
  onSubmitBuild,
  onNextRound,
  onReset,
}) {
  const canSubmit = lessonState.buildDigits.every(Boolean) && !lessonState.isAnswered;

  return el("div", {
    className: "decimal-round decimal-round--build",
    children: [
      el("div", {
        className: "decimal-build-prompt",
        children: [
          el("span", { className: "decimal-round-stage__label", text: "看中文讀法，拼出小數" }),
          el("strong", { text: round.reading }),
          el("small", { text: "請把數字卡放進個位和十分位。" }),
        ],
      }),
      renderDecimalBuildBoard({ lessonState, onPlaceDigit, onPlaceSelectedDigit }),
      renderDecimalChallengeDigitTray({ lessonState, onSelectDigit, onPlaceDigit }),
      renderDecimalIntroFeedback(lessonState),
      el("div", {
        className: "decimal-intro-actions",
        children: [
          el("button", {
            className: "button button--primary",
            text: "確認",
            attrs: {
              type: "button",
              "data-decimal-intro-submit": "true",
              disabled: canSubmit ? null : "disabled",
            },
            on: { click: onSubmitBuild },
          }),
          lessonState.isAnswered
            ? el("button", {
                className: "button button--secondary",
                text: "下一題",
                attrs: { type: "button" },
                on: { click: onNextRound },
              })
            : null,
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button" },
            on: { click: onReset },
          }),
        ],
      }),
    ],
  });
}

function renderDecimalBuildBoard({ lessonState, onPlaceDigit, onPlaceSelectedDigit }) {
  return el("div", {
    className: "decimal-place-table decimal-place-table--practice decimal-place-table--challenge",
    children: [
      renderDecimalBuildCell("個位", 0, lessonState, onPlaceDigit, onPlaceSelectedDigit),
      el("div", {
        className: "is-point",
        children: [el("span", { text: "小數點" }), el("strong", { text: "." })],
      }),
      renderDecimalBuildCell("十分位", 1, lessonState, onPlaceDigit, onPlaceSelectedDigit),
    ],
  });
}

function renderDecimalBuildCell(label, slotIndex, lessonState, onPlaceDigit, onPlaceSelectedDigit) {
  return el("div", {
    children: [
      el("span", { text: label }),
      el("button", {
        className: `decimal-intro-drop-slot${lessonState.buildDigits[slotIndex] ? " is-filled" : ""}`,
        text: lessonState.buildDigits[slotIndex] || "□",
        attrs: {
          type: "button",
          "data-decimal-build-slot": String(slotIndex),
        },
        on: {
          dragenter: (event) => {
            event.preventDefault();
            event.currentTarget.classList.add("is-drop-ready");
          },
          dragover: (event) => event.preventDefault(),
          dragleave: (event) => event.currentTarget.classList.remove("is-drop-ready"),
          drop: (event) => {
            event.preventDefault();
            event.currentTarget.classList.remove("is-drop-ready");
            const digit = event.dataTransfer?.getData("application/x-decimal-challenge-digit");
            if (/^\d$/.test(String(digit))) onPlaceDigit(slotIndex, Number(digit));
          },
          click: () => onPlaceSelectedDigit(slotIndex),
        },
      }),
    ],
  });
}

function renderDecimalChallengeDigitTray({ lessonState, onSelectDigit, onPlaceDigit }) {
  return el("div", {
    className: "decimal-intro-digit-tray decimal-intro-digit-tray--challenge",
    children: Array.from({ length: 10 }, (_, digit) =>
      el("button", {
        className: `decimal-intro-digit${lessonState.selectedDigit === digit ? " is-selected" : ""}`,
        text: String(digit),
        attrs: {
          type: "button",
          draggable: "true",
          "data-decimal-intro-digit": String(digit),
        },
        on: {
          click: () => onSelectDigit(digit),
          dragstart: (event) => {
            event.dataTransfer?.setData("application/x-decimal-challenge-digit", String(digit));
            event.currentTarget.classList.add("is-dragging");
          },
          dragend: (event) => event.currentTarget.classList.remove("is-dragging"),
          pointerdown: (event) => {
            onSelectDigit(digit);
            startDecimalTouchDrag(event, {
              digit,
              sourceClass: "decimal-intro-digit",
              onTap: onSelectDigit,
              onDrop: (target, value) => {
                const slot = target?.closest?.("[data-decimal-build-slot]");
                const slotIndex = Number(slot?.dataset?.decimalBuildSlot);
                if (!Number.isInteger(slotIndex)) return false;
                onPlaceDigit(slotIndex, value);
                return true;
              },
            });
          },
        },
      }),
    ),
  });
}

function renderDecimalIntroFeedback(lessonState) {
  if (lessonState.lastResult === "correct") {
    return el("div", { className: "decimal-intro-feedback is-correct", text: "答對了" });
  }
  if (lessonState.lastResult === "try-again") {
    return el("div", { className: "decimal-intro-feedback is-wrong", text: "再調整一次" });
  }
  return el("div", { className: "decimal-intro-feedback", text: " " });
}

function renderDecimalIntroActions({ isAnswered, onNextRound, onReset }) {
  return el("div", {
    className: "decimal-intro-actions",
    children: [
      isAnswered
        ? el("button", {
            className: "button button--primary",
            text: "下一題",
            attrs: { type: "button" },
            on: { click: onNextRound },
          })
        : null,
      el("button", {
        className: "button button--ghost",
        text: "重新開始",
        attrs: { type: "button" },
        on: { click: onReset },
      }),
    ],
  });
}

const decimalIntroActivities = [
  { id: "life", label: "生活小數" },
  { id: "point", label: "找小數點" },
  { id: "place", label: "位值表" },
  { id: "read", label: "讀小數" },
  { id: "write", label: "讀寫練習" },
];

const selectedIntroDigits = new Map();

function getActiveDecimalIntroId(activeIntroTab) {
  return decimalIntroActivities.some((activity) => activity.id === activeIntroTab)
    ? activeIntroTab
    : decimalIntroActivities[0].id;
}

function renderDecimalIntroActivity(activeId, onSetIntroTab) {
  const isCalculationTab = activeId === "calculate";

  return el("article", {
    className: `decimal-intro-card${isCalculationTab ? " is-calculation" : ""}`,
    children: [
      el("div", {
        className: "decimal-intro-card__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: "小數認識" }),
              el("h3", { text: "先看懂小數點和位值" }),
            ],
          }),
          el("div", {
            className: "decimal-intro-tabs",
            children: decimalIntroActivities.map((activity) =>
              el("button", {
                className: `decimal-intro-tab${activity.id === activeId ? " is-active" : ""}`,
                text: activity.label,
                attrs: { type: "button" },
                on: { click: () => onSetIntroTab(activity.id) },
              }),
            ),
          }),
        ],
      }),
      isCalculationTab ? null : renderDecimalIntroPanel(activeId),
    ],
  });
}

function renderDecimalIntroPanel(activeId) {
  if (activeId === "life") {
    return renderDecimalLifePanel();
  }

  if (activeId === "place") {
    return renderDecimalPlacePanel();
  }

  if (activeId === "read") {
    return renderDecimalReadPanel();
  }

  if (activeId === "write") {
    return renderDecimalWritePanel();
  }

  return renderDecimalPointPanel();
}

function renderDecimalLifePanel() {
  const scenes = [
    { label: "商品價格", value: "12.5", unit: "元", hint: "買點心時可能看到" },
    { label: "身高紀錄", value: "128.3", unit: "公分", hint: "量身高時可能看到" },
    { label: "體溫數字", value: "36.8", unit: "度", hint: "量體溫時可能看到" },
    { label: "比賽秒數", value: "9.7", unit: "秒", hint: "跑步計時可能看到" },
  ];

  return el("div", {
    className: "decimal-intro-panel decimal-intro-panel--life",
    children: [
      el("div", {
        className: "decimal-life-stage",
        children: [
          el("div", {
            className: "decimal-life-board",
            children: [
              el("span", { className: "badge badge--warm", text: "生活中會看到" }),
              el("strong", { text: "有一個小點的數字" }),
              el("p", { text: "先找小數點，再看小數點前後的數字。" }),
            ],
          }),
          el("div", {
            className: "decimal-life-grid",
            children: scenes.map((scene) =>
              el("button", {
                className: "decimal-life-card",
                attrs: { type: "button" },
                on: {
                  click: (event) => {
                    event.currentTarget.classList.toggle("is-revealed");
                  },
                },
                children: [
                  el("span", { text: scene.label }),
                  el("strong", { text: scene.value }),
                  el("small", { text: scene.unit }),
                  el("em", { text: scene.hint }),
                ],
              }),
            ),
          }),
        ],
      }),
      el("div", {
        className: "decimal-mini-mission",
        children: [
          renderMiniMissionStep("1", "找", "找出小數點在哪裡。"),
          renderMiniMissionStep("2", "讀", "照順序讀：前面、點、後面。"),
          renderMiniMissionStep("3", "排", "放進位值表，看誰站在個位或十分位。"),
        ],
      }),
      renderIntroPractice("life", "自己排：1.5", ["個位", ".", "十分位"]),
    ],
  });
}

function renderMiniMissionStep(number, title, text) {
  return el("div", {
    className: "decimal-mini-mission__step",
    children: [
      el("strong", { text: number }),
      el("b", { text: title }),
      el("span", { text }),
    ],
  });
}

function renderDecimalPointPanel() {
  const pointCards = ["1.5", "2.3", "4.7", "0.8", "6.1", "9.4"];

  return el("div", {
    className: "decimal-intro-panel decimal-intro-panel--point",
    children: [
      el("div", {
        className: "decimal-number-stage",
        children: [
          el("span", { className: "decimal-number-stage__digit", text: "3" }),
          el("span", { className: "decimal-number-stage__point", text: "." }),
          el("span", { className: "decimal-number-stage__digit", text: "4" }),
        ],
      }),
      el("div", {
        className: "decimal-point-map",
        children: [
          el("div", { children: [el("strong", { text: "左邊" }), el("span", { text: "整數的位置" })] }),
          el("div", { children: [el("strong", { text: "小數點" }), el("span", { text: "分開整數和小數" })] }),
          el("div", { children: [el("strong", { text: "右邊" }), el("span", { text: "比 1 小的位置" })] }),
        ],
      }),
      el("div", {
        className: "decimal-point-hunt",
        children: pointCards.map((number) => renderPointHuntCard(number)),
      }),
      renderIntroPractice("point", "自己排：3.4", ["個位", ".", "十分位"]),
      el("div", {
        className: "decimal-student-task",
        children: [
          el("b", { text: "看一看" }),
          el("span", { text: "請指出小數點在哪裡，再說出小數點左邊和右邊各是什麼。" }),
        ],
      }),
    ],
  });
}

function renderPointHuntCard(number) {
  const [left, right] = number.split(".");

  return el("button", {
    className: "decimal-point-hunt__card",
    attrs: { type: "button" },
    on: {
      click: (event) => {
        event.currentTarget.classList.toggle("is-found");
      },
    },
    children: [
      el("span", { text: left }),
      el("b", { text: "." }),
      el("span", { text: right }),
    ],
  });
}

function renderDecimalPlacePanel() {
  return el("div", {
    className: "decimal-intro-panel",
    children: [
      renderPlaceValueTable(["十位", "個位", ".", "十分位"], ["2", "0", ".", "5"]),
      el("div", {
        className: "decimal-place-explain",
        children: [
          el("strong", { text: "20.5" }),
          el("span", { text: "2 個十、0 個一、5 個 0.1。" }),
        ],
      }),
      el("div", {
        className: "decimal-intro-practice",
        children: [
          el("strong", { text: "自己排：3.4" }),
          renderIntroPlaceTable(["個位", ".", "十分位"]),
          renderIntroDigitTray("place"),
        ],
      }),
      el("div", {
        className: "decimal-student-task",
        children: [
          el("b", { text: "換一題" }),
          el("span", { text: "把 3.4、1.2、0.7 放進位值表，看看每個數字站在哪一格。" }),
        ],
      }),
    ],
  });
}

function renderDecimalReadPanel() {
  const readCards = [
    ["0.7", "零點七"],
    ["1.2", "一點二"],
    ["3.4", "三點四"],
    ["5.9", "五點九"],
  ];

  return el("div", {
    className: "decimal-intro-panel",
    children: [
      el("div", {
        className: "decimal-read-grid",
        children: readCards.map(([decimal, reading]) =>
          el("button", {
            className: "decimal-read-card",
            attrs: { type: "button" },
            on: {
              click: (event) => {
                event.currentTarget.classList.toggle("is-speaking");
              },
            },
            children: [
              el("strong", { text: decimal }),
              el("span", { text: reading }),
              el("small", { text: "點一下，跟讀一次" }),
            ],
          }),
        ),
      }),
      renderIntroPractice("read", "聽老師念：一點二", ["個位", ".", "十分位"]),
      el("div", {
        className: "decimal-student-task",
        children: [
          el("b", { text: "跟著讀" }),
          el("span", { text: "先讀小數點左邊，再讀「點」，最後一個一個讀右邊的數字。" }),
        ],
      }),
    ],
  });
}

function renderDecimalWritePanel() {
  const practiceCards = [
    { prompt: "7 個 0.1", slots: ["", ".", ""] },
    { prompt: "1 個 1 和 3 個 0.1", slots: ["", ".", ""] },
    { prompt: "2 個 10 和 5 個 0.1", slots: ["", "", ".", ""] },
    { prompt: "0 個 1 和 8 個 0.1", slots: ["", ".", ""] },
  ];

  return el("div", {
    className: "decimal-intro-panel",
    children: [
      el("div", {
        className: "decimal-write-grid",
        children: practiceCards.map((card) =>
          el("div", {
            className: "decimal-write-card",
            children: [
              el("span", { text: card.prompt }),
              el("div", {
                className: "decimal-write-slots",
                children: card.slots.map((slot) =>
                  slot === "."
                    ? el("b", { className: "is-dot", text: "." })
                    : renderIntroDropSlot("write"),
                ),
              }),
            ],
          }),
        ),
      }),
      renderIntroDigitTray("write"),
      el("div", {
        className: "decimal-student-task",
        children: [
          el("b", { text: "寫一寫" }),
          el("span", { text: "先找有幾個 1，再找有幾個 0.1，最後把小數點放中間。" }),
        ],
      }),
    ],
  });
}

function renderIntroPractice(group, title, labels) {
  return el("div", {
    className: "decimal-intro-practice",
    children: [
      el("strong", { text: title }),
      el("span", { className: "decimal-intro-practice__hint", text: "先點一張數字卡，再點上方空格；也可以直接拖進空格。" }),
      renderIntroPlaceTable(labels, group),
      renderIntroDigitTray(group),
    ],
  });
}

function renderIntroPlaceTable(labels, group = "place") {
  return el("div", {
    className: "decimal-place-table decimal-place-table--practice",
    children: labels.map((label) =>
      el("div", {
        className: label === "." ? "is-point" : "",
        children: [
          el("span", { text: label }),
          label === "." ? el("strong", { text: "." }) : renderIntroDropSlot(group),
        ],
      }),
    ),
  });
}

function renderIntroDropSlot(group) {
  return el("button", {
    className: "decimal-intro-drop-slot",
    text: "□",
    attrs: { type: "button", "data-intro-drop-group": group },
    on: {
      dragenter: (event) => {
        event.preventDefault();
        event.currentTarget.classList.add("is-drop-ready");
      },
      dragover: (event) => event.preventDefault(),
      dragleave: (event) => {
        event.currentTarget.classList.remove("is-drop-ready");
      },
      drop: (event) => {
        event.preventDefault();
        event.currentTarget.classList.remove("is-drop-ready");
        const digit = event.dataTransfer?.getData(`application/x-decimal-${group}-digit`);
        if (!digit) return;
        fillIntroDropSlot(event.currentTarget, digit);
      },
      click: (event) => {
        const selectedDigit = selectedIntroDigits.get(group);
        if (/^\d$/.test(String(selectedDigit))) {
          fillIntroDropSlot(event.currentTarget, selectedDigit);
          return;
        }

        event.currentTarget.textContent = "□";
        event.currentTarget.classList.remove("is-filled");
      },
    },
  });
}

function renderIntroDigitTray(group) {
  return el("div", {
    className: "decimal-intro-digit-tray",
    children: Array.from({ length: 10 }, (_, digit) =>
      el("button", {
        className: "decimal-intro-digit",
        text: String(digit),
        attrs: { type: "button", draggable: "true" },
        on: {
          click: (event) => {
            selectIntroDigit(group, digit, event.currentTarget);
          },
          dragstart: (event) => {
            event.dataTransfer?.setData(`application/x-decimal-${group}-digit`, String(digit));
            event.currentTarget.classList.add("is-dragging");
          },
          dragend: (event) => {
            event.currentTarget.classList.remove("is-dragging");
          },
          pointerdown: (event) => {
            startDecimalTouchDrag(event, {
              digit,
              sourceClass: "decimal-intro-digit",
              onTap: (value) => selectIntroDigit(group, value, event.currentTarget),
              onDrop: (target, value) => {
                const slot = target?.closest?.(`.decimal-intro-drop-slot[data-intro-drop-group="${group}"]`);
                if (!slot) return false;
                fillIntroDropSlot(slot, value);
                return true;
              },
            });
          },
        },
      }),
    ),
  });
}

function fillIntroDropSlot(slot, digit) {
  slot.textContent = String(digit);
  slot.classList.add("is-filled");
}

function selectIntroDigit(group, digit, source) {
  selectedIntroDigits.set(group, String(digit));
  source
    .closest(".decimal-intro-digit-tray")
    ?.querySelectorAll(".decimal-intro-digit")
    .forEach((button) => button.classList.toggle("is-selected", button === source));
}

function startDecimalTouchDrag(event, { digit, sourceClass, onDrop, onTap }) {
  if (event.button > 0) return;

  event.preventDefault();
  const source = event.currentTarget;
  const pointerId = event.pointerId;
  const startX = event.clientX;
  const startY = event.clientY;
  let didMove = false;
  let hoverTarget = null;
  const ghost = document.createElement("div");
  ghost.className = `decimal-touch-ghost ${sourceClass}`;
  ghost.textContent = String(digit);
  ghost.setAttribute("aria-hidden", "true");
  document.body.append(ghost);
  source.classList.add("is-dragging");
  try {
    source.setPointerCapture?.(pointerId);
  } catch {
    // Some embedded browsers do not expose pointer capture for synthetic or interrupted drags.
  }

  const moveGhost = (clientX, clientY) => {
    ghost.style.transform = `translate(${clientX}px, ${clientY}px) translate(-50%, -50%)`;
  };

  const setHoverTarget = (target) => {
    const nextTarget = target?.closest?.(".decimal-intro-drop-slot, .vertical-equation__slot") ?? null;
    if (nextTarget === hoverTarget) return;
    hoverTarget?.classList.remove("is-drop-ready");
    hoverTarget = nextTarget;
    hoverTarget?.classList.add("is-drop-ready");
  };

  const stopDrag = (clientX, clientY) => {
    try {
      source.releasePointerCapture?.(pointerId);
    } catch {
      // Ignore pointer capture release failures; the visual cleanup below is enough.
    }
    source.classList.remove("is-dragging");
    hoverTarget?.classList.remove("is-drop-ready");
    hoverTarget = null;
    ghost.remove();
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    window.removeEventListener("pointercancel", onCancel);

    if (!didMove) {
      onTap?.(Number(digit));
      return;
    }

    const target = document.elementFromPoint(clientX, clientY);
    const accepted = onDrop(target, Number(digit));
    if (accepted) {
      target?.closest?.(".decimal-intro-drop-slot, .vertical-equation__slot")?.classList.add("is-touch-drop");
      window.setTimeout(() => {
        document.querySelectorAll(".is-touch-drop").forEach((node) => node.classList.remove("is-touch-drop"));
      }, 240);
    }
  };

  const onMove = (moveEvent) => {
    if (Math.abs(moveEvent.clientX - startX) + Math.abs(moveEvent.clientY - startY) > 5) {
      didMove = true;
    }
    moveEvent.preventDefault();
    moveGhost(moveEvent.clientX, moveEvent.clientY);
    setHoverTarget(document.elementFromPoint(moveEvent.clientX, moveEvent.clientY));
  };

  const onUp = (upEvent) => {
    upEvent.preventDefault();
    stopDrag(upEvent.clientX, upEvent.clientY);
  };

  const onCancel = (cancelEvent) => {
    stopDrag(cancelEvent.clientX, cancelEvent.clientY);
  };

  moveGhost(event.clientX, event.clientY);
  window.addEventListener("pointermove", onMove, { passive: false });
  window.addEventListener("pointerup", onUp, { passive: false });
  window.addEventListener("pointercancel", onCancel);
}

function renderPlaceValueTable(labels, values) {
  return el("div", {
    className: "decimal-place-table",
    children: labels.map((label, index) =>
      el("div", {
        className: label === "." ? "is-point" : "",
        children: [
          el("span", { text: label }),
          el("strong", { text: values[index] }),
        ],
      }),
    ),
  });
}

function renderTeachingCard(challenge) {
  return el("article", {
    className: "decimal-teaching-card",
    children: [
      el("span", { className: "badge badge--warm", text: "直式教學" }),
      el("h3", { text: "小數點要站同一排" }),
      renderVerticalEquation({
        top: "2.7",
        bottom: "1.6",
        operator: "+",
        answer: "4.3",
        revealAnswer: true,
      }),
      el("div", {
        className: "decimal-step-list",
        children: challenge.teachingSteps.map((step, index) =>
          el("div", {
            className: "decimal-step",
            children: [
              el("strong", { text: `${index + 1}` }),
              el("div", {
                children: [
                  el("b", { text: step.title }),
                  el("span", { text: step.text }),
                ],
              }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderGameCard({
  challenge,
  gameState,
  onSelectPlayer,
  onChooseDigit,
  onDropDigit,
  onSelectAnswerSlot,
  onSetMode,
  onClearDigits,
  onSubmitAnswer,
  onShowProcess,
  onNextProcess,
  onHideProcess,
  onNextRound,
  onSkipRound,
  onResetGame,
}) {
  const round = challenge.rounds[gameState.roundIndex];
  const activePlayer = gameState.players[gameState.activePlayerIndex];
  const canSubmit =
    gameState.mode === "challenge"
      ? gameState.verticalDigits.slice(4, 6).every(Boolean) && !gameState.isAnswered
      : gameState.verticalDigits.every(Boolean) && !gameState.isAnswered;
  const isChallengeMode = gameState.mode === "challenge";
  const processRound = getDecimalProcessRound(round, gameState);
  const processSteps = processRound ? buildDecimalProcessSteps(processRound) : [];
  const hasProcessStarted = Number.isInteger(gameState.processStep);
  const canShowProcess = Boolean(processRound);

  return el("article", {
    className: "decimal-game-card",
    children: [
      el("div", {
        className: "decimal-game-card__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: round.operation }),
              el("h3", { text: `第 ${gameState.roundIndex + 1} 題` }),
            ],
          }),
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button" },
            on: { click: onResetGame },
          }),
        ],
      }),
      renderModeSwitch(gameState.mode, onSetMode),
      renderPlayerRow(gameState, onSelectPlayer),
      el("div", {
        className: "decimal-drag-hint",
        children: [
          el("strong", { text: "拖動數字卡" }),
          el("span", { text: isChallengeMode ? "把下方數字拖進答案空格，對齊小數點。" : "自由模式可以把數字拖進整個直式。" }),
        ],
      }),
      el("div", {
        className: "decimal-question-board",
        children: [
          el("div", {
            className: "decimal-question-board__copy",
            children: [
              el("span", { className: "pill", text: `輪到 ${activePlayer.name}` }),
              el("strong", {
                text: isChallengeMode ? `${round.top} ${round.operator} ${round.bottom} = ?` : "自由填直式",
              }),
            ],
          }),
          el("div", {
            className: "decimal-board-workspace",
            children: [
              renderVerticalEquation({
                top: round.top,
                bottom: round.bottom,
                operator: round.operator,
                answer: round.answer,
                revealAnswer: gameState.isAnswered,
                verticalDigits: gameState.verticalDigits,
                activeVerticalSlot: gameState.activeVerticalSlot,
                onSelectAnswerSlot,
                onDropDigit,
                isLocked: gameState.isAnswered,
                mode: gameState.mode,
                processRound,
              }),
              el("div", {
                className: "decimal-side-tools",
                children: [
                  renderProcessPanel({
                    gameState,
                    processSteps,
                    canShowProcess,
                    onShowProcess,
                    onNextProcess,
                    onHideProcess,
                  }),
                  renderDigitPicker({ gameState, onChooseDigit, onDropDigit }),
                ],
              }),
            ],
          }),
        ],
      }),
      renderFeedback(gameState),
      el("div", {
        className: "number-game-actions",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "清除",
            attrs: {
              type: "button",
              disabled: gameState.isAnswered ? "disabled" : null,
            },
            on: { click: onClearDigits },
          }),
          el("button", {
            className: "button button--primary",
            text: "確認答案",
            attrs: {
              type: "button",
              "data-decimal-submit": "true",
              disabled: canSubmit ? null : "disabled",
            },
            on: { click: onSubmitAnswer },
          }),
          el("button", {
            className: "button button--secondary",
            text: hasProcessStarted ? "重新演示" : "演示計算過程",
            attrs: {
              type: "button",
              "data-decimal-process-trigger": "true",
              disabled: canShowProcess ? null : "disabled",
            },
            on: { click: onShowProcess },
          }),
          el("button", {
            className: "button button--ghost",
            text:
              gameState.mode === "free"
                ? "下一題"
                : gameState.roundIndex === gameState.totalRounds - 1
                  ? "看結果"
                  : "下一題",
            attrs: {
              type: "button",
              disabled: gameState.isAnswered ? null : "disabled",
            },
            on: { click: onNextRound },
          }),
          el("button", {
            className: "button button--ghost",
            text: "跳過題目",
            attrs: { type: "button" },
            on: { click: onSkipRound },
          }),
        ],
      }),
    ],
  });
}

function renderProcessPanel({ gameState, processSteps, canShowProcess, onShowProcess, onNextProcess, onHideProcess }) {
  const currentProcessStep = Number.isInteger(gameState.processStep) ? gameState.processStep : null;

  if (currentProcessStep === null) {
    return el("div", {
      className: "decimal-process-panel is-idle",
      children: [
        el("strong", { text: "計算過程" }),
        el("span", {
          text: canShowProcess
            ? "按下演示後，會一步一步看十分位、進位或借位、個位怎麼算。"
            : "自由模式先填好上面兩列小數，就能演示計算過程。",
        }),
        el("button", {
          className: "button button--secondary",
          text: "開始演示",
          attrs: {
            type: "button",
            "data-decimal-process-trigger": "true",
            disabled: canShowProcess ? null : "disabled",
          },
          on: { click: onShowProcess },
        }),
      ],
    });
  }

  if (!processSteps.length) {
    return null;
  }

  const stepIndex = Math.min(currentProcessStep, processSteps.length - 1);
  const step = processSteps[stepIndex];
  const isLast = stepIndex >= processSteps.length - 1;

  return el("div", {
    className: `decimal-process-panel is-${step.kind}`,
    children: [
      el("div", {
        className: "decimal-process-panel__head",
        children: [
          el("span", { text: `第 ${stepIndex + 1} 步 / ${processSteps.length}` }),
          el("strong", { text: step.title }),
        ],
      }),
      renderProcessScene(step),
      el("div", {
        className: "decimal-process-visual",
        children: step.tokens.map((token) =>
          el("span", { className: token.accent ? "is-accent" : "", text: token.text }),
        ),
      }),
      el("p", { text: step.text }),
      el("div", {
        className: "decimal-process-actions",
        children: [
          el("button", {
            className: "button button--primary",
            text: isLast ? "演示完成" : "下一步",
            attrs: { type: "button", disabled: isLast ? "disabled" : null },
            on: { click: onNextProcess },
          }),
          el("button", {
            className: "button button--ghost",
            text: "收起過程",
            attrs: { type: "button" },
            on: { click: onHideProcess },
          }),
        ],
      }),
    ],
  });
}

function renderProcessScene(step) {
  if (!step.scene) {
    return null;
  }

  if (step.scene.type === "carry") {
    return el("div", {
      className: "decimal-carry-scene",
      children: [
        el("div", {
          className: "decimal-carry-scene__group",
          children: [
            el("span", { text: "十分位" }),
            el("div", {
              className: "decimal-carry-blocks",
              children: Array.from({ length: step.scene.total }, (_, index) =>
                el("i", {
                  className: index < 10 ? "is-exchanged" : "is-left",
                  attrs: { "aria-hidden": "true" },
                }),
              ),
            }),
          ],
        }),
        el("div", {
          className: "decimal-carry-scene__exchange",
          children: [
            el("span", { className: "decimal-carry-scene__arrow", text: "→" }),
            el("strong", { text: `進 ${step.scene.carryValue}` }),
            el("small", { text: `留下 ${step.scene.leftDigit}` }),
          ],
        }),
        el("div", {
          className: "decimal-carry-scene__ones",
          children: [
            el("span", { text: "個位" }),
            el("b", { text: `+${step.scene.carryValue}` }),
          ],
        }),
      ],
    });
  }

  if (step.scene.type === "place") {
    return el("div", {
      className: "decimal-place-scene",
      children: [
        el("span", { text: step.scene.label }),
        el("strong", { text: step.scene.value }),
      ],
    });
  }

  return null;
}

function renderModeSwitch(activeMode, onSetMode) {
  return el("div", {
    className: "decimal-mode-switch",
    children: [
      el("button", {
        className: `button ${activeMode === "challenge" ? "button--primary" : "button--secondary"}`,
        text: "出題模式",
        attrs: { type: "button" },
        on: { click: () => onSetMode("challenge") },
      }),
      el("button", {
        className: `button ${activeMode === "free" ? "button--primary" : "button--secondary"}`,
        text: "自由模式",
        attrs: { type: "button" },
        on: { click: () => onSetMode("free") },
      }),
    ],
  });
}

function renderPlayerRow(gameState, onSelectPlayer) {
  return el("div", {
    className: "number-player-row",
    children: gameState.players.map((player, index) =>
      el("button", {
        className: `number-player-chip${index === gameState.activePlayerIndex ? " is-active" : ""}`,
        attrs: {
          type: "button",
          disabled: gameState.isAnswered ? "disabled" : null,
        },
        on: { click: () => onSelectPlayer(index) },
        children: [
          el("strong", { text: player.name }),
          el("span", { text: `${player.score} 分` }),
        ],
      }),
    ),
  });
}

function renderVerticalEquation({
  top,
  bottom,
  operator,
  answer,
  revealAnswer,
  verticalDigits = null,
  activeVerticalSlot = 0,
  onSelectAnswerSlot = () => {},
  onDropDigit = () => {},
  isLocked = false,
  mode = "challenge",
  processRound = null,
}) {
  const rows = buildAlignedRows(top, bottom, answer);
  const carryInfo = processRound ? buildCarryInfo(processRound.top, processRound.bottom, processRound.operator) : buildCarryInfo(top, bottom, operator);
  const isFreeMode = mode === "free";
  const shouldEditTopAndBottom = verticalDigits && !revealAnswer && isFreeMode;
  const shouldEditAnswer = verticalDigits && !revealAnswer;

  return el("div", {
    className: "vertical-equation",
    children: [
      renderPlaceLabels(rows.labels),
      carryInfo ? renderCarryRow(carryInfo) : null,
      shouldEditTopAndBottom
        ? renderEditableDigitsRow({
            operator: "",
            digits: [verticalDigits[0] || "", ".", verticalDigits[1] || ""],
            slotStart: 0,
            activeVerticalSlot,
            onSelectAnswerSlot,
            onDropDigit,
            isLocked,
          })
        : renderDigitsRow("", rows.top),
      shouldEditTopAndBottom
        ? renderEditableDigitsRow({
            operator,
            digits: [verticalDigits[2] || "", ".", verticalDigits[3] || ""],
            slotStart: 2,
            activeVerticalSlot,
            onSelectAnswerSlot,
            onDropDigit,
            isLocked,
          })
        : renderDigitsRow(operator, rows.bottom),
      el("div", { className: "vertical-equation__line" }),
      shouldEditAnswer
        ? renderEditableDigitsRow({
            operator: "",
            digits: [verticalDigits[4] || "", ".", verticalDigits[5] || ""],
            slotStart: 4,
            activeVerticalSlot,
            onSelectAnswerSlot,
            onDropDigit,
            isLocked,
            extraClassName: "vertical-equation__answer",
          })
        : renderDigitsRow("", revealAnswer ? rows.answer : rows.blankAnswer, "vertical-equation__answer"),
    ],
  });
}

function getDecimalProcessRound(round, gameState) {
  if (gameState.mode === "challenge") {
    return round;
  }

  const [topOnes, topTenths, bottomOnes, bottomTenths] = gameState.verticalDigits;
  if ([topOnes, topTenths, bottomOnes, bottomTenths].some((digit) => digit === "")) {
    return null;
  }

  const top = `${topOnes}.${topTenths}`;
  const bottom = `${bottomOnes}.${bottomTenths}`;
  const topValue = Number(top);
  const bottomValue = Number(bottom);
  const answerValue = round.operator === "+" ? topValue + bottomValue : topValue - bottomValue;

  if (answerValue < 0) {
    return null;
  }

  return {
    ...round,
    id: "decimal-free-process",
    top,
    bottom,
    answer: answerValue.toFixed(1),
  };
}

function renderCarryRow(carryInfo) {
  return el("div", {
    className: `vertical-equation__row vertical-equation__carry is-${carryInfo.type}`,
    children: [
      el("span", { className: "vertical-equation__operator" }),
      el("span", { text: carryInfo.onesLabel }),
      el("span", { className: "vertical-equation__dot", text: " " }),
      el("span", { text: carryInfo.tenthsLabel }),
    ],
  });
}

function renderPlaceLabels(labels) {
  return el("div", {
    className: "vertical-equation__row vertical-equation__labels",
    children: [
      el("span", { className: "vertical-equation__operator" }),
      ...labels.map((label) => el("span", { text: label })),
    ],
  });
}

function renderDigitsRow(operator, digits, extraClassName = "") {
  return el("div", {
    className: `vertical-equation__row ${extraClassName}`.trim(),
    children: [
      el("span", { className: "vertical-equation__operator", text: operator }),
      ...digits.map((digit) =>
        el("span", {
          className: digit === "." ? "vertical-equation__dot" : "",
          text: digit,
        }),
      ),
    ],
  });
}

function renderEditableDigitsRow({
  operator,
  digits,
  slotStart,
  activeVerticalSlot,
  onSelectAnswerSlot,
  onDropDigit,
  isLocked,
  extraClassName = "",
}) {
  return el("div", {
    className: `vertical-equation__row vertical-equation__answer--editable ${extraClassName}`.trim(),
    children: [
      el("span", { className: "vertical-equation__operator", text: operator }),
      el("button", {
        className: `vertical-equation__slot${activeVerticalSlot === slotStart ? " is-active" : ""}`,
        attrs: { type: "button", disabled: isLocked ? "disabled" : null, "data-slot-index": slotStart },
        text: digits[0] || "□",
        on: createSlotEvents(slotStart, onSelectAnswerSlot, onDropDigit),
      }),
      el("span", { className: "vertical-equation__dot", text: "." }),
      el("button", {
        className: `vertical-equation__slot${activeVerticalSlot === slotStart + 1 ? " is-active" : ""}`,
        attrs: { type: "button", disabled: isLocked ? "disabled" : null, "data-slot-index": slotStart + 1 },
        text: digits[2] || "□",
        on: createSlotEvents(slotStart + 1, onSelectAnswerSlot, onDropDigit),
      }),
    ],
  });
}

function renderDigitPicker({ gameState, onChooseDigit, onDropDigit }) {
  return el("div", {
    className: "decimal-digit-tray",
    children: [
      el("div", {
        className: "decimal-digit-tray__head",
        children: [
          el("strong", { text: "數字卡" }),
          el("span", { text: "拖到直式空格，也可以先點空格再點數字。" }),
        ],
      }),
      el("div", {
        className: "decimal-digit-pad",
        children: Array.from({ length: 10 }, (_, digit) =>
          el("button", {
            className: "decimal-digit-button",
            attrs: {
              type: "button",
              draggable: gameState.isAnswered ? null : "true",
              "data-digit": digit,
              disabled: gameState.isAnswered ? "disabled" : null,
            },
            text: String(digit),
            on: {
              click: () => onChooseDigit(digit),
              dragstart: (event) => {
                event.dataTransfer?.setData("text/plain", String(digit));
                event.dataTransfer?.setData("application/x-decimal-digit", String(digit));
                event.currentTarget.classList.add("is-dragging");
              },
              dragend: (event) => {
                event.currentTarget.classList.remove("is-dragging");
              },
              pointerdown: (event) => {
                if (gameState.isAnswered) return;
                startDecimalTouchDrag(event, {
                  digit,
                  sourceClass: "decimal-digit-button",
                  onTap: onChooseDigit,
                  onDrop: (target, value) => {
                    const slot = target?.closest?.(".vertical-equation__slot");
                    const slotIndex = Number(slot?.dataset?.slotIndex);
                    if (!Number.isInteger(slotIndex)) return false;
                    onDropDigit(slotIndex, value);
                    return true;
                  },
                });
              },
            },
          }),
        ),
      }),
    ],
  });
}

function createSlotEvents(slotIndex, onSelectAnswerSlot, onDropDigit) {
  return {
    click: () => onSelectAnswerSlot(slotIndex),
    dragenter: (event) => {
      event.preventDefault();
      event.currentTarget.classList.add("is-drop-ready");
    },
    dragover: (event) => {
      event.preventDefault();
    },
    dragleave: (event) => {
      event.currentTarget.classList.remove("is-drop-ready");
    },
    drop: (event) => {
      event.preventDefault();
      event.currentTarget.classList.remove("is-drop-ready");
      const rawDigit =
        event.dataTransfer?.getData("application/x-decimal-digit") ||
        event.dataTransfer?.getData("text/plain");
      if (/^\d$/.test(rawDigit)) {
        onDropDigit(slotIndex, Number(rawDigit));
      }
    },
  };
}

function renderFeedback(gameState) {
  if (!gameState.lastResult) {
    return el("p", {
      className: "decimal-feedback",
      text:
        gameState.mode === "challenge"
          ? "題目已經出好，學生只要填答案。"
          : "自由模式可以自己填題目，也可以自己填答案。",
    });
  }

  return el("p", {
    className: `decimal-feedback ${gameState.lastResult.isCorrect ? "is-correct" : "is-wrong"}`,
    text:
      gameState.mode === "free"
        ? "自由練習完成，可以清除或換下一題。"
        : gameState.lastResult.isCorrect
          ? `答對了，答案是 ${gameState.lastResult.answer}。`
          : `再看一次小數點，答案是 ${gameState.lastResult.answer}。`,
  });
}

function buildCarryInfo(top, bottom, operator) {
  const [, topTenths] = getDecimalPair(top);
  const [, bottomTenths] = getDecimalPair(bottom);
  const topDigit = Number(topTenths);
  const bottomDigit = Number(bottomTenths);

  if (operator === "+" && topDigit + bottomDigit >= 10) {
    return {
      type: "carry",
      onesLabel: "進 1",
      tenthsLabel: "滿 10",
    };
  }

  if (operator === "-" && topDigit < bottomDigit) {
    return {
      type: "borrow",
      onesLabel: "借 1",
      tenthsLabel: "補 10",
    };
  }

  return null;
}

function buildDecimalProcessSteps(round) {
  const [topOnes, topTenths] = getDecimalPair(round.top).map(Number);
  const [bottomOnes, bottomTenths] = getDecimalPair(round.bottom).map(Number);
  const [answerOnes, answerTenths] = getDecimalPair(round.answer).map(Number);

  if (round.operator === "+") {
    const tenthsSum = topTenths + bottomTenths;
    const carry = tenthsSum >= 10 ? 1 : 0;
    const tenthsDigit = tenthsSum % 10;
    const onesSum = topOnes + bottomOnes + carry;

    return [
      {
        kind: "tenths",
        title: "先算十分位",
        text: `十分位先算：${topTenths} + ${bottomTenths} = ${tenthsSum}。`,
        scene: {
          type: "place",
          label: "先把十分位合起來",
          value: `${topTenths} + ${bottomTenths}`,
        },
        tokens: [
          { text: `${topTenths}` },
          { text: "+" },
          { text: `${bottomTenths}` },
          { text: "=" },
          { text: `${tenthsSum}`, accent: true },
        ],
      },
      carry
        ? {
            kind: "carry",
            title: "滿十進一",
            text: `${tenthsSum} 個十分之一，等於 1 個一和 ${tenthsDigit} 個十分之一，所以往個位進 1。`,
            scene: {
              type: "carry",
              total: tenthsSum,
              carryValue: 1,
              leftDigit: tenthsDigit,
            },
            tokens: [
              { text: `${tenthsSum} 個十分之一` },
              { text: "→" },
              { text: "進 1", accent: true },
              { text: `留下 ${tenthsDigit}` },
            ],
          }
        : {
            kind: "tenths",
            title: "十分位留下",
            text: `沒有滿 10，十分位直接留下 ${tenthsDigit}。`,
            scene: {
              type: "place",
              label: "沒有滿 10",
              value: `留下 ${tenthsDigit}`,
            },
            tokens: [
              { text: `${tenthsSum}` },
              { text: "→" },
              { text: `留下 ${tenthsDigit}`, accent: true },
            ],
          },
      {
        kind: "ones",
        title: "再算個位",
        text: carry
          ? `個位算：${topOnes} + ${bottomOnes} + 進位 1 = ${onesSum}。`
          : `個位算：${topOnes} + ${bottomOnes} = ${onesSum}。`,
        scene: {
          type: "place",
          label: carry ? "個位加上進位" : "個位直接相加",
          value: carry ? `${topOnes} + ${bottomOnes} + 1` : `${topOnes} + ${bottomOnes}`,
        },
        tokens: [
          { text: `${topOnes}` },
          { text: "+" },
          { text: `${bottomOnes}` },
          ...(carry ? [{ text: "+ 1", accent: true }] : []),
          { text: "=" },
          { text: `${onesSum}`, accent: true },
        ],
      },
      {
        kind: "answer",
        title: "合成答案",
        text: `答案是 ${answerOnes}.${answerTenths}。`,
        scene: {
          type: "place",
          label: "把個位和十分位放回直式",
          value: `${answerOnes}.${answerTenths}`,
        },
        tokens: [
          { text: `${answerOnes}`, accent: true },
          { text: "." },
          { text: `${answerTenths}`, accent: true },
        ],
      },
    ];
  }

  const needsBorrow = topTenths < bottomTenths;
  const adjustedTenths = needsBorrow ? topTenths + 10 : topTenths;
  const tenthsDiff = adjustedTenths - bottomTenths;
  const adjustedOnes = needsBorrow ? topOnes - 1 : topOnes;
  const onesDiff = adjustedOnes - bottomOnes;

  return [
    needsBorrow
      ? {
          kind: "borrow",
          title: "十分位不夠減",
          text: `${topTenths} 不夠減 ${bottomTenths}，向個位借 1，十分位變成 ${adjustedTenths}。`,
          tokens: [
            { text: `${topTenths}` },
            { text: "不夠" },
            { text: "借 1", accent: true },
            { text: `變 ${adjustedTenths}` },
          ],
        }
      : {
          kind: "tenths",
          title: "先算十分位",
          text: `十分位可以直接算：${topTenths} - ${bottomTenths}。`,
          tokens: [
            { text: `${topTenths}` },
            { text: "-" },
            { text: `${bottomTenths}` },
          ],
        },
    {
      kind: "tenths",
      title: "算出十分位",
      text: `十分位算：${adjustedTenths} - ${bottomTenths} = ${tenthsDiff}。`,
      tokens: [
        { text: `${adjustedTenths}` },
        { text: "-" },
        { text: `${bottomTenths}` },
        { text: "=" },
        { text: `${tenthsDiff}`, accent: true },
      ],
    },
    {
      kind: "ones",
      title: "再算個位",
      text: needsBorrow
        ? `個位借出 1 後變成 ${adjustedOnes}，所以 ${adjustedOnes} - ${bottomOnes} = ${onesDiff}。`
        : `個位算：${topOnes} - ${bottomOnes} = ${onesDiff}。`,
      tokens: [
        { text: `${adjustedOnes}` },
        { text: "-" },
        { text: `${bottomOnes}` },
        { text: "=" },
        { text: `${onesDiff}`, accent: true },
      ],
    },
    {
      kind: "answer",
      title: "合成答案",
      text: `答案是 ${answerOnes}.${answerTenths}。`,
      tokens: [
        { text: `${answerOnes}`, accent: true },
        { text: "." },
        { text: `${answerTenths}`, accent: true },
      ],
    },
  ];
}

function renderFinishedCard(gameState, onResetGame) {
  const ranking = [...gameState.players].sort((a, b) => b.score - a.score);

  return el("article", {
    className: "decimal-game-card decimal-game-card--finished",
    children: [
      el("span", { className: "badge badge--live", text: "完成" }),
      el("h3", { text: "小數直式挑戰完成" }),
      el("div", {
        className: "decimal-result-grid",
        children: ranking.map((player) =>
          el("div", {
            className: "decimal-result-card",
            children: [
              el("strong", { text: player.name }),
              el("span", { text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("button", {
        className: "button button--primary",
        text: "再玩一次",
        attrs: { type: "button" },
        on: { click: onResetGame },
      }),
    ],
  });
}

function buildAlignedRows(top, bottom, answer) {
  const decimalPlaces = Math.max(getDecimalPlaces(top), getDecimalPlaces(bottom), getDecimalPlaces(answer));
  const integerPlaces = Math.max(getIntegerPlaces(top), getIntegerPlaces(bottom), getIntegerPlaces(answer));
  const labels = createPlaceLabels(integerPlaces, decimalPlaces);
  const normalizedAnswer = normalizeDecimal(answer, integerPlaces, decimalPlaces);

  return {
    labels,
    top: normalizeDecimal(top, integerPlaces, decimalPlaces),
    bottom: normalizeDecimal(bottom, integerPlaces, decimalPlaces),
    answer: normalizedAnswer,
    blankAnswer: normalizedAnswer.map((digit) => (digit === "." ? "." : "□")),
  };
}

function normalizeDecimal(value, integerPlaces, decimalPlaces) {
  const [integerPart, decimalPart = ""] = String(value).split(".");
  const left = integerPart.padStart(integerPlaces, " ");
  const right = decimalPart.padEnd(decimalPlaces, "0");
  return decimalPlaces > 0 ? `${left}.${right}`.split("") : left.split("");
}

function getIntegerPlaces(value) {
  return String(value).split(".")[0].length;
}

function getDecimalPlaces(value) {
  return String(value).split(".")[1]?.length ?? 0;
}

function getDecimalPair(value) {
  const [integerPart, decimalPart = "0"] = String(value).split(".");
  return [integerPart, decimalPart[0] ?? "0"];
}

function createPlaceLabels(integerPlaces, decimalPlaces) {
  const integerLabels = ["個", "十", "百"].slice(0, integerPlaces).reverse();
  const decimalLabels = ["十", "百", "千"].slice(0, decimalPlaces).map((label) => `${label}分`);
  return decimalPlaces > 0 ? [...integerLabels, ".", ...decimalLabels] : integerLabels;
}

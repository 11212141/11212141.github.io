import { el, sectionTitle } from "../utils/dom.js";

const modeLabels = {
  wheel: "彩色輪盤",
  spotlight: "跳燈點名",
  orbit: "星球抽選",
  cards: "卡片翻翻",
};

export function renderRandomPickerGame({
  students,
  state,
  onSetMode,
  onStartPick,
  onToggleSettings,
  onSetWeight,
  onResetWeights,
}) {
  const selectedStudent = students.find((student) => student.id === state.selectedId);

  return el("section", {
    className: "panel random-picker-panel",
    attrs: { id: "random-picker-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("隨機挑人", "", el("span", { className: "badge badge--warm", text: "活動遊戲" })),
          renderModeTabs(state.mode, onSetMode),
          el("div", {
            className: "random-picker-layout",
            children: [
              renderStage(students, state),
              renderSidePanel({
                students,
                state,
                selectedStudent,
                onStartPick,
                onToggleSettings,
                onSetWeight,
                onResetWeights,
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderModeTabs(activeMode, onSetMode) {
  const modes = [
    { id: "wheel", label: "輪盤", text: "轉到誰" },
    { id: "spotlight", label: "跳燈", text: "亮到誰" },
    { id: "orbit", label: "星球", text: "落到誰" },
    { id: "cards", label: "卡片", text: "翻到誰" },
  ];

  return el("div", {
    className: "random-mode-grid",
    children: modes.map((mode) =>
      el("button", {
        className: `random-mode-card${activeMode === mode.id ? " is-active" : ""}`,
        attrs: { type: "button" },
        on: { click: () => onSetMode(mode.id) },
        children: [
          el("strong", { text: mode.label }),
          el("span", { text: mode.text }),
        ],
      }),
    ),
  });
}

function renderStage(students, state) {
  if (state.mode === "wheel") {
    return renderWheelStage(students, state);
  }

  if (state.mode === "spotlight") {
    return renderSpotlightStage(students, state);
  }

  if (state.mode === "orbit") {
    return renderOrbitStage(students, state);
  }

  return renderCardStage(students, state);
}

function renderWheelStage(students, state) {
  return el("article", {
    className: "random-stage random-stage--wheel",
    attrs: { style: `--random-animation-id:${state.animationId};` },
    children: [
      el("div", { className: "random-wheel-pointer", text: "▼" }),
      el("div", {
        className: `random-wheel${state.isPicking ? " is-spinning" : ""}`,
        attrs: {
          style: `--wheel-start:${state.wheelStartRotation ?? 0}deg; --wheel-rotation:${state.wheelRotation}deg; --random-animation-id:${state.animationId};`,
        },
        children: students.map((student, index) =>
          el("div", {
            className: `random-wheel-slice random-wheel-slice--${index + 1}${state.selectedId === student.id ? " is-highlighted" : ""}`,
            children: [el("span", { text: student.name })],
          }),
        ),
      }),
      renderStageResult(state, "輪盤正在轉動", "按開始讓輪盤轉起來"),
    ],
  });
}

function renderSpotlightStage(students, state) {
  return el("article", {
    className: `random-stage random-stage--spotlight${state.isPicking ? " is-picking" : ""}`,
    attrs: { style: `--random-animation-id:${state.animationId};` },
    children: [
      el("div", {
        className: "random-spotlight-grid",
        children: students.map((student, index) =>
          el("div", {
            className: `random-spotlight-card random-spotlight-card--${index + 1} random-tone-${index + 1}${state.selectedId === student.id ? " is-picked" : ""}`,
            children: [
              el("div", { className: "random-spotlight-card__beam" }),
              el("div", {
                className: "random-spotlight-card__body",
                children: [
                  el("span", { text: `0${index + 1}` }),
                  el("strong", { text: student.name }),
                  el("small", { text: "待命" }),
                ],
              }),
            ],
          }),
        ),
      }),
      renderStageResult(state, "燈光正在跳動", "按開始讓燈光挑一位"),
    ],
  });
}

function renderOrbitStage(students, state) {
  return el("article", {
    className: `random-stage random-stage--orbit${state.isPicking ? " is-picking" : ""}`,
    attrs: { style: `--random-animation-id:${state.animationId};` },
    children: [
      el("div", {
        className: `random-orbit${state.isPicking ? " is-moving" : ""}`,
        children: [
          el("div", {
            className: "random-orbit-core",
            children: [
              el("span", { text: "GO" }),
            ],
          }),
          ...students.map((student, index) =>
            el("div", {
              className: `random-planet random-planet--${index + 1}${state.selectedId === student.id ? " is-picked" : ""}`,
              children: [
                el("div", {
                  className: "random-planet__body",
                  children: [
                    el("i", { text: student.name.slice(0, 1) }),
                    el("strong", { text: student.name }),
                  ],
                }),
              ],
            }),
          ),
        ],
      }),
      renderStageResult(state, "星球正在移動", "按開始讓星球停下來"),
    ],
  });
}

function renderCardStage(students, state) {
  return el("article", {
    className: `random-stage random-stage--cards${state.isPicking ? " is-picking" : ""}`,
    attrs: { style: `--random-animation-id:${state.animationId};` },
    children: [
      el("div", {
        className: "random-card-table",
        children: students.map((student, index) => {
          const isRevealed = state.selectedId === student.id;

          return el("div", {
            className: `random-draw-card random-draw-card--${index + 1} random-tone-${index + 1}${isRevealed ? " is-revealed" : ""}`,
            attrs: { "aria-label": isRevealed ? `抽到 ${student.name}` : "蓋牌" },
            children: [
              el("div", {
                className: "random-draw-card__back",
                children: [
                  el("i", { text: "★" }),
                  el("span", { text: "?" }),
                  el("small", { text: "抽選卡" }),
                ],
              }),
              el("div", {
                className: "random-draw-card__front",
                children: [
                  el("span", { text: student.name.slice(0, 1) }),
                  el("strong", { text: student.name }),
                ],
              }),
            ],
          });
        }),
      }),
      renderStageResult(state, "卡片正在洗牌", "按開始翻出一張卡"),
    ],
  });
}

function renderStageResult(state, pickingText, idleText) {
  const resultText = state.isPicking
    ? pickingText
    : state.selectedName
      ? `這次是 ${state.selectedName}`
      : idleText;

  return el("div", {
    className: `random-result-card${state.selectedName && !state.isPicking ? " has-result" : ""}`,
    children: [
      el("span", { text: modeLabels[state.mode] }),
      el("strong", { text: resultText }),
    ],
  });
}

function renderSidePanel({
  students,
  state,
  selectedStudent,
  onStartPick,
  onToggleSettings,
  onSetWeight,
  onResetWeights,
}) {
  return el("aside", {
    className: "random-side-panel",
    children: [
      el("div", {
        className: "random-control-card",
        children: [
          el("span", { className: "badge badge--live", text: "現在玩法" }),
          el("strong", { text: modeLabels[state.mode] }),
          selectedStudent
            ? el("p", { text: `${selectedStudent.name} 被抽中了。` })
            : el("p", { text: "點開始後，系統會依照目前機率挑一位學生。" }),
          el("button", {
            className: "button button--primary button--full random-start-button",
            text: state.isPicking ? "抽選中..." : "開始挑人",
            attrs: { type: "button", disabled: state.isPicking ? "disabled" : null },
            on: { click: onStartPick },
          }),
          el("button", {
            className: `random-settings-toggle${state.showSettings ? " is-open" : ""}`,
            text: state.showSettings ? "收起" : "⚙",
            attrs: {
              type: "button",
              "aria-label": state.showSettings ? "隱藏機率設定" : "開啟機率設定",
              title: state.showSettings ? "隱藏機率設定" : "開啟機率設定",
            },
            on: { click: onToggleSettings },
          }),
        ],
      }),
      state.showSettings
        ? renderWeightSettings(students, state, onSetWeight, onResetWeights)
        : null,
    ],
  });
}

function renderWeightSettings(students, state, onSetWeight, onResetWeights) {
  return el("div", {
    className: "random-weight-panel",
    children: [
      el("div", {
        className: "random-weight-panel__head",
        children: [
          el("strong", { text: "隱藏機率設定" }),
          el("button", {
            className: "button button--secondary",
            text: "平均",
            attrs: { type: "button" },
            on: { click: onResetWeights },
          }),
        ],
      }),
      ...students.map((student) => {
        const weight = state.weights[student.id] ?? 1;

        return el("label", {
          className: "random-weight-row",
          children: [
            el("span", { text: student.name }),
            el("input", {
              attrs: {
                type: "range",
                min: "0",
                max: "10",
                step: "1",
                value: String(weight),
              },
              on: { input: (event) => onSetWeight(student.id, Number(event.target.value)) },
            }),
            el("strong", { text: String(weight) }),
          ],
        });
      }),
      el("p", { text: "0 代表暫時不會被抽到；數字越大，被抽到機率越高。" }),
    ],
  });
}

import { el, sectionTitle } from "../utils/dom.js";

const LENGTH_UNITS = ["公尺", "公分", "毫米"];

export function renderLengthLearningGame({
  challenge,
  state,
  calculationMode,
  onSetMode,
  onChooseUnit,
  onNextUnit,
  onChooseCompare,
  onNextCompare,
  onRevealBuild,
  onNextBuild,
  onToggleCalcUnit,
  onChooseLengthDigit,
  onSelectLengthSlot,
  onClearLengthAnswer,
  onSubmitLengthAnswer,
  onNextCalculation,
}) {
  const section = el("section", { className: "panel", attrs: { id: "length-game" } });

  section.append(
    el("div", {
      className: "panel__content",
      children: [
        sectionTitle(challenge.title, "", el("span", { className: "badge badge--live", text: challenge.badge })),
        renderModeTabs(state.mode, onSetMode),
        state.mode === "units"
          ? renderChoiceGame({
              title: "遊戲一：認識長度單位",
              round: challenge.unitRounds[state.unitRoundIndex],
              index: state.unitRoundIndex,
              total: challenge.unitRounds.length,
              selected: state.unitSelected,
              result: state.unitResult,
              onChoose: onChooseUnit,
              onNext: onNextUnit,
            })
          : null,
        state.mode === "compare"
          ? renderChoiceGame({
              title: "遊戲二：長短比一比",
              round: challenge.compareRounds[state.compareRoundIndex],
              index: state.compareRoundIndex,
              total: challenge.compareRounds.length,
              selected: state.compareSelected,
              result: state.compareResult,
              onChoose: onChooseCompare,
              onNext: onNextCompare,
            })
          : null,
        state.mode === "build"
          ? renderBuildGame({
              round: challenge.buildRounds[state.buildRoundIndex],
              index: state.buildRoundIndex,
              total: challenge.buildRounds.length,
              revealed: state.buildRevealed,
              onReveal: onRevealBuild,
              onNext: onNextBuild,
            })
          : null,
        state.mode === "calculation"
          ? renderCalculationGame({
              challenge,
              state,
              calculationMode,
              onToggleCalcUnit,
              onChooseLengthDigit,
              onSelectLengthSlot,
              onClearLengthAnswer,
              onSubmitLengthAnswer,
              onNextCalculation,
            })
          : null,
      ],
    }),
  );

  return section;
}

function renderModeTabs(activeMode, onSetMode) {
  const modes = [
    { id: "units", label: "認識單位" },
    { id: "compare", label: "長短比一比" },
    { id: "build", label: "長度接龍" },
    { id: "calculation", label: "長度直式" },
  ];

  return el("div", {
    className: "decimal-mode-switch",
    children: modes.map((mode) =>
      el("button", {
        className: `button ${activeMode === mode.id ? "button--primary" : "button--secondary"}`,
        text: mode.label,
        attrs: { type: "button" },
        on: { click: () => onSetMode(mode.id) },
      }),
    ),
  });
}

function renderChoiceGame({ title, round, index, total, selected, result, onChoose, onNext }) {
  const prompt = round.prompt ?? `${round.left} 和 ${round.right}`;

  return el("article", {
    className: "length-game-card",
    children: [
      renderCardHead(title, `第 ${index + 1} / ${total} 題`),
      el("div", {
        className: "length-prompt-card",
        children: [el("strong", { text: prompt })],
      }),
      el("div", {
        className: "length-choice-grid",
        children: round.options.map((option) =>
          el("button", {
            className: getChoiceClass(option, round.answer, selected, result),
            text: option,
            attrs: { type: "button", disabled: result ? "disabled" : null },
            on: { click: () => onChoose(option) },
          }),
        ),
      }),
      renderChoiceFeedback(result, round.answer),
      renderNextButton(index === total - 1 ? "回到第一題" : "下一題", onNext, !result),
    ],
  });
}

function renderBuildGame({ round, index, total, revealed, onReveal, onNext }) {
  const target = formatCentimeterLength(round.targetCm);

  return el("article", {
    className: "length-game-card",
    children: [
      renderCardHead("遊戲三：長度接龍", `第 ${index + 1} / ${total} 題`),
      el("div", {
        className: "length-build-board",
        children: [
          el("strong", { text: `${round.baseCm} 公分 + ${round.addCm} 公分` }),
          el("div", {
            className: "length-bar-track",
            children: [
              el("span", {
                className: "length-bar-segment",
                attrs: { style: `--bar-size:${Math.max(18, Math.min(100, (round.baseCm / round.targetCm) * 100))}%;` },
                text: `${round.baseCm} 公分`,
              }),
              el("span", {
                className: "length-bar-segment length-bar-segment--add",
                attrs: { style: `--bar-size:${Math.max(18, Math.min(100, (round.addCm / round.targetCm) * 100))}%;` },
                text: `${round.addCm} 公分`,
              }),
            ],
          }),
          el("p", {
            className: revealed ? "length-build-answer is-revealed" : "length-build-answer",
            text: revealed ? `接起來是 ${target}` : "接起來是？",
          }),
        ],
      }),
      el("div", {
        className: "number-game-actions",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "公布答案",
            attrs: { type: "button", disabled: revealed ? "disabled" : null },
            on: { click: onReveal },
          }),
          el("button", {
            className: "button button--primary",
            text: index === total - 1 ? "回到第一題" : "下一題",
            attrs: { type: "button" },
            on: { click: onNext },
          }),
        ],
      }),
    ],
  });
}

function renderCalculationGame({
  challenge,
  state,
  calculationMode,
  onToggleCalcUnit,
  onChooseLengthDigit,
  onSelectLengthSlot,
  onClearLengthAnswer,
  onSubmitLengthAnswer,
  onNextCalculation,
}) {
  const selector = renderCalculationSelector(state.selectedCalcUnits, onToggleCalcUnit);

  if (!calculationMode) {
    return el("article", {
      className: "length-game-card",
      children: [
        renderCardHead("遊戲四：長度直式計算", "請先勾兩個單位"),
        selector,
        el("p", { className: "length-calc-helper", text: getCalcHelperText(state.selectedCalcUnits) }),
      ],
    });
  }

  const roundIndex = state.calculationRoundIndexes[calculationMode.id] ?? 0;
  const round = calculationMode.rounds[roundIndex];
  const canSubmit = state.lengthAnswer.every((digit) => digit !== "") && !state.lengthAnswered;

  return el("article", {
    className: "length-game-card",
    children: [
      renderCardHead("遊戲四：長度直式計算", `${calculationMode.label}｜第 ${roundIndex + 1} / ${calculationMode.rounds.length} 題`),
      selector,
      el("p", { className: "length-calc-helper", text: getCalcHelperText(state.selectedCalcUnits) }),
      el("div", {
        className: "length-question-board",
        children: [
          el("strong", {
            className: "length-expression",
            text: `${formatCalcLength(round.top, calculationMode.columns)} ${round.operator} ${formatCalcLength(round.bottom, calculationMode.columns)} = ?`,
          }),
          renderLengthVertical({
            round,
            columns: calculationMode.columns,
            answer: state.lengthAnswer,
            activeSlot: state.activeLengthSlot,
            answered: state.lengthAnswered,
            onSelectLengthSlot,
          }),
        ],
      }),
      renderLengthDigitPad({ answered: state.lengthAnswered, onChooseLengthDigit }),
      renderCalculationFeedback(state.lengthResult, round, calculationMode.columns),
      el("div", {
        className: "number-game-actions",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "清除",
            attrs: { type: "button", disabled: state.lengthAnswered ? "disabled" : null },
            on: { click: onClearLengthAnswer },
          }),
          el("button", {
            className: "button button--primary",
            text: "確認答案",
            attrs: { type: "button", disabled: canSubmit ? null : "disabled" },
            on: { click: onSubmitLengthAnswer },
          }),
          el("button", {
            className: "button button--ghost",
            text: roundIndex === calculationMode.rounds.length - 1 ? "回到第一題" : "下一題",
            attrs: { type: "button", disabled: state.lengthAnswered ? null : "disabled" },
            on: { click: onNextCalculation },
          }),
        ],
      }),
    ],
  });
}

function renderCalculationSelector(selectedUnits, onToggleCalcUnit) {
  return el("section", {
    className: "length-calc-picker",
    children: [
      el("div", {
        className: "length-calc-picker__head",
        children: [
          el("strong", { text: "先選兩個單位" }),
          el("span", { text: `已選 ${selectedUnits.length} / 2` }),
        ],
      }),
      el("div", {
        className: "length-calc-selector",
        children: LENGTH_UNITS.map((unit) =>
          el("button", {
            className: `length-calc-chip${selectedUnits.includes(unit) ? " is-selected" : ""}`,
            attrs: { type: "button" },
            on: { click: () => onToggleCalcUnit(unit) },
            children: [
              el("span", {
                className: `length-calc-chip__check${selectedUnits.includes(unit) ? " is-selected" : ""}`,
                text: selectedUnits.includes(unit) ? "✓" : "",
              }),
              el("strong", { text: unit }),
              el("span", { text: selectedUnits.includes(unit) ? "已選" : "點這裡選" }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderLengthVertical({ round, columns, answer, activeSlot, answered, onSelectLengthSlot }) {
  const answerDigits = answered ? flattenAnswerDigits(round.answer, columns) : answer;
  const gridTemplate = getLengthGridTemplate(columns);

  return el("div", {
    className: "length-vertical",
    children: [
      renderLengthLabelRow(columns, gridTemplate),
      renderLengthDigitsRow(columns, round.top, "", gridTemplate),
      renderLengthDigitsRow(columns, round.bottom, round.operator, gridTemplate),
      el("div", { className: "length-vertical__line" }),
      renderLengthAnswerRow({
        digits: answerDigits,
        operator: "",
        activeSlot,
        answered,
        onSelectLengthSlot,
        gridTemplate,
        columns,
      }),
    ],
  });
}

function renderLengthLabelRow(columns, gridTemplate) {
  return el("div", {
    className: "length-vertical__row length-vertical__labels",
    attrs: { style: `grid-template-columns:${gridTemplate};` },
    children: [
      el("span", { className: "length-vertical__operator" }),
      ...columns.map((column, index) =>
        el("span", {
          className: `length-vertical__label-cell${index > 0 ? " length-vertical__group-start" : ""}`,
          text: column.label,
          attrs: { style: `grid-column: span ${column.digits};` },
        }),
      ),
    ],
  });
}

function renderLengthDigitsRow(columns, values, operator, gridTemplate) {
  return el("div", {
    className: "length-vertical__row",
    attrs: { style: `grid-template-columns:${gridTemplate};` },
    children: [
      el("span", { className: "length-vertical__operator", text: operator }),
      ...columns.flatMap((column, columnIndex) =>
        padValue(values[column.key] ?? 0, column.pad).split("").map((digit, localIndex) => {
          return el("span", {
            className: `length-vertical__digit-cell${
              columnIndex > 0 && localIndex === 0 ? " length-vertical__group-start" : ""
            }`,
            text: digit,
          });
        }),
      ),
    ],
  });
}

function renderLengthAnswerRow({ digits, operator, activeSlot, answered, onSelectLengthSlot, gridTemplate, columns }) {
  const groupStarts = getGroupStartIndexes(columns);
  return el("div", {
    className: "length-vertical__row length-vertical__answer",
    attrs: { style: `grid-template-columns:${gridTemplate};` },
    children: [
      el("span", { className: "length-vertical__operator", text: operator }),
      ...digits.map((digit, index) =>
        el("button", {
          className: `length-vertical__slot${groupStarts.includes(index) ? " length-vertical__group-start" : ""}${
            activeSlot === index && !answered ? " is-active" : ""
          }`,
          text: digit || "□",
          attrs: { type: "button", disabled: answered ? "disabled" : null },
          on: { click: () => onSelectLengthSlot(index) },
        }),
      ),
    ],
  });
}

function renderLengthRow(values, operator, extraClassName = "") {
  return el("div", {
    className: `length-vertical__row ${extraClassName}`.trim(),
    children: [
      el("span", { className: "length-vertical__operator", text: operator }),
      ...values.map((value) => el("span", { text: value })),
    ],
  });
}

function renderLengthDigitPad({ answered, onChooseLengthDigit }) {
  return el("div", {
    className: "decimal-digit-pad",
    children: Array.from({ length: 10 }, (_, digit) =>
      el("button", {
        className: "decimal-digit-button",
        text: String(digit),
        attrs: { type: "button", disabled: answered ? "disabled" : null },
        on: { click: () => onChooseLengthDigit(digit) },
      }),
    ),
  });
}

function renderChoiceFeedback(result, answer) {
  if (!result) {
    return el("p", { className: "decimal-feedback", text: "選出最適合的答案。" });
  }

  return el("p", {
    className: `decimal-feedback ${result.isCorrect ? "is-correct" : "is-wrong"}`,
    text: result.isCorrect ? "答對了。" : `再想想，答案是 ${answer}。`,
  });
}

function renderCalculationFeedback(result, round, columns) {
  if (!result) {
    return el("p", { className: "decimal-feedback", text: "先勾兩個單位，再把直式對齊。" });
  }

  const answer = formatCalcLength(round.answer, columns);
  return el("p", {
    className: `decimal-feedback ${result.isCorrect ? "is-correct" : "is-wrong"}`,
    text: result.isCorrect ? `答對了，答案是 ${answer}。` : `再看一次單位，答案是 ${answer}。`,
  });
}

function renderCardHead(title, badgeText) {
  return el("div", {
    className: "length-game-card__head",
    children: [
      el("div", {
        children: [
          el("span", { className: "badge badge--warm", text: badgeText }),
          el("h3", { text: title }),
        ],
      }),
    ],
  });
}

function renderNextButton(label, onNext, disabled) {
  return el("div", {
    className: "number-game-actions",
    children: [
      el("button", {
        className: "button button--primary",
        text: label,
        attrs: { type: "button", disabled: disabled ? "disabled" : null },
        on: { click: onNext },
      }),
    ],
  });
}

function getChoiceClass(option, answer, selected, result) {
  const isSelected = option === selected;
  const isCorrect = result && option === answer;
  const isWrong = result && isSelected && option !== answer;
  return `length-choice-button${isSelected ? " is-selected" : ""}${isCorrect ? " is-correct" : ""}${isWrong ? " is-wrong" : ""}`;
}

function flattenAnswerDigits(answer, columns) {
  return columns.flatMap((column) => padValue(answer[column.key] ?? 0, column.pad).split(""));
}

function padValue(value, digits) {
  return String(value).padStart(digits, "0");
}

function formatCalcLength(values, columns) {
  return columns.map((column) => `${values[column.key] ?? 0} ${column.label}`).join(" ");
}

function formatCentimeterLength(totalCm) {
  const meters = Math.floor(totalCm / 100);
  const centimeters = totalCm % 100;

  if (meters === 0) {
    return `${centimeters} 公分`;
  }

  if (centimeters === 0) {
    return `${meters} 公尺`;
  }

  return `${meters} 公尺 ${centimeters} 公分`;
}

function getCalcHelperText(selectedUnits) {
  if (selectedUnits.length === 0) {
    return "請先選兩個單位。";
  }

  if (selectedUnits.length === 1) {
    return `還要再選 1 個單位，目前選了 ${selectedUnits[0]}。`;
  }

  return `目前使用 ${selectedUnits[0]} 和 ${selectedUnits[1]}。如果要換，先取消一個再選另一個。`;
}

function getLengthGridTemplate(columns) {
  const totalDigits = columns.reduce((sum, column) => sum + column.digits, 0);
  return `4.4rem repeat(${totalDigits}, minmax(5.6rem, 6.2rem))`;
}

function getGroupStartIndexes(columns) {
  const starts = [];
  let cursor = 0;

  columns.forEach((column, index) => {
    if (index > 0) {
      starts.push(cursor);
    }
    cursor += column.digits;
  });

  return starts;
}

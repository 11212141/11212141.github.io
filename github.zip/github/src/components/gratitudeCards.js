import { el, sectionTitle } from "../utils/dom.js";

const REASONS = ["謝謝你幫助我", "謝謝你陪我學習", "謝謝你鼓勵我", "謝謝你很有耐心", "謝謝你讓我很開心"];
const THEMES = [
  { id: "aqua", label: "湖水藍" },
  { id: "sunny", label: "暖陽黃" },
  { id: "rose", label: "玫瑰粉" },
  { id: "leaf", label: "葉子綠" },
];

export function renderGratitudeCards({ state, students, onSelectStudent, onUpdateDraft, onSubmit, onDelete, onRefresh }) {
  const activeStudent = students[state.activeStudentIndex];
  const draft = state.drafts[activeStudent.id];

  return el("section", {
    className: "panel gratitude-panel",
    attrs: { id: "gratitude-cards" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("感謝卡片活動", "", el("span", { className: "badge badge--live", text: "四人一起寫" })),
          renderStudentTabs(students, state.activeStudentIndex, onSelectStudent),
          el("div", {
            className: "gratitude-layout",
            children: [
              renderEditor({ student: activeStudent, draft, isSaving: state.isSaving, onUpdateDraft, onSubmit }),
              renderPreview({ student: activeStudent, draft }),
            ],
          }),
          renderCardWall({ cards: state.cards, isLoading: state.isLoading, error: state.error, onDelete, onRefresh }),
        ],
      }),
    ],
  });
}

function renderStudentTabs(students, activeIndex, onSelectStudent) {
  return el("div", {
    className: "gratitude-student-tabs",
    children: students.map((student, index) =>
      el("button", {
        className: `gratitude-student-tab${index === activeIndex ? " is-active" : ""}`,
        attrs: { type: "button" },
        on: { click: () => onSelectStudent(index) },
        children: [el("strong", { text: student.name }), el("span", { text: student.account })],
      }),
    ),
  });
}

function renderEditor({ student, draft, isSaving, onUpdateDraft, onSubmit }) {
  return el("form", {
    className: "gratitude-editor",
    on: {
      submit: (event) => {
        event.preventDefault();
        onSubmit();
      },
    },
    children: [
      el("div", {
        className: "gratitude-editor__head",
        children: [
          el("span", { className: "badge badge--warm", text: student.name }),
          el("h3", { text: "寫一張感謝卡" }),
        ],
      }),
      renderField("To 收件人", "recipient", draft.recipient, "想感謝誰？", onUpdateDraft),
      renderSelect("感謝原因", "reason", draft.reason, REASONS, onUpdateDraft),
      renderTextarea("卡片內容", "message", draft.message, "謝謝你……我覺得……", onUpdateDraft),
      renderField("From 署名", "signature", draft.signature, student.name, onUpdateDraft),
      renderThemePicker(draft.theme, onUpdateDraft),
      el("button", {
        className: "button button--primary gratitude-submit",
        text: isSaving ? "保存中..." : "保存感謝卡",
        attrs: { type: "submit", disabled: isSaving ? "disabled" : null },
      }),
    ],
  });
}

function renderField(label, key, value, placeholder, onUpdateDraft) {
  return el("label", {
    className: "gratitude-field",
    children: [
      el("span", { text: label }),
      el("input", {
        attrs: { value, placeholder },
        on: { input: (event) => onUpdateDraft(key, event.target.value) },
      }),
    ],
  });
}

function renderTextarea(label, key, value, placeholder, onUpdateDraft) {
  return el("label", {
    className: "gratitude-field",
    children: [
      el("span", { text: label }),
      el("textarea", {
        text: value,
        attrs: { rows: "5", placeholder },
        on: { input: (event) => onUpdateDraft(key, event.target.value) },
      }),
    ],
  });
}

function renderSelect(label, key, value, options, onUpdateDraft) {
  return el("label", {
    className: "gratitude-field",
    children: [
      el("span", { text: label }),
      el("select", {
        on: { change: (event) => onUpdateDraft(key, event.target.value) },
        children: [
          el("option", { text: "請選擇", attrs: { value: "" } }),
          ...options.map((option) => el("option", { text: option, attrs: { value: option, selected: value === option ? "selected" : null } })),
        ],
      }),
    ],
  });
}

function renderThemePicker(activeTheme, onUpdateDraft) {
  return el("div", {
    className: "gratitude-theme-picker",
    children: [
      el("span", { text: "卡片顏色" }),
      el("div", {
        className: "gratitude-theme-row",
        children: THEMES.map((theme) =>
          el("button", {
            className: `gratitude-theme gratitude-theme--${theme.id}${activeTheme === theme.id ? " is-active" : ""}`,
            text: theme.label,
            attrs: { type: "button" },
            on: { click: () => onUpdateDraft("theme", theme.id) },
          }),
        ),
      }),
    ],
  });
}

function renderPreview({ student, draft }) {
  const card = {
    studentName: student.name,
    recipient: draft.recipient || "想感謝的人",
    reason: draft.reason || "謝謝你",
    message: draft.message || "把想說的感謝寫在這裡。",
    signature: draft.signature || student.name,
    theme: draft.theme,
  };

  return el("article", {
    className: "gratitude-preview",
    children: [
      el("span", { className: "badge badge--warm", text: "即時預覽" }),
      renderCard(card),
    ],
  });
}

function renderCardWall({ cards, isLoading, error, onDelete, onRefresh }) {
  return el("section", {
    className: "gratitude-wall",
    children: [
      el("div", {
        className: "gratitude-wall__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: `${cards.length} 張卡片` }),
              el("h3", { text: "感謝卡牆" }),
            ],
          }),
          el("button", { className: "button button--secondary", text: "重新整理", attrs: { type: "button" }, on: { click: onRefresh } }),
        ],
      }),
      error ? el("p", { className: "trip-status is-error", text: error }) : null,
      isLoading ? el("p", { className: "trip-status", text: "讀取卡片中..." }) : null,
      !isLoading && cards.length === 0
        ? el("div", {
            className: "trip-empty",
            children: [el("strong", { text: "還沒有感謝卡" }), el("p", { text: "先選一位學生，寫下第一張溫暖的卡片。" })],
          })
        : null,
      el("div", {
        className: "gratitude-card-grid",
        children: cards.map((card) =>
          el("div", {
            className: "gratitude-saved-card",
            children: [
              renderCard(card),
              el("button", {
                className: "button button--ghost",
                text: "刪除",
                attrs: { type: "button" },
                on: { click: () => onDelete(card.id) },
              }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderCard(card) {
  return el("article", {
    className: `gratitude-card gratitude-card--${card.theme || "aqua"}`,
    children: [
      el("div", { className: "gratitude-card__stamp", text: "Thank you" }),
      el("p", { className: "gratitude-card__to", text: `To ${card.recipient}` }),
      el("h3", { text: card.reason }),
      el("p", { className: "gratitude-card__message", text: card.message }),
      el("p", { className: "gratitude-card__from", text: `From ${card.signature || card.studentName}` }),
    ],
  });
}

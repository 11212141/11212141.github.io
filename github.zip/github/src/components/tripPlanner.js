import { el, sectionTitle } from "../utils/dom.js";

const CATEGORIES = ["交通", "景點", "餐食", "休息", "購物", "活動"];
const TRANSPORTS = ["步行", "公車", "火車", "汽車", "腳踏車", "其他"];

export function renderTripPlanner({ state, summary, onSubmit, onDelete, onRefresh }) {
  return el("section", {
    className: "panel trip-panel",
    attrs: { id: "trip-planner" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("旅行小隊行程板", "", el("span", { className: "badge badge--live", text: "自動保存" })),
          renderSummary(summary),
          el("div", {
            className: "trip-planner-layout",
            children: [
              renderTripForm({ onSubmit, isSaving: state.isSaving }),
              renderTripList({ state, summary, onDelete, onRefresh }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderSummary(summary) {
  const cards = [
    { value: `${summary.itemCount}`, label: "行程" },
    { value: `${summary.totalDuration}`, label: "分鐘" },
    { value: `$${summary.totalBudget}`, label: "預算" },
    { value: summary.mainTransport || "未定", label: "主要交通" },
  ];

  return el("div", {
    className: "trip-summary-grid",
    children: cards.map((card) =>
      el("article", {
        className: "trip-summary-card",
        children: [el("strong", { text: card.value }), el("span", { text: card.label })],
      }),
    ),
  });
}

function renderTripForm({ onSubmit, isSaving }) {
  return el("form", {
    className: "trip-form",
    on: {
      submit: (event) => {
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        onSubmit({
          tripDay: formData.get("tripDay"),
          startTime: formData.get("startTime"),
          title: formData.get("title"),
          location: formData.get("location"),
          category: formData.get("category"),
          transport: formData.get("transport"),
          durationMinutes: formData.get("durationMinutes"),
          budget: formData.get("budget"),
          note: formData.get("note"),
        });
        event.currentTarget.reset();
      },
    },
    children: [
      el("div", {
        className: "trip-form__head",
        children: [
          el("span", { className: "badge badge--warm", text: "新增一站" }),
          el("h3", { text: "今天想去哪裡？" }),
        ],
      }),
      el("div", {
        className: "trip-form-grid",
        children: [
          renderField("日期", "tripDay", "date"),
          renderField("時間", "startTime", "time"),
          renderField("行程名稱", "title", "text", "例如：搭火車、吃午餐、去海邊", true),
          renderField("地點", "location", "text", "例如：臺東車站"),
          renderSelect("活動類型", "category", CATEGORIES),
          renderSelect("交通方式", "transport", TRANSPORTS),
          renderField("停留分鐘", "durationMinutes", "number", "例如：60"),
          renderField("預估花費", "budget", "number", "例如：120"),
        ],
      }),
      el("label", {
        className: "trip-field",
        children: [
          el("span", { text: "小提醒" }),
          el("textarea", {
            attrs: {
              name: "note",
              rows: "4",
              placeholder: "要帶什麼？要注意什麼？可以寫在這裡。",
            },
          }),
        ],
      }),
      el("button", {
        className: "button button--primary trip-submit",
        text: isSaving ? "加入中..." : "加入行程",
        attrs: { type: "submit", disabled: isSaving ? "disabled" : null },
      }),
    ],
  });
}

function renderField(label, name, type, placeholder = "", required = false) {
  return el("label", {
    className: "trip-field",
    children: [
      el("span", { text: label }),
      el("input", {
        attrs: {
          name,
          type,
          min: type === "number" ? "0" : null,
          placeholder,
          required: required ? "required" : null,
        },
      }),
    ],
  });
}

function renderSelect(label, name, options) {
  return el("label", {
    className: "trip-field",
    children: [
      el("span", { text: label }),
      el("select", {
        attrs: { name },
        children: [
          el("option", { text: "請選擇", attrs: { value: "" } }),
          ...options.map((option) => el("option", { text: option, attrs: { value: option } })),
        ],
      }),
    ],
  });
}

function renderTripList({ state, summary, onDelete, onRefresh }) {
  return el("article", {
    className: "trip-list-card",
    children: [
      el("div", {
        className: "trip-list-card__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: `${state.items.length} 站` }),
              el("h3", { text: "我的旅行路線" }),
            ],
          }),
          el("button", {
            className: "button button--secondary",
            text: "重新整理",
            attrs: { type: "button" },
            on: { click: onRefresh },
          }),
        ],
      }),
      summary.categoryText ? el("p", { className: "trip-route-hint", text: summary.categoryText }) : null,
      state.error ? el("p", { className: "trip-status is-error", text: state.error }) : null,
      state.isLoading ? el("p", { className: "trip-status", text: "讀取行程中..." }) : null,
      !state.isLoading && state.items.length === 0
        ? el("div", {
            className: "trip-empty",
            children: [
              el("strong", { text: "還沒有行程" }),
              el("p", { text: "先加入第一站，慢慢排出自己的旅行路線。" }),
            ],
          })
        : null,
      el("div", {
        className: "trip-items",
        children: state.items.map((item, index) => renderTripItem(item, index, onDelete)),
      }),
    ],
  });
}

function renderTripItem(item, index, onDelete) {
  const meta = [item.tripDay, item.startTime, item.location].filter(Boolean).join(" · ");
  const chips = [
    item.category,
    item.transport,
    item.durationMinutes ? `${item.durationMinutes} 分鐘` : "",
    item.budget ? `$${item.budget}` : "",
  ].filter(Boolean);

  return el("article", {
    className: "trip-item",
    children: [
      el("span", { className: "trip-item__number", text: String(index + 1).padStart(2, "0") }),
      el("div", {
        className: "trip-item__body",
        children: [
          el("strong", { text: item.title }),
          meta ? el("span", { text: meta }) : null,
          chips.length
            ? el("div", {
                className: "trip-chip-row",
                children: chips.map((chip) => el("span", { className: "trip-chip", text: chip })),
              })
            : null,
          item.note ? el("p", { text: item.note }) : null,
        ],
      }),
      el("button", {
        className: "button button--ghost",
        text: "刪除",
        attrs: { type: "button" },
        on: { click: () => onDelete(item.id) },
      }),
    ],
  });
}

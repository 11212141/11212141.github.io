import { el, sectionTitle } from "../utils/dom.js";

export function createDateFinanceState(challenge, students) {
  return {
    gameVersion: challenge.version,
    setupComplete: false,
    monthDays: challenge.defaultDays,
    startWeekday: 2,
    activePlayerIndex: 0,
    lastRoll: 0,
    isRolling: false,
    resetUnlocked: false,
    lastCard: null,
    pendingCard: null,
    currentQuestion: null,
    selectedAnswer: "",
    answered: false,
    result: null,
    players: students.map((student, index) => ({
      name: student.name,
      members: student.members ?? "",
      avatarId: challenge.avatarOptions?.[index % (challenge.avatarOptions?.length || 1)]?.id ?? "fox",
      day: 1,
      money: challenge.startMoney,
      saved: 0,
      assets: 0,
      passiveIncome: 0,
      dreamProgress: 0,
      stars: 0,
      streak: 0,
      badges: [],
      jobId: challenge.jobs?.[index % (challenge.jobs?.length || 1)]?.id ?? "helper",
      dreamId: challenge.dreams?.[index % (challenge.dreams?.length || 1)]?.id ?? "bike",
      finished: false,
      correct: 0,
      log: ["進入現金流圈"],
    })),
  };
}

export function renderDateFinanceGame({
  challenge,
  state,
  onSetMonthDays,
  onSetStartWeekday,
  onSetPlayerJob,
  onSetPlayerDream,
  onSelectPlayer,
  onRollDice,
  onChooseAnswer,
  onChooseCardDecision,
  onNextTurn,
  onReset,
  onUpdatePlayerSetup,
  onStartSetup,
  onShowResetLock,
  onCancelResetLock,
  onSubmitResetPassword,
  stateStatus = "",
}) {
  const month = getCurrentMonth(state);
  const activePlayer = state.players[state.activePlayerIndex];
  const currentQuestion = state.currentQuestion ?? buildQuestion(challenge, state, activePlayer);
  const content = state.setupComplete
    ? el("div", {
        className: "date-finance-layout",
        children: [
          renderCircularBoard({ challenge, state, month, activePlayer, onRollDice, onReset, stateStatus }),
          el("div", {
            className: "date-info-layout",
            children: [
              renderControlPanel({
                challenge,
                state,
                activePlayer,
                onSelectPlayer,
                onShowResetLock,
                onCancelResetLock,
                onSubmitResetPassword,
              }),
              renderMissionPanel({ challenge, state, activePlayer, currentQuestion, onChooseAnswer, onChooseCardDecision, onNextTurn }),
            ],
          }),
        ],
      })
    : renderSetupScreen({ challenge, state, onUpdatePlayerSetup, onStartSetup, stateStatus });

  return el("section", {
    className: "panel date-finance-panel",
    attrs: { id: "date-finance-game", "data-name-visibility-skip": "true" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle(challenge.title, "", el("span", { className: "badge badge--warm", text: challenge.badge })),
          content,
        ],
      }),
    ],
  });
}

function renderSetupScreen({ challenge, state, onUpdatePlayerSetup, onStartSetup, stateStatus }) {
  const allReady = state.players.every((player) => player.name.trim() && player.avatarId && player.jobId && player.dreamId);
  const dreamPreview = challenge.dreams.map((dream) => `${dream.icon ?? ""}${dream.name}`).join("、");

  return el("article", {
    className: "cashflow-setup-board",
    children: [
      el("div", {
        className: "cashflow-setup-hero",
        children: [
          el("span", { className: "badge badge--live", text: stateStatus || "開局設定" }),
          el("h3", { text: "先成立你的理財隊伍" }),
          el("p", { text: "每隊先選圖示、確認隊名、決定職業和夢想。開始後夢想目標就固定，大家要靠收入、儲蓄、資產和被動收入往目標前進。" }),
          el("div", {
            className: "cashflow-setup-dreamline",
            children: [
              el("span", { text: "今天可選夢想" }),
              el("strong", { text: dreamPreview }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "cashflow-setup-grid",
        children: state.players.map((player, index) => renderPlayerSetupCard({ challenge, player, index, onUpdatePlayerSetup })),
      }),
      el("div", {
        className: "cashflow-setup-footer",
        children: [
          el("div", {
            children: [
              el("strong", { text: "開局規則" }),
              el("p", { text: "起始現金 0 元。夢想一開始決定，開始後不能中途更換。" }),
            ],
          }),
          el("button", {
            className: "button button--primary",
            text: "開始理財富翁",
            attrs: { type: "button", disabled: allReady ? null : "disabled" },
            on: { click: onStartSetup },
          }),
        ],
      }),
    ],
  });
}

function renderPlayerSetupCard({ challenge, player, index, onUpdatePlayerSetup }) {
  const activeAvatar = getPlayerAvatar(challenge, player);
  const activeJob = getPlayerJob(challenge, player);
  const activeDream = getPlayerDream(challenge, player);
  const nameInput = el("input", {
    className: "cashflow-name-input",
    attrs: {
      type: "text",
      value: player.name,
      maxlength: "8",
      placeholder: `隊伍 ${index + 1}`,
      "aria-label": `隊伍 ${index + 1} 名字`,
    },
  });
  nameInput.addEventListener("change", (event) => onUpdatePlayerSetup(index, { name: event.target.value.trim() || player.name }));
  nameInput.addEventListener("input", (event) => {
    player.name = event.target.value.slice(0, 8);
  });

  return el("section", {
    className: "cashflow-setup-card",
    attrs: { style: `--avatar-color:${activeAvatar.color}; --dream-color:${activeDream.color ?? activeAvatar.color};` },
    children: [
      el("div", {
        className: "cashflow-setup-card__top",
        children: [
          el("div", { className: "cashflow-avatar-preview", text: activeAvatar.icon }),
          el("div", {
            children: [
              el("span", { text: `隊伍 ${index + 1}` }),
              nameInput,
              player.members ? el("small", { className: "cashflow-team-members", text: player.members }) : null,
            ],
          }),
        ],
      }),
      el("div", {
        className: "cashflow-avatar-grid",
        children: challenge.avatarOptions.map((avatar) =>
          el("button", {
            className: `cashflow-avatar-button${avatar.id === player.avatarId ? " is-active" : ""}`,
            attrs: { type: "button", title: avatar.label, style: `--avatar-color:${avatar.color};` },
            text: avatar.icon,
            on: { click: () => onUpdatePlayerSetup(index, { avatarId: avatar.id }) },
          }),
        ),
      }),
      renderSetupSelect("職業", challenge.jobs.map((job) => ({ value: job.id, label: `${job.name}｜收入 ${job.payday}｜支出 ${job.expense}` })), activeJob.id, (value) =>
        onUpdatePlayerSetup(index, { jobId: value }),
      ),
      renderSetupDreamPicker({ challenge, player, onSelect: (dreamId) => onUpdatePlayerSetup(index, { dreamId }) }),
      el("p", { className: "cashflow-setup-note", text: `${activeJob.description} 夢想：${activeDream.icon ?? ""}${activeDream.name}，總財富 ${activeDream.moneyGoal} 元，被動收入 ${activeDream.passiveGoal} 元/回合。` }),
    ],
  });
}

function renderSetupSelect(label, options, value, onChange) {
  const select = el("select", {
    attrs: { "aria-label": label },
    children: options.map((option) =>
      el("option", {
        text: option.label,
        attrs: { value: option.value, selected: option.value === value ? "selected" : null },
      }),
    ),
  });
  select.addEventListener("change", (event) => onChange(event.target.value));

  return el("label", {
    className: "cashflow-setup-select",
    children: [el("span", { text: label }), select],
  });
}

function renderSetupDreamPicker({ challenge, player, onSelect }) {
  return el("div", {
    className: "cashflow-dream-picker",
    children: [
      el("strong", { text: "夢想目標" }),
      el("div", {
        children: challenge.dreams.map((dream) =>
          el("button", {
            className: `cashflow-dream-choice${dream.id === player.dreamId ? " is-active" : ""}`,
            attrs: { type: "button", style: `--dream-color:${dream.color};` },
            on: { click: () => onSelect(dream.id) },
            children: [
              el("span", { text: dream.icon ?? "★" }),
              el("strong", { text: dream.name }),
              el("small", { text: `${dream.moneyGoal} 元｜被動 ${dream.passiveGoal}` }),
            ],
          }),
        ),
      }),
    ],
  });
}

export function applyDateFinanceRoll(challenge, state, roll) {
  const player = state.players[state.activePlayerIndex];
  if (player.finished || state.answered) {
    return;
  }

  const boardSize = getBoardSize(challenge);
  const previousDay = player.day;
  const nextDay = wrapBoardPosition(previousDay + roll, boardSize);
  const passedStart = previousDay + roll > boardSize;
  player.day = nextDay;
  state.lastRoll = roll;
  state.selectedAnswer = "";
  state.answered = false;
  state.result = null;
  state.currentQuestion = null;

  const event = getEventForDay(challenge, nextDay);
  state.lastCard = null;
  applyPassiveIncome(player);
  let eventText = event.text;

  if (event.type === "chance" || event.type === "fate") {
    const card = drawDateCard(challenge, state, player, event.type);
    state.lastCard = { ...card, type: event.type, text: card.text };

    if (event.type === "chance") {
      state.pendingCard = { ...card, type: event.type };
      player.log.unshift(`${getBoardLabel(player.day)}：抽到機會卡，請選擇要或不要。`);
      player.log = player.log.slice(0, 4);
      return;
    }

    const cardText = applyDateCard(challenge, state, player, card);
    state.lastCard = { ...card, type: event.type, text: cardText };
    eventText = `${event.title}卡，${cardText}`;
  } else {
    eventText = applyFinanceEvent(challenge, player, event);
  }

  updateDreamProgress(challenge, player);

  if (player.dreamProgress >= 100 && !player.finished) {
    player.finished = true;
    player.money += challenge.finishBonus;
    player.log.unshift(`達成夢想，獎勵 ${challenge.finishBonus} 元`);
  } else if (passedStart && !player.finished) {
    player.money += challenge.finishBonus;
    player.log.unshift(`走完現金流圈，獎勵 ${challenge.finishBonus} 元，回到起點`);
  } else {
    player.log.unshift(`${getBoardLabel(player.day)}：${eventText}`);
  }

  updateDreamProgress(challenge, player);
  state.currentQuestion = buildQuestion(challenge, state, player);
  player.log = player.log.slice(0, 4);
}

export function decideDateFinanceCard(challenge, state, takeCard) {
  if (!state.pendingCard) {
    return;
  }

  const player = state.players[state.activePlayerIndex];
  const card = state.pendingCard;
  let cardText = `沒有選擇「${card.title}」，保留現金等待下一次機會。`;

  if (takeCard) {
    cardText = applyDateCard(challenge, state, player, card);
  }

  state.lastCard = { ...card, text: cardText, skipped: !takeCard };
  state.pendingCard = null;
  updateDreamProgress(challenge, player);
  player.log.unshift(`${getBoardLabel(player.day)}：${takeCard ? "選擇要" : "選擇不要"}，${cardText}`);
  player.log = player.log.slice(0, 4);
  state.currentQuestion = buildQuestion(challenge, state, player);
}

export function answerDateFinanceQuestion(state, answer, question) {
  if (state.answered) {
    return;
  }

  const player = state.players[state.activePlayerIndex];
  state.currentQuestion = question;
  const isCorrect = answer === question.answer;
  state.selectedAnswer = answer;
  state.answered = true;
  state.result = { isCorrect, answer: question.answer };

  if (isCorrect) {
    player.money += question.reward ?? 15;
    player.correct += 1;
    player.streak = (player.streak ?? 0) + 1;
    player.stars = (player.stars ?? 0) + 1;
    player.log.unshift(`理財任務答對，增加 ${question.reward ?? 15} 元，得到 1 顆星`);
    convertStarsToSavings(player);
    awardFinanceBadges(player);
  } else {
    player.streak = 0;
    player.log.unshift(`理財任務答案是 ${question.answer}`);
  }

  player.log = player.log.slice(0, 4);
}

export function buildFinanceRecord(challenge, state, question) {
  const month = getCurrentMonth(state);
  const player = state.players[state.activePlayerIndex];

  return {
    studentName: player.name,
    day: player.day,
    weekday: getWeekday(challenge, state.startWeekday, player.day),
    weekLabel: `第${getWeekOfMonth(state.startWeekday, player.day)}週`,
    money: player.money,
    saved: player.saved,
    assets: player.assets,
    passiveIncome: player.passiveIncome,
    dreamProgress: player.dreamProgress,
    correctCount: player.correct,
    roll: state.lastRoll,
    cardType: state.lastCard?.type ?? "",
    cardTitle: state.lastCard?.title ?? "",
    eventText: state.lastCard?.text ?? player.log[0] ?? "",
    question: question.prompt,
    selectedAnswer: state.selectedAnswer,
    correctAnswer: question.answer,
    isCorrect: Boolean(state.result?.isCorrect),
    monthLabel: month.label,
  };
}

export function advanceDateFinanceTurn(state) {
  state.activePlayerIndex = (state.activePlayerIndex + 1) % state.players.length;
  state.lastRoll = 0;
  state.lastCard = null;
  state.pendingCard = null;
  state.currentQuestion = null;
  state.selectedAnswer = "";
  state.answered = false;
  state.result = null;
}

export function buildQuestion(challenge, state, player) {
  const job = getPlayerJob(challenge, player);
  const necessaryExpense = job.expense;
  const afterExpense = Math.max(0, player.money - necessaryExpense);
  const totalAsset = player.money + player.saved;
  const netWorth = player.money + player.saved + player.assets;
  const dream = getPlayerDream(challenge, player);
  const dreamGap = Math.max(0, dream.moneyGoal - netWorth);
  const passiveGap = Math.max(0, dream.passiveGoal - player.passiveIncome);
  const afterPayday = player.money + job.payday + player.passiveIncome;
  const assetIncomeAfterBuy = player.passiveIncome + 20;
  const savePlan = Math.min(player.money, 50);
  const afterSave = player.money - savePlan;
  const shopPrice = Math.min(player.money + 20, 80 + (player.day % 4) * 10);
  const afterShop = Math.max(0, player.money - shopPrice);
  const dreamPart = Math.min(dream.moneyGoal, netWorth + 100);
  const dreamPartGap = Math.max(0, dream.moneyGoal - dreamPart);
  const questions = [
    {
      kind: "收入",
      prompt: `${job.name} 每次領錢 ${job.payday} 元，加上被動收入 ${player.passiveIncome} 元，這回合會進帳多少元？`,
      formula: `${job.payday} + ${player.passiveIncome}`,
      answer: `${job.payday + player.passiveIncome}元`,
      options: buildMoneyOptions(job.payday + player.passiveIncome),
      reward: 20,
    },
    {
      kind: "合起來",
      prompt: `現在現金 ${player.money} 元、存款 ${player.saved} 元，合起來有多少元？`,
      formula: `${player.money} + ${player.saved}`,
      answer: `${totalAsset}元`,
      options: buildMoneyOptions(totalAsset),
      reward: 15,
    },
    {
      kind: "支出",
      prompt: `${job.name} 的必要支出是 ${necessaryExpense} 元，現在現金 ${player.money} 元，付完還剩多少元？`,
      formula: `${player.money} - ${necessaryExpense}`,
      answer: `${afterExpense}元`,
      options: buildMoneyOptions(afterExpense),
      reward: 20,
    },
    {
      kind: "總財富",
      prompt: `現在現金 ${player.money} 元、存款 ${player.saved} 元、資產 ${player.assets} 元，總財富是多少元？`,
      formula: `${player.money} + ${player.saved} + ${player.assets}`,
      answer: `${netWorth}元`,
      options: buildMoneyOptions(netWorth),
      reward: 20,
    },
    {
      kind: "收入後",
      prompt: `如果現在領到職業收入 ${job.payday} 元和被動收入 ${player.passiveIncome} 元，現金會變成多少元？`,
      formula: `${player.money} + ${job.payday} + ${player.passiveIncome}`,
      answer: `${afterPayday}元`,
      options: buildMoneyOptions(afterPayday),
      reward: 20,
    },
    {
      kind: "資產",
      prompt: `如果買一個小資產讓被動收入增加 20 元，新的被動收入會是多少元？`,
      formula: `${player.passiveIncome} + 20`,
      answer: `${assetIncomeAfterBuy}元`,
      options: buildMoneyOptions(assetIncomeAfterBuy),
      reward: 20,
    },
    {
      kind: "夢想",
      prompt: `${dream.name} 需要 ${dream.moneyGoal} 元總財富，現在還差多少元？`,
      formula: `${dream.moneyGoal} - ${netWorth}`,
      answer: `${dreamGap}元`,
      options: buildMoneyOptions(dreamGap),
      reward: 20,
    },
    {
      kind: "被動收入",
      prompt: `${dream.name} 需要每回合被動收入 ${dream.passiveGoal} 元，現在還差多少元？`,
      formula: `${dream.passiveGoal} - ${player.passiveIncome}`,
      answer: `${passiveGap}元`,
      options: buildMoneyOptions(passiveGap),
      reward: 20,
    },
    {
      kind: "儲蓄",
      prompt: `如果把 ${savePlan} 元存進銀行，現金會剩多少元？`,
      formula: `${player.money} - ${savePlan}`,
      answer: `${afterSave}元`,
      options: buildMoneyOptions(afterSave),
      reward: 15,
    },
    {
      kind: "購物判斷",
      prompt: `想買的東西要 ${shopPrice} 元，現在現金 ${player.money} 元，買完最多還剩多少元？`,
      formula: `${player.money} - ${shopPrice}`,
      answer: `${afterShop}元`,
      options: buildMoneyOptions(afterShop),
      reward: 15,
    },
    {
      kind: "目標距離",
      prompt: `${dream.name} 的目標是 ${dream.moneyGoal} 元，如果總財富先到 ${dreamPart} 元，還差多少元？`,
      formula: `${dream.moneyGoal} - ${dreamPart}`,
      answer: `${dreamPartGap}元`,
      options: buildMoneyOptions(dreamPartGap),
      reward: 20,
    },
  ];

  return questions[player.day % questions.length];
}

function renderControlPanel({
  challenge,
  state,
  activePlayer,
  onSelectPlayer,
  onShowResetLock,
  onCancelResetLock,
  onSubmitResetPassword,
}) {
  const passwordInput = el("input", {
    className: "date-reset-input",
    attrs: {
      type: "password",
      inputmode: "numeric",
      maxlength: "4",
      placeholder: "輸入 0000",
      "aria-label": "重新開始密碼",
    },
  });
  const activeJob = getPlayerJob(challenge, activePlayer);
  const activeDream = getPlayerDream(challenge, activePlayer);
  const activeAvatar = getPlayerAvatar(challenge, activePlayer);

  return el("aside", {
    className: "date-control-card",
    children: [
      el("div", {
        className: "cashflow-setting-card cashflow-setting-card--locked",
        attrs: { style: `--avatar-color:${activeAvatar.color}; --dream-color:${activeDream.color ?? activeAvatar.color};` },
        children: [
          el("div", { className: "cashflow-avatar-preview", text: activeAvatar.icon }),
          el("div", {
            children: [
              el("span", { className: "cashflow-locked-label", text: "已鎖定角色" }),
              el("strong", { text: activePlayer.name }),
              el("p", { text: `${activeJob.name}｜${activeDream.icon ?? ""}${activeDream.name}` }),
              activePlayer.members ? el("p", { text: `隊員：${activePlayer.members}` }) : null,
              el("p", { text: `夢想目標：總財富 ${activeDream.moneyGoal} 元，被動收入 ${activeDream.passiveGoal} 元/回合。` }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "date-player-list",
        children: state.players.map((player, index) =>
          el("button", {
            className: `date-player-card${index === state.activePlayerIndex ? " is-active" : ""}${player.finished ? " is-finished" : ""}`,
            attrs: { type: "button" },
            on: { click: () => onSelectPlayer(index) },
            children: [
              el("strong", { text: `${getPlayerAvatar(challenge, player).icon} ${player.name}` }),
              el("span", { text: `第 ${player.day} 格` }),
              player.members ? el("small", { text: `隊員：${player.members}` }) : null,
              el("small", { text: `${getPlayerJob(challenge, player).name}｜${getPlayerDream(challenge, player).name}` }),
              el("small", { text: `現金 ${player.money}｜存款 ${player.saved}｜被動 ${player.passiveIncome}` }),
            ],
          }),
        ),
      }),
      el("button", {
        className: "button button--ghost button--full",
        text: "重新開始",
        attrs: { type: "button" },
        on: { click: onShowResetLock },
      }),
      state.resetUnlocked
        ? el("div", {
            className: "date-reset-lock",
            children: [
              passwordInput,
              el("div", {
                className: "button-row",
                children: [
                  el("button", {
                    className: "button button--primary",
                    text: "確認重開",
                    attrs: { type: "button" },
                    on: { click: () => onSubmitResetPassword(passwordInput.value) },
                  }),
                  el("button", {
                    className: "button button--secondary",
                    text: "取消",
                    attrs: { type: "button" },
                    on: { click: onCancelResetLock },
                  }),
                ],
              }),
            ],
          })
        : null,
    ],
  });
}

function renderCircularBoard({ challenge, state, month, activePlayer, onRollDice, stateStatus }) {
  const allFinished = state.players.every((player) => player.finished);
  const activeJob = getPlayerJob(challenge, activePlayer);
  const activeDream = getPlayerDream(challenge, activePlayer);
  const boardSize = getBoardSize(challenge);
  return el("article", {
    className: "date-board-card date-board-card--rectangle",
    children: [
      el("div", {
        className: "date-board-head",
        children: [
          el("h3", { text: "現金流圈" }),
          el("div", {
            className: "button-row",
            children: [
              stateStatus ? el("span", { className: "pill", text: stateStatus }) : null,
              el("span", { className: "pill", text: `${boardSize} 格` }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "cashflow-goal-strip",
        children: [
          renderGoalCard("目前職業", `${activeJob.name} +${activeJob.payday}`),
          renderGoalCard(`${activeDream.icon ?? ""}${activeDream.name}`, `${activeDream.moneyGoal} 元`),
          renderGoalCard("被動目標", `${activeDream.passiveGoal} 元/回合`),
          renderGoalCard("走完一圈", `+${challenge.finishBonus} 元`),
        ],
      }),
      el("div", {
        className: "date-rectangle-board",
        attrs: { style: "--date-board-columns:11; --date-board-rows:7;" },
        children: [
          ...Array.from({ length: boardSize }, (_, index) =>
            renderCalendarCell(challenge, state, index + 1),
          ),
          renderDiceCenter({ challenge, state, activePlayer, onRollDice, disabled: state.isRolling || activePlayer.finished || state.lastRoll || allFinished }),
        ],
      }),
    ],
  });
}

function renderCalendarCell(challenge, state, day) {
  const event = getEventForDay(challenge, day);
  const playersHere = state.players.filter((player) => player.day === day);
  const position = getRectangleBoardPosition(day - 1);

  return el("div", {
    className: `date-cell date-cell--${event.type}`,
    attrs: { style: `--date-cell-row:${position.row}; --date-cell-col:${position.col};` },
    children: [
      el("strong", { text: String(day) }),
      el("span", { text: getCashflowCellTitle(event) }),
      el("small", { text: getShortEventLabel(event) }),
      playersHere.length
        ? el("div", {
            className: "date-cell__players",
            children: playersHere.map((player) => el("i", { text: player.name.slice(0, 1) })),
          })
        : null,
    ],
  });
}

function renderDiceCenter({ challenge, state, activePlayer, onRollDice, disabled }) {
  const dreamProgress = Math.min(100, activePlayer.dreamProgress ?? 0);
  const avatar = getPlayerAvatar(challenge, activePlayer);
  return el("div", {
    className: "date-center-stage",
    children: [
      el("span", { className: "badge badge--live", text: `輪到 ${avatar.icon} ${activePlayer.name}` }),
      el("div", {
        className: "cashflow-dream-meter",
        children: [
          el("span", { text: "夢想進度" }),
          el("div", { children: [el("i", { attrs: { style: `width:${dreamProgress}%;` } })] }),
          el("strong", { text: `${dreamProgress}%` }),
        ],
      }),
      el("button", {
        className: `date-dice${state.lastRoll ? " has-rolled" : ""}${state.isRolling ? " is-rolling" : ""}`,
        attrs: { type: "button", disabled: disabled ? "disabled" : null, "aria-label": "擲骰子" },
        on: { click: onRollDice },
        children: [
          el("span", { text: state.isRolling ? "..." : state.lastRoll ? String(state.lastRoll) : "?" }),
          ...getDicePips(state.lastRoll).map((pip) => el("i", { className: `date-dice__pip date-dice__pip--${pip}` })),
        ],
      }),
      el("strong", { text: state.isRolling ? "擲骰中..." : state.lastRoll ? `前進 ${state.lastRoll} 天` : "按骰子前進" }),
      state.lastCard
        ? el("div", {
            className: `date-card-reveal date-card-reveal--${state.lastCard.type}`,
            children: [
              el("div", {
                className: "date-card-reveal__back",
                text: state.lastCard.type === "chance" ? "機會" : "命運",
              }),
              el("div", {
                className: "date-card-reveal__front",
                children: [
                  el("span", { text: state.lastCard.type === "chance" ? "機會卡" : "命運卡" }),
                  el("strong", { text: state.lastCard.title }),
                  el("p", { text: state.lastCard.text }),
                ],
              }),
            ],
          })
        : el("p", { text: "累積資產與被動收入，往夢想前進。" }),
    ],
  });
}

function renderMissionPanel({ challenge, state, activePlayer, currentQuestion, onChooseAnswer, onChooseCardDecision, onNextTurn }) {
  const activeJob = getPlayerJob(challenge, activePlayer);
  const activeDream = getPlayerDream(challenge, activePlayer);
  const hasPendingCard = Boolean(state.pendingCard);
  return el("aside", {
    className: "date-mission-card",
    children: [
      el("div", {
        className: "date-wallet",
        children: [
          el("span", { text: `${getPlayerAvatar(challenge, activePlayer).icon} ${activePlayer.name}` }),
          el("strong", { text: `${activePlayer.money} 元` }),
          el("small", { text: `職業：${activeJob.name}｜夢想：${activeDream.name}` }),
          el("small", { text: `存款 ${activePlayer.saved}｜資產 ${activePlayer.assets}｜被動 ${activePlayer.passiveIncome}/回合` }),
          renderGameTokens(activePlayer),
          renderCashflowSheet(activePlayer),
        ],
      }),
      el("div", {
        className: "date-question-card",
        children: [
          el("div", {
            className: "date-question-head",
            children: [
              el("span", { className: "badge badge--warm", text: "理財任務" }),
              currentQuestion.kind ? el("span", { className: "pill", text: currentQuestion.kind }) : null,
            ],
          }),
          el("h3", { text: hasPendingCard ? "先決定這張機會卡要不要。" : currentQuestion.prompt }),
          hasPendingCard
            ? renderChanceDecisionCard(state.pendingCard, onChooseCardDecision)
            : null,
          hasPendingCard
            ? null
            : el("div", {
                className: "date-answer-grid",
                children: currentQuestion.options.map((option) =>
                  el("button", {
                    className: getAnswerClass(option, state),
                    text: option,
                    attrs: { type: "button", disabled: !state.lastRoll || state.answered ? "disabled" : null },
                    on: { click: () => onChooseAnswer(option, currentQuestion) },
                  }),
                ),
              }),
          state.result
            ? el("p", {
                className: `decimal-feedback ${state.result.isCorrect ? "is-correct" : "is-wrong"}`,
              text: state.result.isCorrect ? `答對了，增加 ${currentQuestion.reward ?? 15} 元。` : `答案是 ${state.result.answer}。`,
            })
            : null,
        ],
      }),
      el("div", {
        className: "date-log-card",
        children: [
          el("strong", { text: "紀錄" }),
          ...activePlayer.log.map((item) => el("p", { text: item })),
        ],
      }),
      el("button", {
        className: "button button--primary button--full",
        text: activePlayer.finished ? "換下一位" : "下一位",
        attrs: { type: "button", disabled: hasPendingCard || (!state.answered && state.lastRoll) ? "disabled" : null },
        on: { click: onNextTurn },
      }),
    ],
  });
}

function renderChanceDecisionCard(card, onChooseCardDecision) {
  return el("div", {
    className: "cashflow-decision-card",
    children: [
      el("span", { className: "badge badge--live", text: "機會選擇" }),
      el("strong", { text: card.title }),
      el("p", { text: card.text }),
      card.lesson ? el("small", { text: card.lesson }) : null,
      el("div", {
        className: "cashflow-decision-actions",
        children: [
          el("button", {
            className: "button button--primary",
            text: "要",
            attrs: { type: "button" },
            on: { click: () => onChooseCardDecision(true) },
          }),
          el("button", {
            className: "button button--secondary",
            text: "不要",
            attrs: { type: "button" },
            on: { click: () => onChooseCardDecision(false) },
          }),
        ],
      }),
    ],
  });
}

function renderGameTokens(player) {
  const badges = player.badges?.length ? player.badges : ["努力中"];
  return el("div", {
    className: "cashflow-token-row",
    children: [
      el("span", { text: `星星 ${player.stars ?? 0}/3` }),
      el("span", { text: `連答 ${player.streak ?? 0}` }),
      ...badges.slice(-2).map((badge) => el("span", { text: badge })),
    ],
  });
}

function renderCashflowSheet(player) {
  const netWorth = player.money + player.saved + player.assets;
  return el("div", {
    className: "cashflow-sheet",
    children: [
      renderSheetItem("現金", `${player.money}`),
      renderSheetItem("存款", `${player.saved}`),
      renderSheetItem("資產", `${player.assets}`),
      renderSheetItem("被動", `${player.passiveIncome}`),
      renderSheetItem("總財富", `${netWorth}`),
      renderSheetItem("夢想", `${Math.min(100, player.dreamProgress ?? 0)}%`),
    ],
  });
}

function renderSheetItem(label, value) {
  return el("div", {
    className: "cashflow-sheet__item",
    children: [
      el("span", { text: label }),
      el("strong", { text: value }),
    ],
  });
}

function renderGoalCard(label, value) {
  return el("div", {
    className: "cashflow-goal-card",
    children: [
      el("span", { text: label }),
      el("strong", { text: value }),
    ],
  });
}

function renderSelect(label, options, value, onChange) {
  const select = el("select", {
    attrs: { "aria-label": label },
    children: options.map((option) =>
      el("option", {
        text: option.label,
        attrs: { value: option.value, selected: option.value === value ? "selected" : null },
      }),
    ),
  });
  select.addEventListener("change", (event) => onChange(Number(event.target.value)));

  return el("label", {
    className: "date-select-card",
    children: [el("span", { text: label }), select],
  });
}

function renderTextSelect(label, options, value, onChange) {
  const select = el("select", {
    attrs: { "aria-label": label },
    children: options.map((option) =>
      el("option", {
        text: option.label,
        attrs: { value: option.value, selected: option.value === value ? "selected" : null },
      }),
    ),
  });
  select.addEventListener("change", (event) => onChange(event.target.value));

  return el("label", {
    className: "date-select-card",
    children: [el("span", { text: label }), select],
  });
}

function getEventForDay(challenge, day) {
  const events = challenge.events?.length ? challenge.events : [{ type: "income", title: "", amount: 0, text: "" }];
  return events[(day - 1) % events.length];
}

function getShortEventLabel(event) {
  if (event.type === "chance") return "機";
  if (event.type === "fate") return "命";
  if (event.type === "payday") return "領";
  if (event.type === "asset") return "資";
  if (event.type === "dream") return "夢";
  if (event.type === "income") return `+${event.amount}`;
  if (event.type === "expense") return `${event.amount}`;
  return "存";
}

function getCashflowCellTitle(event) {
  const labels = {
    payday: "領錢",
    income: "收入",
    expense: "支出",
    saving: "存款",
    asset: "資產",
    chance: "機會",
    fate: "命運",
    dream: "夢想",
  };
  return labels[event.type] ?? event.title;
}

function getWeekday(challenge, startWeekday, day) {
  return challenge.weekdays[(startWeekday + day - 1) % 7];
}

function getWeekOfMonth(startWeekday, day) {
  return Math.ceil((startWeekday + day) / 7);
}

function buildMoneyOptions(answer) {
  const correctOption = `${answer}元`;
  const candidates = [answer + 10, answer - 10, answer + 5, answer - 5, answer + 20, answer - 20, answer + 30, answer - 30]
    .filter((value) => value >= 0);
  const distractors = shuffleOptions(uniqueOptions(candidates.map((value) => `${value}元`)).filter((option) => option !== correctOption))
    .slice(0, 2);
  return shuffleOptions([correctOption, ...distractors]);
}

function uniqueOptions(options) {
  return [...new Set(options)];
}

function shuffleOptions(options) {
  const shuffled = [...options];

  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }

  return shuffled;
}

function formatMonthDay(month, day) {
  return `${month.label} ${day} 日`;
}

function getDicePips(roll) {
  const pips = {
    0: ["top-left", "top-right", "middle-left", "middle-right", "bottom-left", "bottom-right"],
    1: ["center"],
    2: ["top-left", "bottom-right"],
    3: ["top-left", "center", "bottom-right"],
    4: ["top-left", "top-right", "bottom-left", "bottom-right"],
    5: ["top-left", "top-right", "center", "bottom-left", "bottom-right"],
    6: ["top-left", "top-right", "middle-left", "middle-right", "bottom-left", "bottom-right"],
  };

  return pips[roll || 0];
}

function getRectangleBoardPosition(index) {
  const columns = 11;
  const rows = 7;
  const rightStart = columns;
  const bottomStart = rightStart + rows - 2;
  const leftStart = bottomStart + columns;

  if (index < rightStart) {
    return { row: 1, col: index + 1 };
  }

  if (index < bottomStart) {
    return { row: index - rightStart + 2, col: columns };
  }

  if (index < leftStart) {
    return { row: rows, col: columns - (index - bottomStart) };
  }

  return { row: rows - (index - leftStart) - 1, col: 1 };
}

function drawDateCard(challenge, state, player, type) {
  const cards = type === "chance" ? challenge.chanceCards : challenge.fateCards;
  const index = (player.day + state.activePlayerIndex + state.lastRoll) % cards.length;
  return cards[index];
}

function applyDateCard(challenge, state, player, card) {
  let outcomeText = card.text;

  if (card.asset && card.money && card.money < 0) {
    const cost = Math.abs(card.money);

    if (player.money < cost) {
      updateDreamProgress(challenge, player);
      return `需要 ${cost} 元才可以買，現金不夠，這次先不買。`;
    }

    player.money -= cost;
    player.assets += card.asset;
    player.passiveIncome += card.passive ?? 0;

    if (card.move) {
      player.day = wrapBoardPosition(player.day + card.move, getBoardSize(challenge));
    }

    updateDreamProgress(challenge, player);
    return outcomeText;
  }

  if (card.money) {
    if (card.money < 0) {
      const paid = Math.min(player.money, Math.abs(card.money));
      player.money -= paid;
      outcomeText = paid === Math.abs(card.money) ? card.text : `現金不夠，先付出 ${paid} 元。`;
    } else {
      player.money += card.money;
    }
  }

  if (card.saving) {
    const saved = Math.min(player.money, card.saving);
    player.money -= saved;
    player.saved += saved;
    outcomeText = saved > 0 ? `把 ${saved} 元存起來。` : "目前沒有現金可存。";
  }

  if (card.asset) {
    player.assets += card.asset;
  }

  if (card.passive) {
    player.passiveIncome += card.passive;
  }

  if (card.move) {
    player.day = wrapBoardPosition(player.day + card.move, getBoardSize(challenge));
  }

  updateDreamProgress(challenge, player);
  return outcomeText;
}

function applyFinanceEvent(challenge, player, event) {
  const job = getPlayerJob(challenge, player);

  if (event.type === "saving") {
    const saved = Math.min(player.money, event.amount);
    player.money -= saved;
    player.saved += saved;
    return saved > 0 ? `把 ${saved} 元存進銀行。` : "目前沒有現金可存。";
  }

  if (event.type === "asset") {
    if (player.money < event.cost) {
      return `資產需要 ${event.cost} 元，現金不夠，這次先不買。`;
    }

    player.money -= event.cost;
    player.assets += event.cost;
    player.passiveIncome += event.passive;
    return `買資產花 ${event.cost} 元，被動收入增加 ${event.passive} 元。`;
  }

  if (event.type === "dream") {
    updateDreamProgress(challenge, player);
    return "檢查夢想進度。";
  }

  if (event.type === "payday") {
    player.money += job.payday;
    return `領取 ${job.name} 職業收入 ${job.payday} 元。`;
  }

  if (event.type === "expense") {
    const paid = Math.min(player.money, job.expense);
    player.money -= paid;
    return `支付必要支出 ${paid} 元。`;
  }

  const amount = event.amount ?? 0;
  if (amount < 0) {
    const paid = Math.min(player.money, Math.abs(amount));
    player.money -= paid;
    return `支出 ${paid} 元。`;
  }

  player.money += amount;
  return `收入 ${amount} 元。`;
}

function applyPassiveIncome(player) {
  if (player.passiveIncome > 0) {
    player.money += player.passiveIncome;
  }
}

function updateDreamProgress(challenge, player) {
  const dream = getPlayerDream(challenge, player);
  const netWorth = player.money + player.saved + player.assets;
  const moneyProgress = Math.min(100, Math.round((netWorth / dream.moneyGoal) * 100));
  const passiveProgress = Math.min(100, Math.round((player.passiveIncome / dream.passiveGoal) * 100));
  player.dreamProgress = Math.min(100, Math.round((moneyProgress + passiveProgress) / 2));
}

function convertStarsToSavings(player) {
  if ((player.stars ?? 0) < 3) {
    return;
  }

  player.stars -= 3;
  player.saved += 50;
  player.log.unshift("集滿 3 顆星，自動存入 50 元。");
}

function awardFinanceBadges(player) {
  const badges = new Set(player.badges ?? []);

  if (player.saved >= 100) {
    badges.add("儲蓄家");
  }

  if (player.passiveIncome >= 50) {
    badges.add("資產家");
  }

  if ((player.streak ?? 0) >= 3) {
    badges.add("連勝王");
  }

  player.badges = [...badges];
}

function getPlayerJob(challenge, player) {
  return challenge.jobs.find((job) => job.id === player.jobId) ?? challenge.jobs[0];
}

function getPlayerDream(challenge, player) {
  return challenge.dreams.find((dream) => dream.id === player.dreamId) ?? challenge.dreams[0];
}

function getPlayerAvatar(challenge, player) {
  const fallback = challenge.avatarOptions?.[0] ?? { id: "fox", icon: "●", label: "玩家", color: "#57aeb2" };
  return challenge.avatarOptions?.find((avatar) => avatar.id === player.avatarId) ?? fallback;
}

function getCurrentMonth(state) {
  return {
    label: "本月",
    days: state.monthDays,
  };
}

function getBoardLabel(day) {
  return `第 ${day} 格`;
}

function getBoardSize(challenge) {
  return challenge.boardSize ?? 32;
}

function wrapBoardPosition(position, boardSize) {
  return ((position - 1 + boardSize) % boardSize) + 1;
}

function getAnswerClass(option, state) {
  if (!state.answered) {
    return "date-answer-button";
  }

  if (option === state.result?.answer) {
    return "date-answer-button is-correct";
  }

  if (option === state.selectedAnswer) {
    return "date-answer-button is-wrong";
  }

  return "date-answer-button";
}

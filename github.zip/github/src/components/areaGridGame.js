import { el, sectionTitle } from "../utils/dom.js";

export function createAreaGridQuestions() {
  return Array.from({ length: 30 }, (_, index) => {
    const { rows, cols, fullCells, halfCells } = buildConnectedAreaSpec(index + 1);
    const answer = fullCells.length + halfCells.length * 0.5;
    const options = buildAreaOptions(answer, index);
    return {
      id: `area-grid-${index + 1}`,
      title: `第 ${index + 1} 題`,
      prompt: "數一數湖水藍色圖形共有多少平方公分。",
      rows,
      cols,
      cells: buildAreaCellMap(fullCells, halfCells),
      answer,
      options,
    };
  });
}

export function createAreaGridState() {
  return {
    roundIndex: 0,
    selected: null,
    isAnswered: false,
    score: 0,
    activeQuestion: null,
    customRows: 10,
    customCols: 10,
    customTool: "full",
    customCells: {},
  };
}

export function buildCustomAreaQuestion(state) {
  const rows = clampGridSize(state.customRows);
  const cols = clampGridSize(state.customCols);
  const cells = {};

  Object.entries(state.customCells).forEach(([key, value]) => {
    const [row, col] = key.split("-").map(Number);
    if (row < rows && col < cols && getCellAreaValue(value) > 0) {
      cells[key] = value;
    }
  });

  const answer = getAreaAnswer(cells);
  return {
    id: "area-custom",
    title: "自訂圖形",
    prompt: "數一數自訂圖形共有多少平方公分。",
    rows,
    cols,
    cells,
    answer,
    options: buildAreaOptions(answer || 1, 7),
  };
}

export function buildRandomAreaQuestion(index = 0) {
  const { rows, cols, fullCells, halfCells } = buildConnectedAreaSpec(Date.now() + index, true);
  const cells = buildAreaCellMap(fullCells, halfCells);
  const answer = getAreaAnswer(cells);
  return {
    id: `area-random-${Date.now()}`,
    title: "隨機題",
    prompt: "數一數隨機圖形共有多少平方公分。",
    rows,
    cols,
    cells,
    answer,
    options: buildAreaOptions(answer || 1, index + rows + cols),
  };
}

function getHalfDirectionTowardFull(row, col, fullKeys, rows, cols) {
  const touchingSides = getNeighborCells(row, col, rows, cols)
    .filter((cell) => fullKeys.has(`${cell.row}-${cell.col}`))
    .map((cell) => {
      if (cell.row < row) return "top";
      if (cell.row > row) return "bottom";
      if (cell.col < col) return "left";
      return "right";
    });

  if (touchingSides.includes("top") && touchingSides.includes("left")) return "half-tl";
  if (touchingSides.includes("top") && touchingSides.includes("right")) return "half-tr";
  if (touchingSides.includes("bottom") && touchingSides.includes("right")) return "half-br";
  if (touchingSides.includes("bottom") && touchingSides.includes("left")) return "half-bl";
  if (touchingSides.includes("top")) return Math.random() < 0.5 ? "half-tl" : "half-tr";
  if (touchingSides.includes("bottom")) return Math.random() < 0.5 ? "half-bl" : "half-br";
  if (touchingSides.includes("left")) return Math.random() < 0.5 ? "half-tl" : "half-bl";
  if (touchingSides.includes("right")) return Math.random() < 0.5 ? "half-tr" : "half-br";
  return "half-tl";
}

function buildConnectedAreaSpec(seed, useRandom = false) {
  const rng = useRandom ? Math.random : createSeededRandom(seed * 7919 + 17);
  const rows = 5 + Math.floor(rng() * 4);
  const cols = 5 + Math.floor(rng() * 4);
  const targetFullCount = Math.min(rows * cols - 5, 6 + Math.floor(rng() * 9));
  const start = {
    row: Math.floor(rows / 2),
    col: Math.floor(cols / 2),
  };
  const fullKeys = new Set([`${start.row}-${start.col}`]);

  while (fullKeys.size < targetFullCount) {
    const expandable = [...fullKeys].map((key) => {
      const [row, col] = key.split("-").map(Number);
      return { row, col };
    }).filter((cell) =>
      getNeighborCells(cell.row, cell.col, rows, cols)
        .some((neighbor) => !fullKeys.has(`${neighbor.row}-${neighbor.col}`)),
    );

    if (!expandable.length) break;

    const base = expandable[Math.floor(rng() * expandable.length)] ?? start;
    const candidates = shuffleAreaCells(getNeighborCells(base.row, base.col, rows, cols), rng)
      .filter((cell) => !fullKeys.has(`${cell.row}-${cell.col}`));

    const next = candidates[0];
    fullKeys.add(`${next.row}-${next.col}`);
  }

  const halfCells = [];
  const halfTarget = seed % 3 === 0 ? 4 : seed % 2 === 0 ? 2 : 0;
  const edgeCandidates = [];
  fullKeys.forEach((key) => {
    const [row, col] = key.split("-").map(Number);
    getNeighborCells(row, col, rows, cols).forEach((cell) => {
      const candidateKey = `${cell.row}-${cell.col}`;
      if (!fullKeys.has(candidateKey) && !edgeCandidates.some((item) => item.key === candidateKey)) {
        edgeCandidates.push({ ...cell, key: candidateKey });
      }
    });
  });

  shuffleAreaCells(edgeCandidates, rng).slice(0, Math.min(halfTarget, edgeCandidates.length)).forEach((cell) => {
    halfCells.push([cell.row, cell.col, getHalfDirectionTowardFull(cell.row, cell.col, fullKeys, rows, cols)]);
  });

  return {
    rows,
    cols,
    fullCells: [...fullKeys].map((key) => key.split("-").map(Number)),
    halfCells,
  };
}

function getNeighborCells(row, col, rows, cols) {
  return [
    { row: row - 1, col },
    { row: row + 1, col },
    { row, col: col - 1 },
    { row, col: col + 1 },
  ].filter((cell) => cell.row >= 0 && cell.col >= 0 && cell.row < rows && cell.col < cols);
}

function shuffleAreaCells(items, rng = Math.random) {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(rng() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function createSeededRandom(seed) {
  let value = Math.max(1, Math.floor(seed) % 2147483647);
  return () => {
    value = (value * 48271) % 2147483647;
    return value / 2147483647;
  };
}

export function renderAreaGridGame({
  questions,
  state,
  onChoose,
  onNext,
  onReset,
  onToggleCustomCell,
  onApplyCustom,
  onClearCustom,
  onRandomQuestion,
  onSetCustomSize,
  onSetCustomTool,
}) {
  const question = state.activeQuestion ?? questions[state.roundIndex];
  const isCorrect = state.isAnswered && state.selected === question.answer;
  const badgeText = state.activeQuestion ? question.title : `${state.roundIndex + 1}/${questions.length}`;

  return el("section", {
    className: "panel area-grid-game",
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("面積數格", "", el("span", { className: "badge badge--live", text: badgeText })),
          el("div", {
            className: "area-grid-layout",
            children: [
              el("article", {
                className: "area-grid-stage",
                children: [
                  renderAreaBoard(question),
                  el("div", {
                    className: "area-grid-question",
                    children: [
                      el("strong", { text: question.prompt }),
                      el("span", { text: "1 個完整方格 = 1 平方公分；2 個半格可以合成 1 平方公分。" }),
                    ],
                  }),
                  renderHalfConceptCard(question, state),
                  renderCustomAreaBuilder({
                    state,
                    onToggleCustomCell,
                    onApplyCustom,
                    onClearCustom,
                    onRandomQuestion,
                    onSetCustomSize,
                    onSetCustomTool,
                  }),
                ],
              }),
              el("aside", {
                className: "area-grid-control",
                children: [
                  el("div", {
                    className: "area-grid-score",
                    children: [
                      el("span", { text: "得分" }),
                      el("strong", { text: `${state.score}` }),
                    ],
                  }),
                  el("div", {
                    className: "area-grid-options",
                    children: question.options.map((option) =>
                      el("button", {
                        className: getOptionClass(option, question.answer, state),
                        text: formatArea(option),
                        attrs: { type: "button", disabled: state.isAnswered ? "disabled" : null },
                        on: { click: () => onChoose(option) },
                      }),
                    ),
                  }),
                  state.isAnswered
                    ? el("div", {
                        className: `area-grid-feedback ${isCorrect ? "is-correct" : "is-wrong"}`,
                        children: [
                          el("strong", { text: isCorrect ? "答對了" : "再看一次" }),
                          el("p", { text: `完整格和半格合起來是 ${formatArea(question.answer)}。` }),
                        ],
                      })
                    : null,
                  el("div", {
                    className: "button-row",
                    children: [
                      el("button", {
                        className: "button button--primary",
                        text: state.activeQuestion || state.roundIndex === questions.length - 1 ? "完成" : "下一題",
                        attrs: { type: "button", disabled: state.isAnswered ? null : "disabled" },
                        on: { click: onNext },
                      }),
                      el("button", {
                        className: "button button--secondary",
                        text: "重新開始",
                        attrs: { type: "button" },
                        on: { click: onReset },
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderAreaBoard(question) {
  return el("div", {
    className: "area-grid-board",
    attrs: {
      style: `--area-rows:${question.rows}; --area-cols:${question.cols};`,
    },
    children: Array.from({ length: question.rows * question.cols }, (_, cellIndex) => {
      const row = Math.floor(cellIndex / question.cols);
      const col = cellIndex % question.cols;
      const value = question.cells[`${row}-${col}`] ?? 0;
      return renderAreaCell(value);
    }),
  });
}

function renderAreaCell(value, onClick) {
  const halfClass = getHalfDirectionClass(value);
  const className = [
    "area-grid-cell",
    value === 1 ? "is-filled" : "",
    isHalfCell(value) ? "is-half" : "",
    halfClass,
  ].filter(Boolean).join(" ");

  return el(onClick ? "button" : "div", {
    className,
    attrs: {
      type: onClick ? "button" : null,
      "aria-label": getCellLabel(value),
    },
    on: onClick ? { click: onClick } : {},
  });
}

function renderHalfConceptCard(question, state) {
  const wholeCount = countAreaValue(question.cells, 1);
  const halfCount = Object.values(question.cells).filter(isHalfCell).length;
  const halfPairs = Math.floor(halfCount / 2);
  const leftHalf = halfCount % 2;
  const message = state.isAnswered
    ? `完整格 ${wholeCount} 個，半格 ${halfCount} 個，可以合成 ${halfPairs} 個完整格${leftHalf ? "，還剩半格" : ""}。`
    : "先找完整格，再把半格兩兩配成 1 平方公分。";

  return el("div", {
    className: "area-half-card",
    children: [
      el("strong", { text: "半格合併" }),
      el("div", {
        className: "area-half-demo",
        children: [
          renderAreaCell(0.5),
          el("span", { text: "+" }),
          renderAreaCell("half-br"),
          el("span", { text: "=" }),
          renderAreaCell(1),
        ],
      }),
      el("p", { text: message }),
    ],
  });
}

function renderCustomAreaBuilder({
  state,
  onToggleCustomCell,
  onApplyCustom,
  onClearCustom,
  onRandomQuestion,
  onSetCustomSize,
  onSetCustomTool,
}) {
  return el("div", {
    className: "area-custom-builder",
    children: [
      el("div", {
        className: "area-custom-builder__head",
        children: [
          el("strong", { text: "自訂圖形" }),
          el("div", {
            className: "area-custom-size",
            children: [
              renderSizeSelect("列", "rows", state.customRows, onSetCustomSize),
              renderSizeSelect("欄", "cols", state.customCols, onSetCustomSize),
            ],
          }),
        ],
      }),
      el("div", {
        className: "area-custom-tools",
        children: [
          { id: "full", label: "完整格" },
          { id: "half-tl", label: "半格↖" },
          { id: "half-tr", label: "半格↗" },
          { id: "half-br", label: "半格↘" },
          { id: "half-bl", label: "半格↙" },
          { id: "erase", label: "橡皮擦" },
        ].map((tool) =>
          el("button", {
            className: `area-custom-tool${state.customTool === tool.id ? " is-active" : ""}`,
            text: tool.label,
            attrs: { type: "button", "data-tool": tool.id },
            on: { click: (event) => onSetCustomTool(tool.id, event.currentTarget) },
          }),
        ),
      }),
      el("div", {
        className: "area-custom-board",
        attrs: { style: `--area-rows:${state.customRows}; --area-cols:${state.customCols};` },
        children: Array.from({ length: state.customRows * state.customCols }, (_, cellIndex) => {
          const row = Math.floor(cellIndex / state.customCols);
          const col = cellIndex % state.customCols;
          const key = `${row}-${col}`;
          return renderAreaCell(state.customCells[key] ?? 0, (event) => onToggleCustomCell(key, event.currentTarget));
        }),
      }),
      el("div", {
        className: "area-custom-actions",
        children: [
          el("button", {
            className: "button button--primary",
            text: "套用自訂圖形",
            attrs: { type: "button" },
            on: { click: onApplyCustom },
          }),
          el("button", {
            className: "button button--secondary",
            text: "清空圖形",
            attrs: { type: "button" },
            on: { click: onClearCustom },
          }),
          el("button", {
            className: "button button--secondary",
            text: "隨機出題",
            attrs: { type: "button" },
            on: { click: onRandomQuestion },
          }),
        ],
      }),
    ],
  });
}

function renderSizeSelect(label, field, value, onSetCustomSize) {
  return el("label", {
    children: [
      el("span", { text: label }),
      el("select", {
        on: { change: (event) => onSetCustomSize(field, Number(event.target.value)) },
        children: Array.from({ length: 11 }, (_, index) => index + 10).map((size) =>
          el("option", {
            text: `${size}`,
            attrs: { value: size, selected: size === value ? "selected" : null },
          }),
        ),
      }),
    ],
  });
}

function buildAreaOptions(answer, index) {
  const candidates = [answer, answer - 1, answer - 0.5, answer + 0.5, answer + 1, answer + 2]
    .filter((value) => value > 0);
  const unique = [...new Set(candidates)];
  while (unique.length < 4) {
    unique.push(answer + unique.length + 1);
  }
  return unique.slice(0, 4).sort((a, b) => ((a + index) % 3) - ((b + index) % 3));
}

function getOptionClass(option, answer, state) {
  const classes = ["area-grid-option"];
  if (!state.isAnswered && state.selected === option) classes.push("is-selected");
  if (state.isAnswered && option === answer) classes.push("is-correct");
  if (state.isAnswered && state.selected === option && option !== answer) classes.push("is-wrong");
  return classes.join(" ");
}

function buildAreaCellMap(fullCells, halfCells) {
  const cells = {};
  fullCells.forEach(([row, col]) => {
    cells[`${row}-${col}`] = 1;
  });
  halfCells.forEach(([row, col, direction], index) => {
    const directions = ["half-tl", "half-tr", "half-br", "half-bl"];
    if (!cells[`${row}-${col}`]) cells[`${row}-${col}`] = direction ?? directions[index % directions.length];
  });
  return cells;
}

function buildHalfCells(index, rows, cols, fullCells) {
  if (index % 3 !== 0) return [];
  const fullSet = new Set(fullCells.map(([row, col]) => `${row}-${col}`));
  const halves = [];

  for (let row = 0; row < rows && halves.length < 4; row += 1) {
    for (let col = 0; col < cols && halves.length < 4; col += 1) {
      const key = `${row}-${col}`;
      if (!fullSet.has(key) && (row + col + index) % 2 === 0) {
        halves.push([row, col]);
      }
    }
  }

  return halves;
}

function getAreaAnswer(cells) {
  return Object.values(cells).reduce((sum, value) => sum + getCellAreaValue(value), 0);
}

function countAreaValue(cells, target) {
  return Object.values(cells).filter((value) => value === target).length;
}

function clampGridSize(value) {
  return Math.min(20, Math.max(10, Number(value) || 10));
}

function isHalfCell(value) {
  return value === 0.5 || String(value).startsWith("half-");
}

function getCellAreaValue(value) {
  if (value === 1) return 1;
  if (isHalfCell(value)) return 0.5;
  return 0;
}

function getHalfDirectionClass(value) {
  if (value === 0.5 || value === "half-tl") return "is-half-tl";
  if (value === "half-tr") return "is-half-tr";
  if (value === "half-br") return "is-half-br";
  if (value === "half-bl") return "is-half-bl";
  return "";
}

function getCellLabel(value) {
  if (value === 1) return "完整方格";
  if (isHalfCell(value)) return "半格";
  return "空白方格";
}

function formatArea(value) {
  return Number.isInteger(value) ? `${value} 平方公分` : `${value} 平方公分`;
}

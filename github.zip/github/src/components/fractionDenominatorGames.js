import { el, sectionTitle } from "../utils/dom.js";
import { renderFractionPizza } from "./fractionSameDenominatorGame.js?v=20260610-fraction-gameplay2";

const denominatorQuestions = [
  [1, 4], [3, 8], [2, 5], [5, 6], [7, 10], [4, 9],
  [6, 12], [2, 7], [9, 11], [1, 3], [8, 12], [5, 10],
];

export function getFractionDenominatorQuestion(roundIndex) {
  const [numerator, denominator] = denominatorQuestions[roundIndex % denominatorQuestions.length];
  return { numerator, denominator };
}

const matchCardSpecs = [
  [1, 4], [3, 4], [2, 6], [5, 6], [1, 8], [7, 8],
  [4, 10], [9, 10], [3, 12], [11, 12], [2, 5], [4, 5],
];

export function createFractionExtraState() {
  return {
    denominatorRound: 0,
    denominatorSelected: null,
    denominatorScore: 0,
    cutDenominator: 6,
    matchCards: buildMatchCards(),
    matchSelected: [],
    matchSolved: [],
    matchMessage: "翻兩張分數卡，找分母一樣的朋友。",
    matchMoves: 0,
  };
}

export function renderFractionDenominatorGames({
  state,
  onChooseDenominator,
  onNextDenominator,
  onSetCutDenominator,
  onFlipMatchCard,
  onResetMatch,
}) {
  return el("section", {
    className: "panel fraction-extra-games",
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("分母延伸遊戲", "", el("span", { className: "badge badge--live", text: "新增活動" })),
          el("div", {
            className: "fraction-extra-grid",
            children: [
              renderDenominatorQuest({ state, onChooseDenominator, onNextDenominator }),
              renderPizzaCutLab({ state, onSetCutDenominator }),
              renderDenominatorMatch({ state, onFlipMatchCard, onResetMatch }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderDenominatorQuest({ state, onChooseDenominator, onNextDenominator }) {
  const { numerator, denominator } = getFractionDenominatorQuestion(state.denominatorRound);
  const options = buildDenominatorOptions(denominator, state.denominatorRound);
  const hasAnswered = state.denominatorSelected !== null;
  const isCorrect = state.denominatorSelected === denominator;

  return el("article", {
    className: "fraction-extra-card fraction-denominator-quest",
    children: [
      el("div", {
        className: "fraction-extra-card__head",
        children: [
          el("span", { text: "遊戲一" }),
          el("strong", { text: "分母快找" }),
          el("em", { text: `${state.denominatorScore} 分` }),
        ],
      }),
      el("div", {
        className: "fraction-big-card",
        children: [
          el("strong", { text: `${numerator}` }),
          el("span"),
          el("strong", { text: `${denominator}` }),
        ],
      }),
      el("div", {
        className: "fraction-denominator-options",
        children: options.map((option) =>
          el("button", {
            className: getDenominatorOptionClass(option, denominator, state.denominatorSelected),
            text: `${option}`,
            attrs: { type: "button", disabled: hasAnswered ? "disabled" : null },
            on: { click: () => onChooseDenominator(option) },
          }),
        ),
      }),
      hasAnswered
        ? el("div", {
            className: `fraction-extra-feedback ${isCorrect ? "is-correct" : "is-wrong"}`,
            children: [
              el("strong", { text: isCorrect ? "找到分母" : "再看下面的數字" }),
              el("button", {
                className: "button button--primary",
                text: "下一題",
                attrs: { type: "button" },
                on: { click: onNextDenominator },
              }),
            ],
          })
        : null,
    ],
  });
}

function renderPizzaCutLab({ state, onSetCutDenominator }) {
  return el("article", {
    className: "fraction-extra-card fraction-cut-lab",
    children: [
      el("div", {
        className: "fraction-extra-card__head",
        children: [
          el("span", { text: "遊戲二" }),
          el("strong", { text: "披薩切切" }),
          el("em", { text: `${state.cutDenominator} 等分` }),
        ],
      }),
      el("div", {
        className: "fraction-cut-pizza",
        children: [renderFractionPizza(state.cutDenominator, state.cutDenominator, true)],
      }),
      el("div", {
        className: "fraction-cut-controls",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "-1 等分",
            attrs: { type: "button" },
            on: { click: () => onSetCutDenominator(Math.max(2, state.cutDenominator - 1)) },
          }),
          el("div", {
            className: "fraction-cut-number",
            children: [
              el("span", { text: "分母" }),
              el("strong", { text: `${state.cutDenominator}` }),
            ],
          }),
          el("button", {
            className: "button button--secondary",
            text: "+1 等分",
            attrs: { type: "button" },
            on: { click: () => onSetCutDenominator(Math.min(12, state.cutDenominator + 1)) },
          }),
        ],
      }),
      el("p", { text: `分母 ${state.cutDenominator} 表示一個披薩被切成 ${state.cutDenominator} 份。` }),
    ],
  });
}

function renderDenominatorMatch({ state, onFlipMatchCard, onResetMatch }) {
  return el("article", {
    className: "fraction-extra-card fraction-match-game",
    children: [
      el("div", {
        className: "fraction-extra-card__head",
        children: [
          el("span", { text: "遊戲三" }),
          el("strong", { text: "分母翻牌" }),
          el("em", { text: `${state.matchSolved.length / 2} 組` }),
        ],
      }),
      el("div", {
        className: "fraction-match-board",
        children: state.matchCards.map((card, index) => {
          const isOpen = state.matchSelected.includes(index) || state.matchSolved.includes(index);
          return el("button", {
            className: `fraction-match-card${isOpen ? " is-open" : ""}${state.matchSolved.includes(index) ? " is-solved" : ""}`,
            attrs: { type: "button", disabled: state.matchSolved.includes(index) ? "disabled" : null },
            on: { click: () => onFlipMatchCard(index) },
            children: isOpen
              ? [
                  el("strong", { text: `${card.numerator}` }),
                  el("span"),
                  el("strong", { text: `${card.denominator}` }),
                ]
              : [el("i", { text: "?" })],
          });
        }),
      }),
      el("div", {
        className: "fraction-match-status",
        children: [
          el("strong", { text: state.matchMessage }),
          el("span", { text: `翻牌 ${state.matchMoves} 次` }),
          el("button", {
            className: "button button--secondary",
            text: "重新洗牌",
            attrs: { type: "button" },
            on: { click: onResetMatch },
          }),
        ],
      }),
    ],
  });
}

function buildMatchCards() {
  return shuffleCards(matchCardSpecs.map(([numerator, denominator], index) => ({
    id: `match-${index}`,
    numerator,
    denominator,
  })));
}

export function resolveMatchFlip(state, index) {
  if (state.matchSolved.includes(index)) return state;

  const selected = state.matchSelected.length === 2 ? [] : [...state.matchSelected];
  if (selected.includes(index)) return { ...state, matchSelected: selected };

  selected.push(index);
  if (selected.length < 2) {
    return {
      ...state,
      matchSelected: selected,
      matchMessage: "再翻一張，看看分母是不是一樣。",
    };
  }

  const [firstIndex, secondIndex] = selected;
  const first = state.matchCards[firstIndex];
  const second = state.matchCards[secondIndex];
  const isMatch = first.denominator === second.denominator;

  return {
    ...state,
    matchSelected: selected,
    matchSolved: isMatch ? [...state.matchSolved, firstIndex, secondIndex] : state.matchSolved,
    matchMessage: isMatch ? `配對成功，分母都是 ${first.denominator}。` : "分母不一樣，下一次再試。",
    matchMoves: state.matchMoves + 1,
  };
}

export function resetMatchGame(state) {
  return {
    ...state,
    matchCards: buildMatchCards(),
    matchSelected: [],
    matchSolved: [],
    matchMessage: "翻兩張分數卡，找分母一樣的朋友。",
    matchMoves: 0,
  };
}

function buildDenominatorOptions(answer, index) {
  const options = [answer, answer - 2, answer - 1, answer + 1, answer + 2]
    .filter((value) => value >= 2 && value <= 12);
  let candidate = 2;
  while (options.length < 4 && candidate <= 12) {
    if (!options.includes(candidate)) options.push(candidate);
    candidate += 1;
  }
  return [...new Set(options)].slice(0, 4).sort((a, b) => ((a + index) % 4) - ((b + index) % 4));
}

function getDenominatorOptionClass(option, answer, selected) {
  const classes = ["fraction-denominator-option"];
  if (selected === null) return classes.join(" ");
  if (option === answer) classes.push("is-correct");
  if (selected === option && option !== answer) classes.push("is-wrong");
  return classes.join(" ");
}

function shuffleCards(cards) {
  return [...cards].sort(() => Math.random() - 0.5);
}

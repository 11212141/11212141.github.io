import { el, sectionTitle } from "../utils/dom.js";

export function renderWorkPage({
  state,
  onSelectStudent,
  onToggleTask,
  onUpdateNote,
  onSetFocus,
  onResetWork,
}) {
  const activeStudent = state.students[state.activeStudentIndex];
  const doneCount = state.tasks.filter((task) => task.done).length;

  return el("section", {
    className: "panel work-panel",
    attrs: { id: "work-page" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("工作頁面", "", el("span", { className: "badge badge--warm", text: "活動頁" })),
          el("div", {
            className: "work-layout",
            children: [
              el("aside", {
                className: "work-student-card",
                children: [
                  el("strong", { text: "學生" }),
                  el("div", {
                    className: "work-student-list",
                    children: state.students.map((student, index) =>
                      el("button", {
                        className: `work-student-button${index === state.activeStudentIndex ? " is-active" : ""}`,
                        attrs: { type: "button" },
                        on: { click: () => onSelectStudent(index) },
                        children: [
                          el("span", { text: student.name }),
                          el("small", { text: student.account }),
                        ],
                      }),
                    ),
                  }),
                  el("button", {
                    className: "button button--secondary",
                    text: "重置工作板",
                    attrs: { type: "button" },
                    on: { click: onResetWork },
                  }),
                ],
              }),
              el("div", {
                className: "work-main",
                children: [
                  el("div", {
                    className: "work-focus-card",
                    children: [
                      el("span", { className: "badge badge--live", text: activeStudent.name }),
                      el("h3", { text: state.focus || "今天要完成什麼？" }),
                      el("div", {
                        className: "work-focus-actions",
                        children: ["課前準備", "課中練習", "課後整理"].map((focus) =>
                          el("button", {
                            className: `button ${state.focus === focus ? "button--primary" : "button--secondary"}`,
                            text: focus,
                            attrs: { type: "button" },
                            on: { click: () => onSetFocus(focus) },
                          }),
                        ),
                      }),
                    ],
                  }),
                  el("div", {
                    className: "work-progress-card",
                    children: [
                      el("strong", { text: `${doneCount} / ${state.tasks.length}` }),
                      el("span", { text: "已完成" }),
                    ],
                  }),
                  el("div", {
                    className: "work-task-list",
                    children: state.tasks.map((task) =>
                      el("button", {
                        className: `work-task${task.done ? " is-done" : ""}`,
                        attrs: { type: "button" },
                        on: { click: () => onToggleTask(task.id) },
                        children: [
                          el("span", { className: "work-check", text: task.done ? "✓" : "" }),
                          el("strong", { text: task.title }),
                          el("small", { text: task.note }),
                        ],
                      }),
                    ),
                  }),
                  el("label", {
                    className: "work-note-card",
                    children: [
                      el("span", { text: "課堂紀錄" }),
                      el("textarea", {
                        attrs: {
                          rows: "5",
                          placeholder: "可以記錄今天學生完成了什麼、哪裡需要再練習。",
                        },
                        text: state.note,
                        on: { input: (event) => onUpdateNote(event.target.value) },
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

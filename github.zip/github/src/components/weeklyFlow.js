import { el, sectionTitle } from "../utils/dom.js";

export function renderWeeklyFlow({
  agenda,
  title = "活動流程",
  description = "把第一次見面的節奏排清楚，帶課時就不容易慌，也能更安心地照顧每位孩子。",
}) {
  const section = el("section", { className: "panel", attrs: { id: "rhythm" } });

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(title, description, el("span", { className: "badge badge--warm", text: "30 分鐘版本" })),
      el("div", {
        className: "agenda-list",
        children: agenda.map((block) => renderAgendaBlock(block)),
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderAgendaBlock(block) {
  return el("article", {
    className: "agenda-card",
    children: [
      el("div", {
        className: "agenda-meta",
        children: [
          el("div", {
            children: [
              el("strong", { text: `${block.day}｜${block.focus}` }),
              el("p", { text: block.time }),
            ],
          }),
          el("span", { className: "pill", text: `${block.tasks.length} 個任務` }),
        ],
      }),
      el("div", {
        className: "task-list",
        children: block.tasks.map((task) => renderTask(task)),
      }),
    ],
  });
}

function renderTask(task) {
  return el("div", {
    className: "task-item",
    children: [
      el("span", { className: "task-marker" }),
      el("span", {
        html: `<strong>${task.title}</strong><p>${task.note}</p>`,
      }),
    ],
  });
}

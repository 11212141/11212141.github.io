import { el, sectionTitle } from "../utils/dom.js";

export function renderMbtiGuide({
  guide,
  dimensions,
  roles,
  letterGuide,
  profiles,
  activeTypeId,
  onSelectType,
}) {
  const section = el("section", { className: "panel", attrs: { id: "mbti-guide" } });
  const activeProfile = profiles.find((profile) => profile.id === activeTypeId) ?? profiles[0];

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(
        guide.title,
        guide.summary,
        el("span", { className: "badge badge--warm", text: guide.badge }),
      ),
      el("div", {
        className: "mbti-intro",
        children: [renderDimensionCard(dimensions), renderRoleCard(roles)],
      }),
      el("div", {
        className: "mbti-layout",
        children: [
          renderTypePanel({
            profiles,
            activeProfile,
            onSelectType,
          }),
          renderProfileCard(activeProfile, roles, letterGuide),
        ],
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderDimensionCard(dimensions) {
  return el("article", {
    className: "mbti-intro-card",
    children: [
      el("span", { className: "badge badge--live", text: "字母" }),
      el("h3", { text: "四個字母怎麼看" }),
      el("div", {
        className: "mbti-pair-grid",
        children: dimensions.map((item) =>
          el("div", {
            className: "mbti-pair-card",
            children: [
              el("strong", { text: item.title }),
              el("span", { className: "pill", text: item.label }),
              el("p", { text: item.summary }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderRoleCard(roles) {
  return el("article", {
    className: "mbti-intro-card",
    children: [
      el("span", { className: "badge badge--warm", text: "分群" }),
      el("h3", { text: "16 型也分 4 組" }),
      el("div", {
        className: "mbti-role-grid",
        children: roles.map((role) =>
          el("div", {
            className: "mbti-role-card",
            children: [
              el("div", {
                className: "mbti-role-card__top",
                children: [
                  el("strong", { text: role.label }),
                  el("span", { className: "pill", text: role.pair }),
                ],
              }),
              el("p", { text: role.summary }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderTypePanel({ profiles, activeProfile, onSelectType }) {
  return el("article", {
    className: "mbti-type-panel",
    children: [
      el("div", {
        className: "mbti-type-panel__header",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: "16 型" }),
              el("h3", { text: "點一個代碼看分析" }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "mbti-type-grid",
        children: profiles.map((profile) =>
          el("button", {
            className: `mbti-type-button${profile.id === activeProfile.id ? " is-active" : ""}`,
            attrs: { type: "button" },
            on: {
              click: () => onSelectType(profile.id),
            },
            children: [
              el("strong", { text: profile.id }),
              el("span", { text: profile.officialName }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderProfileCard(profile, roles, letterGuide) {
  const role = roles.find((item) => item.id === profile.groupId) ?? null;

  return el("article", {
    className: "mbti-profile-card",
    children: [
      el("div", {
        className: "mbti-profile-card__header",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: profile.group }),
              el("h3", { text: `${profile.id}｜${profile.officialName}` }),
              el("p", { text: profile.nickname }),
            ],
          }),
        ],
      }),
      el("p", { text: profile.summary }),
      el("div", {
        className: "mbti-strength-list",
        children: profile.strengths.map((strength) =>
          el("span", {
            className: "mbti-strength",
            text: strength,
          }),
        ),
      }),
      el("div", {
        className: "mbti-letter-grid",
        children: profile.id
          .split("")
          .map((letter) => renderLetterCard(letter, letterGuide[letter])),
      }),
      el("div", {
        className: "mbti-detail-grid",
        children: [
          role ? detailCard(`${role.label} 的特點`, role.summary) : null,
          detailCard("在課堂裡", profile.classroom),
          detailCard("玩網站內容時", profile.games),
          detailCard("和同學一起", profile.friendship),
          detailCard("給你的話", profile.encouragement, true),
        ],
      }),
    ],
  });
}

function renderLetterCard(letter, item) {
  return el("div", {
    className: "mbti-letter-card",
    children: [
      el("div", {
        className: "mbti-letter-card__top",
        children: [
          el("span", { className: "mbti-letter-card__code", text: letter }),
          el("strong", { text: item ? `${item.title}` : letter }),
        ],
      }),
      el("p", { text: item?.summary ?? "" }),
      item?.hint ? el("span", { text: item.hint }) : null,
    ],
  });
}

function detailCard(title, text, accent = false) {
  return el("div", {
    className: `mbti-detail-card${accent ? " mbti-detail-card--accent" : ""}`,
    children: [el("strong", { text: title }), el("p", { text })],
  });
}

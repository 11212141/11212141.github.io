import { el, sectionTitle } from "../utils/dom.js";

export function renderSportsEnglishGame({
  challenge,
  decks,
  state,
  onSelectDeck,
  onStartGame,
  onSelectPlayer,
  onFlipCard,
  onCoverCards,
  onResetGame,
}) {
  return el("section", {
    className: "panel sports-game sports-memory-game",
    attrs: { id: "sports-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle(challenge.title, "", el("span", { className: "badge badge--live", text: "配對翻卡" })),
          renderDeckSelector({ decks, state, onSelectDeck }),
          renderMemoryIntro(decks, state),
          !state.started
            ? renderStartCard(onStartGame)
            : state.finished
              ? renderFinished(state, onResetGame)
              : renderMemoryGame({ state, onSelectPlayer, onFlipCard, onCoverCards, onResetGame }),
        ],
      }),
    ],
  });
}

function renderDeckSelector({ decks, state, onSelectDeck }) {
  return el("div", {
    className: "sports-deck-selector",
    children: decks.map((deck) =>
      el("button", {
        className: `sports-deck-button${state.deckId === deck.id ? " is-active" : ""}`,
        attrs: { type: "button", disabled: state.isShuffling ? "disabled" : null },
        on: { click: () => onSelectDeck(deck.id) },
        children: [
          el("strong", { text: deck.label }),
          el("span", { text: `${deck.items.length} 組` }),
        ],
      }),
    ),
  });
}

function renderMemoryIntro(decks, state) {
  const deck = decks.find((item) => item.id === state.deckId) ?? decks[0];

  return el("div", {
    className: "sports-memory-intro",
    children: [
      el("div", {
        children: [
          el("strong", { text: deck.label }),
          el("span", { text: "翻英文卡和中文卡，找出同一張圖卡。" }),
        ],
      }),
      el("div", {
        className: "sports-memory-stat sports-memory-stat--matched",
        children: [
          el("strong", { text: `${state.matchedSportIds.length} / ${deck.items.length}` }),
          el("span", { text: "已完成配對" }),
        ],
      }),
      el("div", {
        className: "sports-memory-stat sports-memory-stat--attempts",
        children: [
          el("strong", { text: `${state.attempts}` }),
          el("span", { text: "翻牌次數" }),
        ],
      }),
    ],
  });
}

function renderStartCard(onStartGame) {
  return el("article", {
    className: "sports-memory-card sports-memory-start",
    children: [
      el("span", { className: "badge badge--warm", text: "準備開始" }),
      el("h3", { text: "圖卡配對" }),
      el("p", { text: "先選一種圖卡，按下開始後會洗牌。卡背有 A1、B1、C1、D1 位置，可以直接指定學生翻哪一張。" }),
      el("button", {
        className: "button button--primary",
        text: "開始洗牌",
        attrs: { type: "button" },
        on: { click: onStartGame },
      }),
    ],
  });
}

function renderMemoryGame({ state, onSelectPlayer, onFlipCard, onCoverCards, onResetGame }) {
  const activePlayer = state.players[state.activePlayerIndex];

  return el("article", {
    className: `sports-memory-card${state.isShuffling ? " is-shuffling" : ""}`,
    children: [
      el("div", {
        className: "sports-memory-head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: state.isShuffling ? "洗牌中" : `輪到 ${activePlayer.name}` }),
              el("h3", { text: state.isShuffling ? "卡片正在洗牌" : "圖卡配對" }),
            ],
          }),
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button", disabled: state.isShuffling ? "disabled" : null },
            on: { click: onResetGame },
          }),
        ],
      }),
      renderPlayerRow(state, onSelectPlayer),
      el("div", {
        className: `sports-memory-board${state.isShuffling ? " is-shuffling" : ""}`,
        children: state.cards.map((card, index) => renderMemoryCard({ card, index, state, onFlipCard })),
      }),
      el("div", {
        className: "sports-feedback-slot",
        children: [renderFeedback(state, onCoverCards)],
      }),
    ],
  });
}

function renderPlayerRow(state, onSelectPlayer) {
  return el("div", {
    className: "sports-player-row",
    children: state.players.map((player, index) =>
      el("button", {
        className: `sports-player-chip${index === state.activePlayerIndex ? " is-active" : ""}`,
        attrs: {
          type: "button",
          disabled: state.isShuffling || state.flippedCardIds.length || state.pendingMismatch ? "disabled" : null,
          "data-player-index": index,
        },
        on: { click: () => onSelectPlayer(index) },
        children: [
          el("strong", { text: player.name }),
          el("span", { text: `${player.score} 分` }),
        ],
      }),
    ),
  });
}

function renderMemoryCard({ card, index, state, onFlipCard }) {
  const isMatched = state.matchedSportIds.includes(card.sportId);
  const isFlipped = isMatched || state.flippedCardIds.includes(card.id);
  const isLocked = state.isShuffling || isMatched || state.pendingMismatch || state.flippedCardIds.length >= 2;

  return el("button", {
    className: `sports-memory-tile${isFlipped ? " is-flipped" : ""}${isMatched ? " is-matched" : ""}${state.isShuffling ? " is-shuffling" : ""}`,
    attrs: {
      type: "button",
      disabled: isLocked ? "disabled" : null,
      style: `--sport-color:${card.color}; --shuffle-index:${index};`,
      "data-card-id": card.id,
      "data-sport-id": card.sportId,
    },
    on: { click: () => onFlipCard(card.id) },
    children: [
      el("span", {
        className: "sports-memory-tile__back",
        children: [
          el("strong", { text: card.positionLabel }),
          el("small", { text: "圖卡" }),
        ],
      }),
      el("span", {
        className: "sports-memory-tile__front",
        children: [
          renderCardVisual(card),
          el("strong", { text: card.text }),
          el("small", { text: card.kind === "english" ? "English" : "中文" }),
        ],
      }),
    ],
  });
}

function renderFeedback(state, onCoverCards) {
  if (state.isShuffling) {
    return el("p", { className: "sports-feedback", text: "洗牌中，等等就可以開始翻卡。" });
  }

  if (!state.lastResult) {
    return el("p", { className: "sports-feedback", text: "先翻兩張卡，找出英文和中文是不是同一張圖卡。" });
  }

  if (state.lastResult.isMatch) {
    return el("div", {
      className: "sports-feedback is-correct",
      children: [
        el("strong", { text: "配對成功" }),
        el("span", { text: `${state.lastResult.english} = ${state.lastResult.chinese}` }),
      ],
    });
  }

  return el("div", {
    className: "sports-feedback is-wrong",
    children: [
      el("strong", { text: "沒有配對" }),
      el("span", { text: "看清楚兩張卡，再把它們蓋回去。" }),
      el("button", {
        className: "button button--secondary",
        text: "蓋回卡片",
        attrs: { type: "button" },
        on: { click: onCoverCards },
      }),
    ],
  });
}

function renderCardVisual(card) {
  if (card.visual) {
    return el("span", { className: "sports-memory-visual", text: card.visual });
  }

  return el("span", {
    className: "sports-memory-swatch",
    attrs: { style: `--sport-color:${card.color};` },
  });
}

function renderFinished(state, onResetGame) {
  const winner = [...state.players].sort((left, right) => right.score - left.score)[0];

  return el("article", {
    className: "sports-memory-card sports-memory-card--finished",
    children: [
      el("span", { className: "badge badge--live", text: "完成" }),
      el("h3", { text: "全部配對完成" }),
      el("p", { text: `今日 MVP：${winner.name}` }),
      renderScoreBoard(state),
      el("button", {
        className: "button button--primary",
        text: "再玩一次",
        attrs: { type: "button" },
        on: { click: onResetGame },
      }),
    ],
  });
}

function renderScoreBoard(state) {
  return el("div", {
    className: "sports-player-row",
    children: state.players.map((player) =>
      el("div", {
        className: "sports-player-chip",
        children: [el("strong", { text: player.name }), el("span", { text: `${player.score} 分` })],
      }),
    ),
  });
}

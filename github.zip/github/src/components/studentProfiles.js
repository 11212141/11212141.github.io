import { el, sectionTitle } from "../utils/dom.js";
import { renderStudentLessonHistory } from "./studentLessonHistory.js";

export function renderStudentProfiles({ students }) {
  const section = el("section", { className: "panel", attrs: { id: "students" } });

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(
        "學生資料",
        "",
        el("span", { className: "badge badge--warm", text: `${students.length} 位學生` }),
      ),
      el("div", {
        className: "student-grid",
        children: students.map((student) => renderStudentCard(student)),
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderStudentCard(student) {
  return el("article", {
    className: "student-card",
    children: [
      el("div", {
        className: "student-card__header",
        children: [
          el("div", {
            children: [
              el("h3", { text: student.name }),
              el("p", { text: `${student.grade} • ${student.gender} • ${student.background}` }),
            ],
          }),
          el("span", { className: "badge badge--warm", text: student.account }),
        ],
      }),
      el("div", {
        className: "data-grid",
        children: [
          dataPair("教學端", student.teachingSide),
          dataPair("學習端", student.learningSide),
          dataPair("家庭背景", student.background),
          dataPair("家中設備", student.homeEquipment),
          dataPair("學科領域", student.subject),
          dataPair("學科版本", student.subjectVersion),
          dataPair("學習平台", student.platformUsage),
        ],
      }),
      el("section", {
        className: "student-analysis",
        children: [
          el("strong", { text: "需求調查" }),
          el("p", { text: student.needsAnalysis }),
        ],
      }),
      student.mbti ? renderStudentMbti(student.mbti) : null,
      renderStudentLessonHistory(student),
    ],
  });
}

function renderStudentMbti(mbti) {
  return el("section", {
    className: "student-mbti-card",
    children: [
      el("div", {
        className: "student-mbti-card__header",
        children: [
          el("span", { className: "student-mbti-card__type", text: mbti.type }),
          el("div", {
            children: [
              el("strong", { text: mbti.name }),
              el("p", { text: mbti.summary }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "student-mbti-strengths",
        children: mbti.strengths.map((strength) => el("span", { text: strength })),
      }),
      el("p", { text: mbti.analysis }),
      el("p", { className: "student-mbti-card__encouragement", text: mbti.encouragement }),
    ],
  });
}

function dataPair(label, value) {
  return el("div", {
    className: "data-pair",
    children: [el("span", { text: label }), el("strong", { text: value })],
  });
}

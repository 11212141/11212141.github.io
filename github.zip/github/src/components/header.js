import { el } from "../utils/dom.js";

export function renderHeader(
  profile,
  {
    pages = [],
    currentPageId = "home",
    actionText = "",
    actionHref = "",
  } = {},
) {
  const isCollapsed = localStorage.getItem("aidigital-sidebar-collapsed") === "true";
  document.body.classList.toggle("sidebar-collapsed", isCollapsed);

  const brand = el("a", {
    className: "brand",
    attrs: { href: "./index.html" },
    children: [
      el("div", { className: "brand__mark", text: "AD" }),
      el("div", {
        className: "brand__label",
        html: `<strong>${profile.title}</strong><span>${profile.mentorName}</span>`,
      }),
    ],
  });

  const toggle = el("button", {
    className: "sidebar-toggle",
    attrs: {
      type: "button",
      "aria-label": isCollapsed ? "展開選單" : "收合選單",
      title: isCollapsed ? "展開選單" : "收合選單",
    },
    text: isCollapsed ? "›" : "‹",
    on: {
      click: () => {
        const nextCollapsed = !document.body.classList.contains("sidebar-collapsed");
        document.body.classList.toggle("sidebar-collapsed", nextCollapsed);
        localStorage.setItem("aidigital-sidebar-collapsed", String(nextCollapsed));
        toggle.textContent = nextCollapsed ? "›" : "‹";
        toggle.setAttribute("aria-label", nextCollapsed ? "展開選單" : "收合選單");
        toggle.setAttribute("title", nextCollapsed ? "展開選單" : "收合選單");
      },
    },
  });

  const homePages = sortPages(pages.filter((page) => page.category === "home" || page.id === "home"), ["home"]);
  const englishPages = sortPages(pages.filter((page) => page.category === "english"), [
    "color-mix",
    "this-that-game",
    "can-do-game",
    "sports-game",
    "phonics-game",
    "word-guess-game",
  ]);
  const mathPages = sortPages(pages.filter((page) => page.category === "math"), [
    "money-game",
    "division-game",
    "decimal-intro",
    "decimal-game",
    "time-game",
    "area-grid-game",
    "fraction-game",
    "sudoku-game",
  ]);
  const activityPages = sortPages(pages.filter((page) => page.category === "activity"), [
    "date-finance-game",
    "random-picker",
    "gratitude-cards",
  ]);
  const studentPages = sortPages(pages.filter((page) => page.category === "student"), ["students"]);

  const nav = el("nav", {
    className: "nav sidebar-nav",
    children: [
      ...homePages.map((page) => navLink(page, currentPageId)),
      renderNavGroup("英文教學", englishPages, currentPageId),
      renderNavGroup("數學教學", mathPages, currentPageId),
      renderNavGroup("活動遊戲", activityPages, currentPageId),
      renderNavGroup("工作頁面", studentPages, currentPageId),
    ],
  });

  const wrapper = el("aside", {
    className: "site-header",
    children: [
      el("div", {
        className: "site-header__inner",
        children: [
          el("div", {
            className: "sidebar-brand-row",
            children: [brand, toggle],
          }),
          nav,
          actionText && actionHref
            ? el("a", {
                className: "button button--primary sidebar-action",
                text: actionText,
                attrs: { href: actionHref },
              })
            : null,
        ],
      }),
    ],
  });

  return wrapper;
}

function sortPages(pages, order) {
  return [...pages].sort((a, b) => {
    const aIndex = order.indexOf(a.id);
    const bIndex = order.indexOf(b.id);
    if (aIndex === -1 && bIndex === -1) return 0;
    if (aIndex === -1) return 1;
    if (bIndex === -1) return -1;
    return aIndex - bIndex;
  });
}

function renderNavGroup(title, pages, currentPageId) {
  if (!pages.length) {
    return null;
  }

  return el("div", {
    className: "nav-group",
    children: [
      el("span", { className: "nav-group__title", text: title }),
      ...pages.map((page) => navLink(page, currentPageId)),
    ],
  });
}

function navLink(page, currentPageId) {
  return el("a", {
    className: page.id === currentPageId ? "is-active" : "",
    attrs: { href: page.href, title: page.label },
    children: [
      el("span", { className: "nav-icon", text: getNavIcon(page) }),
      el("span", { className: "nav-text", text: page.label }),
    ],
  });
}

function getNavIcon(page) {
  if (page.id === "home") return "";
  if (page.badge?.includes("數學")) return "";
  if (page.badge?.includes("英文")) return "";
  if (page.id === "students") return "";
  return "";
}

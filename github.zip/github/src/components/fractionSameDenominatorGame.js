import { el, sectionTitle } from "../utils/dom.js";

export function createFractionQuestions() {
  const specs = [
    [4, 1, 2, "+"], [5, 2, 1, "+"], [6, 1, 3, "+"], [8, 3, 2, "+"], [10, 4, 3, "+"],
    [7, 5, 2, "-"], [9, 6, 1, "-"], [8, 7, 3, "-"], [6, 5, 2, "-"], [10, 8, 5, "-"],
    [12, 3, 4, "+"], [9, 2, 5, "+"], [11, 4, 2, "+"], [12, 5, 3, "+"], [10, 1, 6, "+"],
    [12, 9, 4, "-"], [11, 8, 3, "-"], [10, 9, 2, "-"], [9, 7, 4, "-"], [8, 6, 5, "-"],
    [6, 2, 2, "+"], [7, 1, 4, "+"], [8, 2, 5, "+"], [9, 3, 3, "+"], [12, 6, 5, "+"],
    [12, 11, 6, "-"], [10, 7, 1, "-"], [9, 8, 2, "-"], [7, 6, 3, "-"], [6, 4, 1, "-"],
  ];

  return specs.map(([denominator, first, second, operator], index) => {
    return buildFractionQuestion({
      id: `fraction-${index + 1}`,
      title: `第 ${index + 1} 題`,
      denominator,
      first,
      second,
      operator,
      optionSeed: index,
    });
  });
}

export function createFractionState() {
  return {
    roundIndex: 0,
    selected: null,
    isAnswered: false,
    score: 0,
    streak: 0,
    missionIndex: 0,
    visual: "both",
    activeQuestion: null,
    answerNumerator: 0,
    custom: {
      denominator: 8,
      first: 3,
      second: 2,
      operator: "+",
    },
  };
}

export const fractionMissionCards = [
  {
    title: "披薩主廚",
    text: "先調出披薩片數，再說出答案是幾分之幾。",
    goal: "用披薩回答",
  },
  {
    title: "分母守門員",
    text: "觀察上下兩個分數的分母，答題時說出分母有沒有改變。",
    goal: "守住分母",
  },
  {
    title: "超過一盒",
    text: "如果披薩超過 1 個，找出有幾個完整披薩，還剩幾片。",
    goal: "找完整披薩",
  },
  {
    title: "加減偵探",
    text: "先判斷今天是加法還是減法，再決定披薩要增加或減少。",
    goal: "先看符號",
  },
];

export function buildFractionQuestion({
  id = "fraction-custom",
  title = "自訂題",
  denominator,
  first,
  second,
  operator,
  optionSeed = 0,
}) {
  const safeDenominator = clampInteger(denominator, 2, 12);
  const safeOperator = operator === "-" ? "-" : "+";
  const safeFirst = clampInteger(first, 0, safeDenominator);
  const safeSecondLimit = safeOperator === "+" ? safeDenominator : safeFirst;
  const safeSecond = clampInteger(second, 0, safeSecondLimit);
  const answer = safeOperator === "+" ? safeFirst + safeSecond : safeFirst - safeSecond;

  return {
    id,
    title,
    denominator: safeDenominator,
    first: safeFirst,
    second: safeSecond,
    operator: safeOperator,
    answer,
    options: buildFractionOptions(answer, safeDenominator, optionSeed),
  };
}

export function createRandomFractionQuestion(seed = Date.now()) {
  const denominator = randomInteger(3, 12);
  const operator = Math.random() > 0.45 ? "+" : "-";
  const first = randomInteger(operator === "+" ? 0 : 1, denominator);
  const secondMax = operator === "+" ? denominator : first;
  const second = randomInteger(secondMax === 0 ? 0 : 1, Math.max(0, secondMax));

  return buildFractionQuestion({
    id: `fraction-random-${seed}`,
    title: "隨機題",
    denominator,
    first,
    second,
    operator,
    optionSeed: seed,
  });
}

export function renderFractionSameDenominatorGame({
  questions,
  state,
  onNext,
  onReset,
  onSetVisual,
  onSetCustomField,
  onApplyCustom,
  onRandomQuestion,
  onAdjustAnswer,
  onSubmitPizzaAnswer,
}) {
  const question = state.activeQuestion ?? questions[state.roundIndex];
  const selectedAnswer = state.selected ?? state.answerNumerator;
  const isCorrect = state.isAnswered && selectedAnswer === question.answer;
  const badgeText = state.activeQuestion ? question.title : `${state.roundIndex + 1}/${questions.length}`;
  const mission = fractionMissionCards[state.missionIndex % fractionMissionCards.length];

  return el("section", {
    className: "panel fraction-game",
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("同分母分數", "", el("span", { className: "badge badge--live", text: badgeText })),
          el("div", {
            className: "fraction-layout",
            children: [
              el("article", {
                className: "fraction-stage",
                children: [
                  renderFractionMissionStrip({ question, state, mission }),
                  el("div", {
                    className: "fraction-expression",
                    attrs: { "data-fraction-expression": "true" },
                    children: [
                      renderFractionNumber(question.first, question.denominator),
                      el("span", { className: "fraction-operator", text: question.operator }),
                      renderFractionNumber(question.second, question.denominator),
                      el("span", { className: "fraction-operator", text: "=" }),
                      state.isAnswered
                        ? renderFractionNumber(question.answer, question.denominator, "is-answer")
                        : el("div", { className: "fraction-mystery", text: "?" }),
                    ],
                  }),
                  renderFractionBuilder({
                    state,
                    onSetCustomField,
                    onApplyCustom,
                    onRandomQuestion,
                  }),
                  renderPizzaAnswerControl({
                    question,
                    state,
                    onAdjustAnswer,
                    onSubmitPizzaAnswer,
                  }),
                  el("div", {
                    className: "fraction-visual-toggle",
                    children: [
                      ["both", "圓餅＋長條"], ["pie", "圓餅"], ["bar", "長條"],
                    ].map(([id, label]) =>
                      el("button", {
                        className: state.visual === id ? "is-active" : "",
                        text: label,
                        attrs: { type: "button", "data-visual": id },
                        on: { click: () => onSetVisual(id) },
                      }),
                    ),
                  }),
                  renderFractionVisuals(question, state),
                ],
              }),
              el("aside", {
                className: "fraction-control",
                children: [
                  el("div", {
                    className: "fraction-score",
                    children: [
                      el("span", { text: "得分" }),
                      el("strong", { text: `${state.score}` }),
                      el("em", { text: `連續答對 ${state.streak} 題` }),
                    ],
                  }),
                  state.isAnswered
                    ? el("div", {
                        className: `fraction-feedback ${isCorrect ? "is-correct" : "is-wrong"}`,
                        children: [
                          el("strong", { text: isCorrect ? "披薩完成" : "再調一次披薩" }),
                          el("p", { text: buildExplanation(question) }),
                          el("small", { text: isCorrect ? mission.goal : "可以先看分子，再看披薩片數。" }),
                        ],
                      })
                    : null,
                  el("div", {
                    className: "button-row",
                    children: [
                      el("button", {
                        className: "button button--primary",
                        text: state.roundIndex === questions.length - 1 ? "完成" : "下一題",
                        attrs: { type: "button", disabled: state.isAnswered ? null : "disabled" },
                        on: { click: onNext },
                      }),
                      el("button", {
                        className: "button button--secondary",
                        text: "重新開始",
                        attrs: { type: "button" },
                        on: { click: onReset },
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderFractionMissionStrip({ question, state, mission }) {
  return el("div", {
    className: "fraction-mission-strip",
    children: [
      el("div", {
        className: "fraction-mission-card",
        children: [
          el("span", { text: "今日任務" }),
          el("strong", { text: mission.title }),
          el("p", { text: mission.text }),
        ],
      }),
      el("div", {
        className: "fraction-mini-card",
        children: [
          el("span", { text: "分母" }),
          el("strong", { text: `${question.denominator}` }),
          el("p", { text: "每個披薩都切成一樣多片" }),
        ],
      }),
      el("div", {
        className: "fraction-mini-card",
        children: [
          el("span", { text: "關卡" }),
          el("strong", { text: state.activeQuestion ? "自訂" : `${state.roundIndex + 1}` }),
          el("p", { text: state.streak >= 2 ? "連續答對中" : "調好披薩再送出" }),
        ],
      }),
    ],
  });
}

function renderFractionNumber(numerator, denominator, extraClass = "") {
  return el("div", {
    className: `fraction-number ${extraClass}`.trim(),
    children: [
      el("strong", { text: `${numerator}` }),
      el("span"),
      el("strong", { text: `${denominator}` }),
    ],
  });
}

export function renderFractionAnswerNumber(numerator, denominator) {
  return renderFractionNumber(numerator, denominator);
}

export function renderFractionAnswerSummary(numerator, denominator) {
  const whole = Math.floor(numerator / denominator);
  const rest = numerator % denominator;
  const summary = whole > 0
    ? `${whole} 個完整披薩，還有 ${rest} 片`
    : `目前有 ${rest} 片，還沒滿 1 個披薩`;

  return el("div", {
    className: "fraction-answer-summary",
    children: [
      el("span", { text: "披薩份量" }),
      el("strong", { text: summary }),
    ],
  });
}

function renderFractionBuilder({ state, onSetCustomField, onApplyCustom, onRandomQuestion }) {
  const custom = state.custom;

  return el("div", {
    className: "fraction-builder",
    children: [
      el("div", {
        className: "fraction-builder__head",
        children: [
          el("strong", { text: "老師出題" }),
          el("button", {
            className: "button button--secondary",
            text: "隨機出題",
            attrs: { type: "button" },
            on: { click: onRandomQuestion },
          }),
        ],
      }),
      el("div", {
        className: "fraction-builder__grid",
        children: [
          renderNumberField("分母", "denominator", custom.denominator, onSetCustomField, 2, 12),
          renderNumberField("第一分子", "first", custom.first, onSetCustomField, 0, 12),
          renderOperatorField(custom.operator, onSetCustomField),
          renderNumberField("第二分子", "second", custom.second, onSetCustomField, 0, 12),
        ],
      }),
      el("button", {
        className: "button button--primary button--full",
        text: "套用自訂題",
        attrs: { type: "button" },
        on: { click: onApplyCustom },
      }),
    ],
  });
}

function renderPizzaAnswerControl({ question, state, onAdjustAnswer, onSubmitPizzaAnswer }) {
  return el("div", {
    className: "fraction-answer-builder",
    children: [
      el("div", {
        className: "fraction-answer-builder__head",
        children: [
          el("strong", { text: "調整答案披薩" }),
          el("div", {
            attrs: { "data-fraction-answer-number": "true" },
            children: [renderFractionNumber(state.answerNumerator, question.denominator)],
          }),
        ],
      }),
      el("div", {
        className: "fraction-answer-pizza",
        attrs: { "data-fraction-answer-pizza": "true" },
        children: [renderPie(state.answerNumerator, question.denominator, true)],
      }),
      el("div", {
        attrs: { "data-fraction-answer-summary": "true" },
        children: [renderFractionAnswerSummary(state.answerNumerator, question.denominator)],
      }),
      el("div", {
        className: "fraction-answer-actions",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "-1 片",
            attrs: { type: "button", disabled: state.isAnswered ? "disabled" : null },
            on: { click: () => onAdjustAnswer(-1) },
          }),
          el("button", {
            className: "button button--secondary",
            text: "+1 片",
            attrs: { type: "button", disabled: state.isAnswered ? "disabled" : null },
            on: { click: () => onAdjustAnswer(1) },
          }),
          el("button", {
            className: "button button--primary",
            text: "送出披薩答案",
            attrs: { type: "button", disabled: state.isAnswered ? "disabled" : null },
            on: { click: onSubmitPizzaAnswer },
          }),
        ],
      }),
    ],
  });
}

function renderNumberField(label, field, value, onSetCustomField, min, max) {
  return el("label", {
    className: "fraction-builder-field",
    children: [
      el("span", { text: label }),
      el("input", {
        attrs: {
          type: "number",
          min,
          max,
          value,
        },
        on: {
          change: (event) => onSetCustomField(field, event.target.value),
        },
      }),
    ],
  });
}

function renderOperatorField(value, onSetCustomField) {
  return el("label", {
    className: "fraction-builder-field",
    children: [
      el("span", { text: "運算" }),
      el("select", {
        attrs: { value },
        on: {
          change: (event) => onSetCustomField("operator", event.target.value),
        },
        children: [
          el("option", { text: "加法 +", attrs: { value: "+", selected: value === "+" ? "selected" : null } }),
          el("option", { text: "減法 -", attrs: { value: "-", selected: value === "-" ? "selected" : null } }),
        ],
      }),
    ],
  });
}

function renderFractionVisuals(question, state) {
  const showPie = state.visual === "both" || state.visual === "pie";
  const showBar = state.visual === "both" || state.visual === "bar";
  const items = [
    { label: "第一個分數", numerator: question.first },
    { label: "第二個分數", numerator: question.second },
  ];

  if (state.isAnswered) {
    items.push({ label: "計算結果", numerator: question.answer, result: true });
  }

  return el("div", {
    className: "fraction-visuals",
    children: items.map((item) =>
      el("div", {
        className: `fraction-visual-card${item.result ? " is-result" : ""}`,
        children: [
          el("strong", { text: item.label }),
          showPie ? renderPie(item.numerator, question.denominator) : null,
          showBar ? renderBar(item.numerator, question.denominator) : null,
          el("span", { text: `${item.numerator}/${question.denominator}` }),
        ],
      }),
    ),
  });
}

function renderPie(numerator, denominator, isInteractive = false) {
  const wholeCount = Math.floor(numerator / denominator);
  const remainder = numerator % denominator;
  const slice = 360 / denominator;
  const pieNumerators = [
    ...Array.from({ length: wholeCount }, () => denominator),
    ...(remainder > 0 || numerator === 0 ? [remainder] : []),
  ];

  return el("div", {
    className: `fraction-pizza-stack${isInteractive ? " is-interactive" : ""}`,
    children: pieNumerators.map((pieNumerator, index) => {
      const percent = (pieNumerator / denominator) * 100;
      return el("div", {
        className: `fraction-pie${pieNumerator === denominator ? " is-whole" : ""}`,
        attrs: { style: `--fraction-percent:${percent}; --fraction-slice:${slice}deg;` },
        children: [el("i", { text: index === 0 ? `${numerator}/${denominator}` : `+${pieNumerator}/${denominator}` })],
      });
    }),
  });
}

export function renderFractionPizza(numerator, denominator, isInteractive = false) {
  return renderPie(numerator, denominator, isInteractive);
}

function renderBar(numerator, denominator) {
  const wholeCount = Math.floor(numerator / denominator);
  const remainder = numerator % denominator;
  const barNumerators = [
    ...Array.from({ length: wholeCount }, () => denominator),
    ...(remainder > 0 || numerator === 0 ? [remainder] : []),
  ];

  return el("div", {
    className: "fraction-bar-stack",
    children: barNumerators.map((barNumerator) =>
      el("div", {
        className: "fraction-bar",
        attrs: { style: `--fraction-denominator:${denominator};` },
        children: Array.from({ length: denominator }, (_, index) =>
          el("span", { className: index < barNumerator ? "is-filled" : "" }),
        ),
      }),
    ),
  });
}

function buildFractionOptions(answer, denominator, index) {
  const values = [answer, answer - 2, answer - 1, answer + 1, answer + 2]
    .filter((value) => value >= 0 && value <= denominator * 2);
  const unique = [...new Set(values)];
  let candidate = 0;
  while (unique.length < 4 && candidate <= denominator * 2) {
    if (!unique.includes(candidate)) unique.push(candidate);
    candidate += 1;
  }
  return unique.slice(0, 4).sort((a, b) => ((a + index) % 4) - ((b + index) % 4));
}

function getFractionOptionClass(option, answer, state) {
  const classes = ["fraction-option"];
  if (!state.isAnswered && state.selected === option) classes.push("is-selected");
  if (state.isAnswered && option === answer) classes.push("is-correct");
  if (state.isAnswered && state.selected === option && option !== answer) classes.push("is-wrong");
  return classes.join(" ");
}

function buildExplanation(question) {
  const action = question.operator === "+" ? "分子相加" : "分子相減";
  const whole = Math.floor(question.answer / question.denominator);
  const rest = question.answer % question.denominator;
  const mixed = whole > 0 ? `也就是 ${whole} 個完整披薩又 ${rest} 片。` : "";
  return `同分母時，分母 ${question.denominator} 不變，只要把${action}，答案是 ${question.answer}/${question.denominator}。${mixed}`;
}

function clampInteger(value, min, max) {
  const number = Number.parseInt(value, 10);
  if (!Number.isFinite(number)) return min;
  return Math.min(max, Math.max(min, number));
}

function randomInteger(min, max) {
  if (max <= min) return min;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

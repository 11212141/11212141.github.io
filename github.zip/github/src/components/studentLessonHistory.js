import { el } from "../utils/dom.js";
import { addStudentLessonRecord, getStudentLessonHistory } from "../utils/studentLessonHistoryStore.js";

export function renderStudentLessonHistory(student) {
  const saveText = el("span", {
    className: "student-status-save",
    text: getHistorySummary(student.id),
  });

  const lessonDateField = inputField("上課日期", "date");
  lessonDateField.value = getTodayValue();

  const subjectSelect = selectField("科目", [
    { value: "", label: "請選擇" },
    { value: "英文", label: "英文" },
    { value: "數學", label: "數學" },
    { value: "其他", label: "其他" },
  ]);

  const lessonStateSelect = selectField("上課狀況", [
    { value: "", label: "請選擇" },
    { value: "主動", label: "主動" },
    { value: "普通", label: "普通" },
    { value: "較少", label: "較少" },
    { value: "未出席", label: "未出席" },
  ]);

  const noteField = textareaField("上課紀錄", "記錄這次上課的表現或狀況");
  const reminderField = textareaField("下次重點", "記錄下次上課要留意的事");

  const historyList = el("div", { className: "student-history-list" });

  function refreshHistory() {
    const records = getStudentLessonHistory(student.id);

    saveText.textContent = getHistorySummary(student.id);
    historyList.replaceChildren(
      ...(records.length > 0
        ? records.map((record) => renderHistoryItem(record))
        : [
            el("div", {
              className: "student-history-empty",
              text: "尚無上課歷程",
            }),
          ]),
    );
  }

  const saveButton = el("button", {
    className: "button button--primary",
    text: "新增紀錄",
    attrs: { type: "button" },
    on: {
      click: () => {
        const note = noteField.value.trim();
        const reminder = reminderField.value.trim();

        if (!lessonDateField.value || !subjectSelect.value || !note) {
          saveText.textContent = "請先填寫日期、科目和上課紀錄";
          return;
        }

        addStudentLessonRecord(student.id, {
          date: lessonDateField.value,
          subject: subjectSelect.value,
          lessonState: lessonStateSelect.value,
          note,
          reminder,
          createdAt: formatTimestamp(new Date()),
        });

        lessonStateSelect.value = "";
        noteField.value = "";
        reminderField.value = "";
        refreshHistory();
      },
    },
  });

  const card = el("section", {
    className: "student-status-card",
    children: [
      el("div", {
        className: "student-status-card__header",
        children: [el("strong", { text: "上課歷程" }), saveText],
      }),
      el("div", {
        className: "student-status-grid",
        children: [
          fieldWrap("上課日期", lessonDateField),
          fieldWrap("科目", subjectSelect),
        ],
      }),
      el("div", {
        className: "student-status-grid",
        children: [
          fieldWrap("目前狀態", lessonStateSelect),
        ],
      }),
      fieldWrap("上課紀錄", noteField),
      fieldWrap("下次重點", reminderField),
      el("div", {
        className: "button-row",
        children: [saveButton],
      }),
      historyList,
    ],
  });

  refreshHistory();
  return card;
}

function fieldWrap(label, control) {
  return el("label", {
    className: "student-field",
    children: [el("span", { text: label }), control],
  });
}

function selectField(label, options) {
  return el("select", {
    attrs: {
      "aria-label": label,
    },
    children: options.map((option) =>
      el("option", {
        text: option.label,
        attrs: {
          value: option.value,
        },
      }),
    ),
  });
}

function inputField(label, type) {
  return el("input", {
    attrs: {
      type,
      "aria-label": label,
    },
  });
}

function textareaField(label, placeholder) {
  return el("textarea", {
    attrs: {
      rows: "3",
      placeholder,
      "aria-label": label,
    },
  });
}

function formatTimestamp(date) {
  return date.toLocaleString("zh-TW", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function renderHistoryItem(record) {
  return el("article", {
    className: "student-history-item",
    children: [
      el("div", {
        className: "student-history-item__header",
        children: [
          el("strong", { text: `${record.date}｜${record.subject}` }),
          el("span", {
            className: "pill",
            text: record.lessonState || "未填狀況",
          }),
        ],
      }),
      el("p", { text: record.note }),
      record.reminder
        ? el("div", {
            className: "student-history-note",
            children: [el("span", { text: "下次重點" }), el("p", { text: record.reminder })],
          })
        : null,
    ],
  });
}

function getHistorySummary(studentId) {
  const records = getStudentLessonHistory(studentId);
  return records.length > 0 ? `已記錄 ${records.length} 筆` : "尚無記錄";
}

function getTodayValue() {
  const now = new Date();
  const year = now.getFullYear();
  const month = `${now.getMonth() + 1}`.padStart(2, "0");
  const day = `${now.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

import { el, sectionTitle } from "../utils/dom.js";

export function renderEnglishNumberGames({
  challenge,
  listenState,
  mathState,
  listenAnswerMode = "number",
  onToggleListenMode,
  onSelectListenPlayer,
  onSelectMathPlayer,
  onChooseListenAnswer,
  onChooseMathAnswer,
  onNextListenRound,
  onNextMathRound,
  onResetListenGame,
  onResetMathGame,
}) {
  const section = el("section", { className: "panel", attrs: { id: "english-number-game" } });
  section.append(
    el("div", {
      className: "panel__content",
      children: [
        sectionTitle(challenge.title, "", el("span", { className: "badge badge--live", text: challenge.badge })),
        el("div", {
          className: "number-game-stack",
          children: [
            renderNumberGamePanel({
              title: "遊戲一：聽英文選數字",
              badge: "1-20",
              mode: "listen",
              challenge,
              rounds: challenge.listenRounds,
              gameState: listenState,
              answerMode: listenAnswerMode,
              onToggleMode: onToggleListenMode,
              onSelectPlayer: onSelectListenPlayer,
              onChooseAnswer: onChooseListenAnswer,
              onNextRound: onNextListenRound,
              onResetGame: onResetListenGame,
            }),
            renderNumberGamePanel({
              title: "遊戲二：算式選英文",
              badge: "加減乘除",
              mode: "math",
              challenge,
              rounds: challenge.mathRounds,
              gameState: mathState,
              onSelectPlayer: onSelectMathPlayer,
              onChooseAnswer: onChooseMathAnswer,
              onNextRound: onNextMathRound,
              onResetGame: onResetMathGame,
            }),
          ],
        }),
      ],
    }),
  );

  return section;
}

function renderNumberGamePanel({
  title,
  badge,
  mode,
  challenge,
  rounds,
  gameState,
  answerMode = "number",
  onToggleMode,
  onSelectPlayer,
  onChooseAnswer,
  onNextRound,
  onResetGame,
}) {
  if (gameState.finished) {
    return renderFinishedPanel({ title, badge, gameState, onResetGame });
  }

  const round = rounds[gameState.roundIndex];
  const answerWord = getNumberWord(challenge, round.answer);
  const activePlayer = gameState.players[gameState.activePlayerIndex];
  const headerActions = [
    mode === "listen"
      ? el("button", {
          className: "button button--secondary",
          text: answerMode === "number" ? "切換算式模式" : "切換數字模式",
          attrs: { type: "button" },
          on: { click: onToggleMode },
        })
      : null,
    el("button", {
      className: "button button--ghost",
      text: "重新開始",
      attrs: { type: "button" },
      on: { click: onResetGame },
    }),
  ].filter(Boolean);

  return el("article", {
    className: `number-game-card number-game-card--${mode}`,
    children: [
      el("div", {
        className: "number-game-card__head",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--warm", text: badge }),
              el("h3", { text: title }),
            ],
          }),
          el("div", { className: "button-row", children: headerActions }),
        ],
      }),
      renderPlayerRow(gameState, onSelectPlayer),
      mode === "listen"
        ? renderListenPrompt({ answerWord, gameState, activePlayer, answerMode })
        : renderMathPrompt({ round, answerWord, gameState, activePlayer }),
      el("div", {
        className: "number-option-grid",
        children: round.options.map((value) =>
          renderAnswerButton({
            challenge,
            value,
            mode,
            answerMode,
            gameState,
            answer: round.answer,
            onChooseAnswer,
          }),
        ),
      }),
      renderFeedback(challenge, gameState, round),
      el("div", {
        className: "number-game-actions",
        children: [
          el("button", {
            className: "button button--primary",
            text: gameState.roundIndex === gameState.totalRounds - 1 ? "看結果" : "下一題",
            attrs: {
              type: "button",
              disabled: gameState.isAnswered ? null : "disabled",
            },
            on: { click: onNextRound },
          }),
        ],
      }),
    ],
  });
}

function renderPlayerRow(gameState, onSelectPlayer) {
  return el("div", {
    className: "number-player-row",
    children: gameState.players.map((player, index) =>
      el("button", {
        className: `number-player-chip${index === gameState.activePlayerIndex ? " is-active" : ""}`,
        attrs: {
          type: "button",
          disabled: gameState.isAnswered ? "disabled" : null,
        },
        on: { click: () => onSelectPlayer(index) },
        children: [
          el("strong", { text: player.name }),
          el("span", { text: `${player.score} 分` }),
        ],
      }),
    ),
  });
}

function renderListenPrompt({ answerWord, gameState, activePlayer, answerMode }) {
  return el("div", {
    className: "number-prompt-card",
    children: [
      el("span", { className: "pill", text: `輪到 ${activePlayer.name}` }),
      el("span", { className: "pill", text: `第 ${gameState.roundIndex + 1} 題` }),
      el("strong", { className: "number-word", text: answerWord }),
      el("p", {
        text:
          answerMode === "number"
            ? "請選出對應的數字。"
            : "請選出答案等於這個英文數字的算式。",
      }),
    ],
  });
}

function renderMathPrompt({ round, answerWord, gameState, activePlayer }) {
  return el("div", {
    className: "number-prompt-card number-prompt-card--math",
    children: [
      el("span", { className: "pill", text: `輪到 ${activePlayer.name}` }),
      el("span", { className: "pill", text: round.operation }),
      el("strong", { className: "number-equation", text: `${round.expression} = ?` }),
      el("p", { text: `答案在 1-20 裡，請選英文：${gameState.isAnswered ? answerWord : "?"}` }),
    ],
  });
}

function renderAnswerButton({ challenge, value, mode, answerMode, gameState, answer, onChooseAnswer }) {
  const isSelected = gameState.selectedAnswer === value;
  const isCorrect = gameState.isAnswered && value === answer;
  const isWrong = gameState.isAnswered && isSelected && value !== answer;
  const label =
    mode === "listen" && answerMode === "equation"
      ? getNumberEquation(value)
      : mode === "listen"
        ? String(value)
        : getNumberWord(challenge, value);
  const note =
    mode === "listen" && answerMode === "equation"
      ? "算式等於幾？"
      : mode === "listen"
        ? ""
        : `${value}`;

  return el("button", {
    className: `number-answer-card${isSelected ? " is-selected" : ""}${isCorrect ? " is-correct" : ""}${isWrong ? " is-wrong" : ""}`,
    attrs: {
      type: "button",
      disabled: gameState.isAnswered ? "disabled" : null,
    },
    on: { click: () => onChooseAnswer(value) },
    children: [
      el("span", { className: "pill", text: getOptionBadge(mode, answerMode) }),
      el("strong", { text: label }),
      note ? el("p", { text: note }) : null,
    ],
  });
}

function renderFeedback(challenge, gameState, round) {
  if (!gameState.lastResult) {
    return null;
  }

  const answerWord = getNumberWord(challenge, round.answer);

  return el("div", {
    className: `number-feedback${gameState.lastResult.isCorrect ? " is-success" : " is-retry"}`,
    children: [
      el("strong", { text: gameState.lastResult.isCorrect ? "答對了" : "再試一次" }),
      el("p", { text: `${round.answer} = ${answerWord}` }),
    ],
  });
}

function renderFinishedPanel({ title, badge, gameState, onResetGame }) {
  const winner = [...gameState.players].sort((left, right) => right.score - left.score)[0];

  return el("article", {
    className: "number-game-card",
    children: [
      el("div", {
        className: "number-finish-card",
        children: [
          el("span", { className: "badge badge--warm", text: badge }),
          el("h3", { text: `${title}完成` }),
          el("p", { text: `${winner.name} ${winner.score} 分` }),
        ],
      }),
      el("div", {
        className: "number-score-grid",
        children: gameState.players.map((player) =>
          el("div", {
            className: "number-score-card",
            children: [
              el("strong", { text: player.name }),
              el("span", { text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("button", {
        className: "button button--primary",
        text: "再玩一次",
        attrs: { type: "button" },
        on: { click: onResetGame },
      }),
    ],
  });
}

function getNumberWord(challenge, value) {
  return challenge.numbers.find((number) => number.value === value)?.word ?? String(value);
}

function getOptionBadge(mode, answerMode) {
  if (mode !== "listen") {
    return "English";
  }

  return answerMode === "equation" ? "算式" : "Number";
}

function getNumberEquation(value) {
  const equations = {
    1: "2 - 1 = ?",
    2: "1 + 1 = ?",
    3: "5 - 2 = ?",
    4: "2 + 2 = ?",
    5: "10 - 5 = ?",
    6: "3 + 3 = ?",
    7: "10 - 3 = ?",
    8: "4 + 4 = ?",
    9: "3 × 3 = ?",
    10: "5 + 5 = ?",
    11: "20 - 9 = ?",
    12: "3 × 4 = ?",
    13: "10 + 3 = ?",
    14: "7 + 7 = ?",
    15: "3 × 5 = ?",
    16: "8 + 8 = ?",
    17: "20 - 3 = ?",
    18: "9 + 9 = ?",
    19: "20 - 1 = ?",
    20: "10 + 10 = ?",
  };

  return equations[value] ?? `${value} = ?`;
}

import { el, sectionTitle } from "../utils/dom.js";

const sizeLabels = {
  4: "4×4",
  6: "6×6",
  9: "9×9",
};

const difficultyLabels = {
  easy: "入門",
  medium: "中階",
  hard: "挑戰",
};

export function renderSudokuGame({
  state,
  onSetSize,
  onSetDifficulty,
  onNewPuzzle,
  onSelectNumber,
  onPlaceNumber,
  onClearCell,
  onCheckAnswer,
  onRevealAnswer,
}) {
  return el("section", {
    className: "panel sudoku-panel",
    attrs: { id: "sudoku-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("數獨挑戰", "", el("span", { className: "badge badge--live", text: "數學活動" })),
          el("div", {
            className: "sudoku-layout",
            children: [
              el("aside", {
                className: "sudoku-control-card",
                children: [
                  renderSettings({ state, onSetSize, onSetDifficulty, onNewPuzzle }),
                  renderNumberTray({ state, onSelectNumber }),
                  renderStatusCard({ state, onCheckAnswer, onRevealAnswer }),
                ],
              }),
              renderBoard({ state, onPlaceNumber, onClearCell }),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderSettings({ state, onSetSize, onSetDifficulty, onNewPuzzle }) {
  return el("section", {
    className: "sudoku-settings",
    children: [
      el("span", { className: "badge badge--warm", text: "遊戲設定" }),
      el("div", {
        className: "sudoku-setting-group",
        children: [
          el("strong", { text: "格數" }),
          el("div", {
            className: "sudoku-button-grid",
            children: [4, 6, 9].map((size) =>
              el("button", {
                className: state.size === size ? "is-active" : "",
                text: sizeLabels[size],
                attrs: { type: "button" },
                on: { click: () => onSetSize(size) },
              }),
            ),
          }),
        ],
      }),
      el("div", {
        className: "sudoku-setting-group",
        children: [
          el("strong", { text: "難度" }),
          el("div", {
            className: "sudoku-button-grid",
            children: ["easy", "medium", "hard"].map((difficulty) =>
              el("button", {
                className: state.difficulty === difficulty ? "is-active" : "",
                text: difficultyLabels[difficulty],
                attrs: { type: "button" },
                on: { click: () => onSetDifficulty(difficulty) },
              }),
            ),
          }),
        ],
      }),
      el("button", {
        className: "button button--primary button--full",
        text: "重新出題",
        attrs: { type: "button" },
        on: { click: onNewPuzzle },
      }),
    ],
  });
}

function renderNumberTray({ state, onSelectNumber }) {
  return el("section", {
    className: "sudoku-number-card",
    children: [
      el("strong", { text: "數字卡" }),
      el("div", {
        className: "sudoku-number-tray",
        children: Array.from({ length: state.size }, (_, index) => index + 1).map((value) =>
          el("button", {
            className: state.selectedNumber === value ? "sudoku-number is-active" : "sudoku-number",
            text: String(value),
            attrs: {
              type: "button",
              draggable: "true",
            },
            dataset: { value },
            on: {
              click: () => onSelectNumber(value),
              dragstart: (event) => {
                event.dataTransfer.setData("text/plain", String(value));
                event.dataTransfer.effectAllowed = "copy";
              },
            },
          }),
        ),
      }),
    ],
  });
}

function renderStatusCard({ state, onCheckAnswer, onRevealAnswer }) {
  return el("section", {
    className: "sudoku-status-card",
    children: [
      el("span", { text: "目前狀態" }),
      el("strong", { text: state.message || "把數字卡拖進空格。" }),
      el("div", {
        className: "sudoku-mini-stats",
        children: [
          el("i", { text: `${state.size}×${state.size}` }),
          el("i", { text: difficultyLabels[state.difficulty] }),
          el("i", { text: `空格 ${countEmptyCells(state.grid)}` }),
        ],
      }),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "檢查",
            attrs: { type: "button" },
            on: { click: onCheckAnswer },
          }),
          el("button", {
            className: "button button--ghost",
            text: "看答案",
            attrs: { type: "button" },
            on: { click: onRevealAnswer },
          }),
        ],
      }),
    ],
  });
}

function renderBoard({ state, onPlaceNumber, onClearCell }) {
  const box = getBoxShape(state.size);

  return el("section", {
    className: `sudoku-board-card sudoku-board-card--${state.size}`,
    children: [
      el("div", {
        className: "sudoku-board",
        attrs: {
          style: `--sudoku-size:${state.size}; --sudoku-box-width:${box.width}; --sudoku-box-height:${box.height};`,
        },
        children: state.grid.flatMap((row, rowIndex) =>
          row.map((value, colIndex) => {
            const fixed = state.fixed[rowIndex][colIndex];
            const cellClass = [
              "sudoku-cell",
              fixed ? "is-fixed" : "",
              state.conflicts.some((cell) => cell.row === rowIndex && cell.col === colIndex) ? "is-conflict" : "",
              colIndex > 0 && colIndex % box.width === 0 ? "has-left-line" : "",
              rowIndex > 0 && rowIndex % box.height === 0 ? "has-top-line" : "",
            ]
              .filter(Boolean)
              .join(" ");

            return el("button", {
              className: cellClass,
              attrs: { type: "button" },
              dataset: { row: rowIndex, col: colIndex },
              children: [
                !fixed ? el("span", { className: "sudoku-cell-label", text: getCellLabel(rowIndex, colIndex) }) : null,
                value ? el("strong", { text: String(value) }) : null,
              ],
              on: {
                click: () => {
                  if (fixed) return;
                  if (state.selectedNumber) {
                    onPlaceNumber(rowIndex, colIndex, state.selectedNumber);
                  }
                },
                dblclick: () => {
                  if (!fixed) onClearCell(rowIndex, colIndex);
                },
                dragover: (event) => {
                  if (!fixed) event.preventDefault();
                },
                drop: (event) => {
                  if (fixed) return;
                  event.preventDefault();
                  const valueFromDrag = Number(event.dataTransfer.getData("text/plain"));
                  if (valueFromDrag) onPlaceNumber(rowIndex, colIndex, valueFromDrag);
                },
              },
            });
          }),
        ),
      }),
      el("p", {
        className: "sudoku-board-hint",
        text: "拖數字卡到空格；也可以先點數字，再點格子。雙擊空格可清除。",
      }),
    ],
  });
}

function getBoxShape(size) {
  if (size === 6) return { width: 3, height: 2 };
  if (size === 4) return { width: 2, height: 2 };
  return { width: 3, height: 3 };
}

function getCellLabel(rowIndex, colIndex) {
  return `${String.fromCharCode(65 + colIndex)}${rowIndex + 1}`;
}

function countEmptyCells(grid) {
  return grid.flat().filter((value) => !value).length;
}

import { el, sectionTitle } from "../utils/dom.js";

export function renderMoneyBuilderGame({
  challenge,
  gameState,
  onSelectPlayer,
  onAddValue,
  onRemoveValue,
  onClearValues,
  onSubmitRound,
  onToggleTarget,
  onNextRound,
  onResetGame,
}) {
  const section = el("section", { className: "panel", attrs: { id: "money-game" } });
  const currentRound = challenge.rounds[gameState.roundIndex];
  const activePlayer = gameState.players[gameState.activePlayerIndex];

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(challenge.title, "", el("span", { className: "badge badge--warm", text: challenge.badge })),
      el("div", {
        className: "money-layout",
        children: [
          renderPlayerBoard(gameState, onSelectPlayer),
          gameState.finished
            ? renderFinishedState(gameState, onResetGame)
            : renderRoundStage({
                challenge,
                gameState,
                currentRound,
                activePlayer,
                onAddValue,
                onRemoveValue,
                onClearValues,
                onSubmitRound,
                onToggleTarget,
                onNextRound,
                onResetGame,
              }),
        ],
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderPlayerBoard(gameState, onSelectPlayer) {
  const progress = Math.round(((gameState.roundIndex + 1) / gameState.totalRounds) * 100);

  return el("div", {
    className: "money-player-board",
    children: [
      el("div", {
        className: "money-board-head",
        children: [
          el("strong", { text: "四位學生輪流區" }),
          el("span", { className: "pill", text: `第 ${Math.min(gameState.roundIndex + 1, gameState.totalRounds)} 題` }),
        ],
      }),
      el("div", {
        className: "money-map-card",
        children: [
          el("div", {
            className: "money-map-card__head",
            children: [
              el("strong", { text: "挑戰進度" }),
              el("span", { text: `${progress}%` }),
            ],
          }),
          el("div", {
            className: "money-progress-track",
            children: [
              el("span", {
                className: "money-progress-bar",
                attrs: { style: `width:${progress}%;` },
              }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "money-player-list",
        children: gameState.players.map((player, index) =>
          el("button", {
            className: `money-player-card${index === gameState.activePlayerIndex ? " is-active" : ""}`,
            attrs: { type: "button" },
            on: {
              click: () => onSelectPlayer(index),
            },
            children: [
              el("div", {
                className: "money-player-meta",
                children: [
                  el("strong", { text: player.name }),
                  el("span", { text: index === gameState.activePlayerIndex ? "目前作答" : "等待中" }),
                ],
              }),
              el("span", { className: "money-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
    ],
  });
}

function renderRoundStage({
  challenge,
  gameState,
  currentRound,
  activePlayer,
  onAddValue,
  onRemoveValue,
  onClearValues,
  onSubmitRound,
  onToggleTarget,
  onNextRound,
  onResetGame,
}) {
  const currentTotal = gameState.selectedValues.reduce((sum, value) => sum + value, 0);
  const difference = currentRound.target - currentTotal;
  const statusText = getDifferenceLabel(difference);
  const progressPercent = Math.min(100, Math.round((currentTotal / currentRound.target) * 100));

  return el("div", {
    className: "money-stage",
    children: [
      el("div", {
        className: "money-stage__header",
        children: [
          el("div", {
            children: [
              el("span", { className: "badge badge--live", text: `輪到 ${activePlayer.name}` }),
              el("h3", { text: currentRound.scene ?? "金錢任務" }),
            ],
          }),
          el("div", {
            className: "button-row",
            children: [
              el("button", {
                className: "button button--ghost",
                text: "重新開始",
                attrs: { type: "button" },
                on: { click: onResetGame },
              }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "money-target-card",
        children: [
          el("div", {
            className: "money-mission-topline",
            children: [
              el("span", { className: "badge badge--warm", text: `第 ${gameState.roundIndex + 1} 題` }),
              el("span", { className: "money-mission-chip", text: currentRound.targetLabel ?? "目標金額" }),
            ],
          }),
          el("p", { text: currentRound.prompt }),
          el("small", { text: currentRound.question ?? "用面額拼出目標金額。" }),
          gameState.showTarget
            ? el("div", {
                className: "money-target-amount",
                children: [
                  el("span", { text: "要拼到" }),
                  el("strong", { text: `${currentRound.target} 元` }),
                ],
              })
            : el("button", {
                className: "money-target-reveal",
                text: "顯示目標金額",
                attrs: { type: "button" },
                on: { click: onToggleTarget },
              }),
        ],
      }),
      el("div", {
        className: "money-concept-card",
        children: [
          el("strong", { text: "理財小觀念" }),
          el("p", { text: currentRound.concept ?? "先看清楚題目，再決定要拿哪些面額。" }),
        ],
      }),
      el("div", {
        className: "money-bank-grid",
        children: challenge.denominations.map((value) =>
          renderMoneyButton(value, gameState, onAddValue),
        ),
      }),
      el("div", {
        className: "money-summary-grid",
        children: [
          el("div", {
            className: "money-build-card",
            children: [
              el("div", {
                className: "money-build-card__header",
                children: [el("strong", { text: "目前拼法" }), el("span", { className: "pill", text: statusText })],
              }),
              gameState.selectedValues.length > 0
                ? el("div", {
                    className: "money-token-list",
                    children: gameState.selectedValues.map((value, index) =>
                      el("span", {
                        className: `money-token money-token--${getMoneyKind(value)}`,
                        text: `${value} 元`,
                        attrs: { style: `--money-token-index:${index};` },
                      }),
                    ),
                  })
                : el("div", { className: "money-placeholder-box", text: "點選面額，錢會放進這裡" }),
              el("p", {
                className: "money-expression",
                text:
                  gameState.selectedValues.length > 0
                    ? `${gameState.selectedValues.join(" + ")} = ${currentTotal}`
                    : "",
              }),
            ],
          }),
          el("div", {
            className: "money-total-card",
            children: [
              el("div", {
                className: "money-vault-card",
                children: [
                  el("div", {
                    className: "money-vault-card__head",
                    children: [
                      el("strong", { text: "金庫能量" }),
                      el("span", { text: `${progressPercent}%` }),
                    ],
                  }),
                  el("div", {
                    className: "money-vault-track",
                    children: [
                      el("span", {
                        className: "money-vault-fill",
                        attrs: { style: `width:${progressPercent}%;` },
                      }),
                    ],
                  }),
                  el("p", { text: getNextStepHint(difference) }),
                ],
              }),
              metaCard("目標金額", `${currentRound.target} 元`),
              metaCard("目前總和", `${currentTotal} 元`),
              metaCard("差距", statusText),
              metaCard("已用個數", `${gameState.selectedValues.length}`),
            ],
          }),
        ],
      }),
      renderFeedback(challenge, gameState, currentRound, difference),
      el("div", {
        className: "money-actions",
        children: [
          el("button", {
            className: "button button--secondary",
            text: "收回一個",
            attrs: {
              type: "button",
              disabled: gameState.solved || gameState.selectedValues.length === 0 ? "disabled" : null,
            },
            on: { click: onRemoveValue },
          }),
          el("button", {
            className: "button button--ghost",
            text: "清空重拼",
            attrs: {
              type: "button",
              disabled: gameState.solved || gameState.selectedValues.length === 0 ? "disabled" : null,
            },
            on: { click: onClearValues },
          }),
          el("button", {
            className: "button button--primary",
            text: "送出拼法",
            attrs: {
              type: "button",
              disabled: gameState.solved || gameState.selectedValues.length === 0 ? "disabled" : null,
            },
            on: { click: onSubmitRound },
          }),
          el("button", {
            className: "button button--secondary",
            text: gameState.roundIndex === gameState.totalRounds - 1 ? "看結果" : "下一題",
            attrs: {
              type: "button",
              disabled: gameState.solved ? null : "disabled",
            },
            on: { click: onNextRound },
          }),
        ],
      }),
    ],
  });
}

function renderMoneyButton(value, gameState, onAddValue) {
  return el("button", {
    className: "money-bank-button",
    attrs: {
      type: "button",
      disabled: gameState.solved ? "disabled" : null,
    },
    on: {
      click: () => onAddValue(value),
    },
    children: [
      el("strong", { text: `${value}` }),
      el("small", { text: "元" }),
    ],
  });
}

function renderFeedback(challenge, gameState, currentRound, difference) {
  const currentTotal = gameState.selectedValues.reduce((sum, value) => sum + value, 0);

  if (!gameState.lastResult) {
    return null;
  }

  if (gameState.lastResult.isCorrect) {
    return el("div", {
      className: "money-feedback is-success",
      children: [
        el("strong", { text: "拼對了" }),
        el("p", { text: `${currentTotal} 元` }),
      ],
    });
  }

  return el("div", {
    className: "money-feedback is-retry",
    children: [
      el("strong", { text: "再試一次" }),
      el("p", { text: `${currentTotal} 元，${getDifferenceLabel(difference)}` }),
    ],
  });
}

function renderFinishedState(gameState, onResetGame) {
  const winner = [...gameState.players].sort((left, right) => right.score - left.score)[0];

  return el("div", {
    className: "money-stage",
    children: [
      el("div", {
        className: "money-finish-card",
        children: [
          el("span", { className: "badge badge--warm", text: "挑戰完成" }),
          el("h3", { text: "金錢拼數字完成了" }),
          el("p", { text: `${winner.name} ${winner.score} 分` }),
        ],
      }),
      el("div", {
        className: "money-result-grid",
        children: gameState.players.map((player) =>
          el("div", {
            className: "money-result-card",
            children: [
              el("strong", { text: player.name }),
              el("span", { className: "money-score", text: `${player.score} 分` }),
            ],
          }),
        ),
      }),
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--primary",
            text: "再玩一次",
            attrs: { type: "button" },
            on: { click: onResetGame },
          }),
        ],
      }),
    ],
  });
}

function getDifferenceLabel(difference) {
  if (difference === 0) {
    return "剛剛好";
  }

  if (difference > 0) {
    return `還差 ${difference} 元`;
  }

  return `超過 ${Math.abs(difference)} 元`;
}

function getNextStepHint(difference) {
  if (difference === 0) {
    return "剛剛好，可以送出拼法。";
  }

  if (difference > 0) {
    return `還差 ${difference} 元，可以再想要補大面額還是小面額。`;
  }

  return `超過 ${Math.abs(difference)} 元，可以收回一個再調整。`;
}

function getMoneyKind(value) {
  if (value >= 500) return "large";
  if (value >= 100) return "bill";
  if (value >= 50) return "half";
  return "coin";
}

function metaCard(label, value) {
  return el("div", {
    className: "mini-card",
    html: `<strong>${value}</strong><p>${label}</p>`,
  });
}

import { el, sectionTitle } from "../utils/dom.js";

export function renderModuleMap({ modules, activeModuleId, onModuleSelect }) {
  const section = el("section", { className: "panel", attrs: { id: "modules" } });
  const activeModule = modules.find((module) => module.id === activeModuleId) ?? modules[0];

  const content = el("div", {
    className: "panel__content",
    children: [
      sectionTitle(
        "小遊戲模組地圖",
        "把第一次見面的活動拆成清楚段落，你可以只挑其中兩段，也可以完整走完一整堂破冰課。",
        el("span", { className: "badge badge--warm", text: "模組化設計" }),
      ),
      el("div", {
        className: "module-layout",
        children: [
          el("div", {
            className: "module-list",
            children: modules.map((module) =>
              el("button", {
                className: `module-button${module.id === activeModule.id ? " is-active" : ""}`,
                on: {
                  click: () => onModuleSelect(module.id),
                },
                html: `<strong>${module.index} ${module.name}</strong><span>${module.phase}</span><p>${module.summary}</p>`,
              }),
            ),
          }),
          renderModuleDetail(activeModule),
        ],
      }),
    ],
  });

  section.append(content);
  return section;
}

function renderModuleDetail(module) {
  return el("div", {
    className: "detail-card module-detail",
    children: [
      el("div", {
        className: "module-detail__header",
        children: [
          el("div", {
            children: [
              el("div", { className: "detail-number", text: module.index }),
              el("h3", { text: module.name }),
              el("p", { text: module.summary }),
            ],
          }),
          el("span", { className: "badge badge--warm", text: module.phase }),
        ],
      }),
      el("div", {
        className: "data-grid",
        children: [
          dataPair("活動主題", module.liveTopic),
          dataPair("建議時段", module.liveWindow),
          dataPair("帶法工具", module.tools.join(" / ")),
          dataPair("這段重點", module.phase),
        ],
      }),
      el("div", {
        className: "checkpoint-list",
        children: module.checkpoints.map((checkpoint) => renderCheckpoint(checkpoint)),
      }),
    ],
  });
}

function renderCheckpoint(checkpoint) {
  return el("div", {
    className: "checkpoint",
    children: [
      el("div", { className: "checkpoint__marker" }),
      el("div", {
        children: [el("strong", { text: checkpoint.title }), el("p", { text: checkpoint.detail })],
      }),
    ],
  });
}

function dataPair(label, value) {
  return el("div", {
    className: "data-pair",
    html: `<span>${label}</span><strong>${value}</strong>`,
  });
}

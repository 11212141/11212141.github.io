import { el, sectionTitle } from "../utils/dom.js";

export function renderAngleAdjustGame({
  angle,
  showRightAngle,
  showAngleHint,
  onSetAngle,
  onToggleRightAngle,
  onNudgeAngle,
  onSetPreset,
  onToggleAngleHint,
}) {
  const angleType = getAngleType(angle);
  const end = getRayEnd(angle);
  const arcPath = getArcPath(angle);
  const rightArcPath = getArcPath(90, 32);
  const liveBadge = el("span", {
    className: `badge angle-badge angle-badge--${angleType.id}${showAngleHint ? "" : " is-hidden"}`,
    text: showAngleHint ? angleType.label : "先猜看看",
  });
  const svg = createAngleSvg({ angle, end, arcPath, rightArcPath, showRightAngle });
  const readoutValue = el("strong", { text: `${angle}°` });
  const readoutLabel = el("span", { text: showAngleHint ? angleType.label : "先猜看看" });
  const typeTitle = el("h3", { text: showAngleHint ? angleType.label : "這是什麼角？" });
  const typeDescription = el("p", { text: showAngleHint ? angleType.description : "先觀察它比直角大還是小，再請學生回答。" });
  const slider = el("input", {
    className: "angle-slider",
    attrs: {
      type: "range",
      min: "0",
      max: "180",
      step: "1",
      value: String(angle),
      "aria-label": "調整角度",
      style: `--angle-progress:${(angle / 180) * 100}%;`,
    },
  });

  const updateLiveAngle = (nextAngle) => {
    const normalizedAngle = clampAngle(nextAngle);
    updateAngleView({
      angle: normalizedAngle,
      svg,
      slider,
      liveBadge,
      readoutValue,
      readoutLabel,
      typeTitle,
      typeDescription,
      showAngleHint,
    });
    onSetAngle(normalizedAngle);
  };

  slider.addEventListener("input", (event) => updateLiveAngle(event.target.value));
  enableAngleDrag(svg, updateLiveAngle);

  return el("section", {
    className: "panel angle-panel",
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle(
            "角度調整活動",
            "",
            liveBadge,
          ),
          el("div", {
            className: "angle-layout",
            children: [
              el("article", {
                className: "angle-stage-card",
                children: [
                  el("div", {
                    className: "angle-meter",
                    children: [
                      svg,
                      el("div", {
                        className: "angle-readout",
                        children: [readoutValue, readoutLabel],
                      }),
                    ],
                  }),
                  el("div", {
                    className: "angle-slider-wrap",
                    children: [
                      slider,
                      el("div", {
                        className: "angle-slider-labels",
                        children: [el("span", { text: "0°" }), el("span", { text: "90°" }), el("span", { text: "180°" })],
                      }),
                    ],
                  }),
                ],
              }),
              el("aside", {
                className: "angle-control-card",
                children: [
                  el("div", {
                    className: "angle-type-card",
                    children: [
                      el("span", { className: "badge badge--live", text: "現在角度" }),
                      typeTitle,
                      typeDescription,
                    ],
                  }),
                  el("div", {
                    className: "angle-button-grid",
                    children: [
                      controlButton("-10°", () => onNudgeAngle(-10)),
                      controlButton("-1°", () => onNudgeAngle(-1)),
                      controlButton("+1°", () => onNudgeAngle(1)),
                      controlButton("+10°", () => onNudgeAngle(10)),
                    ],
                  }),
                  el("div", {
                    className: "angle-preset-grid",
                    children: [
                      presetButton("0°", 0, angle, onSetPreset),
                      presetButton("45°", 45, angle, onSetPreset),
                      presetButton("90°", 90, angle, onSetPreset),
                      presetButton("120°", 120, angle, onSetPreset),
                      presetButton("180°", 180, angle, onSetPreset),
                    ],
                  }),
                  el("button", {
                    className: `button ${showRightAngle ? "button--primary" : "button--secondary"} button--full`,
                    text: showRightAngle ? "隱藏直角比較" : "顯示直角比較",
                    attrs: { type: "button" },
                    on: { click: onToggleRightAngle },
                  }),
                  el("button", {
                    className: `button ${showAngleHint ? "button--secondary" : "button--primary"} button--full`,
                    text: showAngleHint ? "隱藏角度提示" : "顯示角度提示",
                    attrs: { type: "button" },
                    on: { click: onToggleAngleHint },
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function updateAngleView({
  angle,
  svg,
  slider,
  liveBadge,
  readoutValue,
  readoutLabel,
  typeTitle,
  typeDescription,
  showAngleHint,
}) {
  const angleType = getAngleType(angle);
  const end = getRayEnd(angle);

  svg.setAttribute("aria-label", `${angle} 度角`);
  svg.querySelector(".angle-arc--soft")?.setAttribute("d", getArcPath(angle));
  const movingRay = svg.querySelector(".angle-ray--moving");
  movingRay?.setAttribute("x2", String(end.x));
  movingRay?.setAttribute("y2", String(end.y));
  const handle = svg.querySelector(".angle-handle");
  handle?.setAttribute("cx", String(end.x));
  handle?.setAttribute("cy", String(end.y));

  slider.value = String(angle);
  slider.style.setProperty("--angle-progress", `${(angle / 180) * 100}%`);
  liveBadge.className = `badge angle-badge angle-badge--${angleType.id}${showAngleHint ? "" : " is-hidden"}`;
  liveBadge.textContent = showAngleHint ? angleType.label : "先猜看看";
  readoutValue.textContent = `${angle}°`;
  readoutLabel.textContent = showAngleHint ? angleType.label : "先猜看看";
  typeTitle.textContent = showAngleHint ? angleType.label : "這是什麼角？";
  typeDescription.textContent = showAngleHint ? angleType.description : "先觀察它比直角大還是小，再請學生回答。";
}

function enableAngleDrag(svg, onUpdateAngle) {
  let isDragging = false;

  const updateFromPointer = (event) => {
    const point = svg.createSVGPoint();
    point.x = event.clientX;
    point.y = event.clientY;
    const svgPoint = point.matrixTransform(svg.getScreenCTM().inverse());
    const origin = getAngleOrigin();
    const dx = svgPoint.x - origin.x;
    const dy = origin.y - svgPoint.y;
    const radians = Math.atan2(Math.max(0, dy), dx);
    const degrees = (radians * 180) / Math.PI;
    onUpdateAngle(clampAngle(degrees));
  };

  svg.addEventListener("pointerdown", (event) => {
    if (!event.target.closest(".angle-ray--moving, .angle-handle, .angle-meter-hitbox")) {
      return;
    }

    isDragging = true;
    svg.setPointerCapture(event.pointerId);
    updateFromPointer(event);
  });

  svg.addEventListener("pointermove", (event) => {
    if (!isDragging) {
      return;
    }

    updateFromPointer(event);
  });

  svg.addEventListener("pointerup", (event) => {
    isDragging = false;
    svg.releasePointerCapture(event.pointerId);
  });

  svg.addEventListener("pointercancel", () => {
    isDragging = false;
  });
}

function createAngleSvg({ angle, end, arcPath, rightArcPath, showRightAngle }) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "angle-svg");
  svg.setAttribute("viewBox", "0 0 360 240");
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", `${angle} 度角`);

  [
    ["rect", { class: "angle-meter-hitbox", x: "0", y: "0", width: "360", height: "240" }],
    ["line", { class: "angle-grid-line", x1: "54", y1: "176", x2: "318", y2: "176" }],
    ["path", { class: "angle-arc angle-arc--soft", d: arcPath }],
    showRightAngle ? ["path", { class: "angle-arc angle-arc--right", d: rightArcPath }] : null,
    showRightAngle ? ["line", { class: "angle-ray angle-ray--right", x1: "206", y1: "176", x2: "206", y2: "96" }] : null,
    ["line", { class: "angle-ray angle-ray--base", x1: "206", y1: "176", x2: "296", y2: "176" }],
    ["line", { class: "angle-ray angle-ray--moving", x1: "206", y1: "176", x2: String(end.x), y2: String(end.y) }],
    ["circle", { class: "angle-point", cx: "206", cy: "176", r: "6" }],
    ["circle", { class: "angle-handle", cx: String(end.x), cy: String(end.y), r: "12" }],
  ].forEach((item) => {
    if (!item) return;
    const [tag, attrs] = item;
    const node = document.createElementNS("http://www.w3.org/2000/svg", tag);
    Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, value));
    svg.append(node);
  });

  return svg;
}

function controlButton(label, onClick) {
  return el("button", {
    className: "button button--secondary",
    text: label,
    attrs: { type: "button" },
    on: { click: onClick },
  });
}

function presetButton(label, value, angle, onSetPreset) {
  return el("button", {
    className: `button ${angle === value ? "button--primary" : "button--secondary"}`,
    text: label,
    attrs: { type: "button" },
    on: { click: () => onSetPreset(value) },
  });
}

function getAngleType(angle) {
  if (angle === 0) {
    return { id: "zero", label: "零角", description: "兩條邊重疊在一起，角度是 0 度。" };
  }

  if (angle < 90) {
    return { id: "acute", label: "銳角", description: "比直角小，角度小於 90 度。" };
  }

  if (angle === 90) {
    return { id: "right", label: "直角", description: "剛好是 90 度，像課本角、桌角一樣方方的。" };
  }

  if (angle < 180) {
    return { id: "obtuse", label: "鈍角", description: "比直角大，但還沒有變成一直線。" };
  }

  return { id: "straight", label: "平角", description: "兩條邊變成一直線，角度是 180 度。" };
}

function getRayEnd(angle) {
  const origin = getAngleOrigin();
  const length = 88;
  const radians = (angle * Math.PI) / 180;

  return {
    x: Math.round(origin.x + Math.cos(radians) * length),
    y: Math.round(origin.y - Math.sin(radians) * length),
  };
}

function getArcPath(angle, radius = 30) {
  const origin = getAngleOrigin();
  const radians = (angle * Math.PI) / 180;
  const end = {
    x: origin.x + Math.cos(radians) * radius,
    y: origin.y - Math.sin(radians) * radius,
  };
  const largeArc = angle > 180 ? 1 : 0;

  return `M ${origin.x + radius} ${origin.y} A ${radius} ${radius} 0 ${largeArc} 0 ${end.x.toFixed(2)} ${end.y.toFixed(2)}`;
}

function clampAngle(angle) {
  return Math.min(180, Math.max(0, Math.round(Number(angle) || 0)));
}

function getAngleOrigin() {
  return { x: 206, y: 176 };
}

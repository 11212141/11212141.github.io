export function renderPeerBoard() {
  return document.createDocumentFragment();
}

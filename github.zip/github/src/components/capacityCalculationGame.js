import { el, sectionTitle } from "../utils/dom.js";

export function renderCapacityCalculationGame({
  challenge,
  state,
  onChooseDigit,
  onSelectSlot,
  onClearAnswer,
  onSubmitAnswer,
  onNextRound,
}) {
  const round = challenge.rounds[state.roundIndex];
  const canSubmit = state.answer.every((digit) => digit !== "") && !state.answered;

  return el("section", {
    className: "panel",
    attrs: { id: "capacity-calculation-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle(challenge.title, "", el("span", { className: "badge badge--live", text: challenge.badge })),
          el("article", {
            className: "length-game-card",
            children: [
              el("div", {
                className: "length-game-card__head",
                children: [
                  el("div", {
                    children: [
                      el("span", { className: "badge badge--warm", text: `第 ${state.roundIndex + 1} / ${challenge.rounds.length} 題` }),
                      el("h3", { text: "公升和毫升直式" }),
                    ],
                  }),
                ],
              }),
              el("div", {
                className: "length-question-board",
                children: [
                  el("strong", {
                    className: "length-expression",
                    text: `${formatValue(round.top, challenge.columns)} ${round.operator} ${formatValue(round.bottom, challenge.columns)} = ?`,
                  }),
                  renderUnitVertical({
                    columns: challenge.columns,
                    round,
                    answer: state.answered ? flattenAnswer(round.answer, challenge.columns) : state.answer,
                    activeSlot: state.activeSlot,
                    answered: state.answered,
                    onSelectSlot,
                  }),
                ],
              }),
              renderDigitPad(state.answered, onChooseDigit),
              renderFeedback(state.result, round, challenge.columns),
              el("div", {
                className: "number-game-actions",
                children: [
                  el("button", {
                    className: "button button--secondary",
                    text: "清除",
                    attrs: { type: "button", disabled: state.answered ? "disabled" : null },
                    on: { click: onClearAnswer },
                  }),
                  el("button", {
                    className: "button button--primary",
                    text: "確認答案",
                    attrs: { type: "button", disabled: canSubmit ? null : "disabled" },
                    on: { click: onSubmitAnswer },
                  }),
                  el("button", {
                    className: "button button--ghost",
                    text: state.roundIndex === challenge.rounds.length - 1 ? "回到第一題" : "下一題",
                    attrs: { type: "button", disabled: state.answered ? null : "disabled" },
                    on: { click: onNextRound },
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

export function renderUnitVertical({ columns, round, answer, activeSlot, answered, onSelectSlot }) {
  const gridTemplate = getGridTemplate(columns);

  return el("div", {
    className: "length-vertical",
    children: [
      renderLabelRow(columns, gridTemplate),
      renderDigitsRow(columns, round.top, "", gridTemplate),
      renderDigitsRow(columns, round.bottom, round.operator, gridTemplate),
      el("div", { className: "length-vertical__line" }),
      renderAnswerRow({
        digits: answer,
        columns,
        gridTemplate,
        activeSlot,
        answered,
        onSelectSlot,
      }),
    ],
  });
}

export function flattenAnswer(answer, columns) {
  return columns.flatMap((column) => padValue(answer[column.key] ?? 0, column.pad).split(""));
}

export function formatValue(values, columns) {
  return columns.map((column) => `${values[column.key] ?? 0} ${column.label}`).join(" ");
}

function renderLabelRow(columns, gridTemplate) {
  return el("div", {
    className: "length-vertical__row length-vertical__labels",
    attrs: { style: `grid-template-columns:${gridTemplate};` },
    children: [
      el("span", { className: "length-vertical__operator" }),
      ...columns.map((column, index) =>
        el("span", {
          className: `length-vertical__label-cell${index > 0 ? " length-vertical__group-start" : ""}`,
          text: column.label,
          attrs: { style: `grid-column: span ${column.digits};` },
        }),
      ),
    ],
  });
}

function renderDigitsRow(columns, values, operator, gridTemplate) {
  return el("div", {
    className: "length-vertical__row",
    attrs: { style: `grid-template-columns:${gridTemplate};` },
    children: [
      el("span", { className: "length-vertical__operator", text: operator }),
      ...columns.flatMap((column, columnIndex) =>
        padValue(values[column.key] ?? 0, column.pad).split("").map((digit, localIndex) =>
          el("span", {
            className: `length-vertical__digit-cell${
              columnIndex > 0 && localIndex === 0 ? " length-vertical__group-start" : ""
            }`,
            text: digit,
          }),
        ),
      ),
    ],
  });
}

function renderAnswerRow({ digits, columns, gridTemplate, activeSlot, answered, onSelectSlot }) {
  const groupStarts = getGroupStartIndexes(columns);

  return el("div", {
    className: "length-vertical__row length-vertical__answer",
    attrs: { style: `grid-template-columns:${gridTemplate};` },
    children: [
      el("span", { className: "length-vertical__operator" }),
      ...digits.map((digit, index) =>
        el("button", {
          className: `length-vertical__slot${groupStarts.includes(index) ? " length-vertical__group-start" : ""}${
            activeSlot === index && !answered ? " is-active" : ""
          }`,
          text: digit || "□",
          attrs: { type: "button", disabled: answered ? "disabled" : null },
          on: { click: () => onSelectSlot(index) },
        }),
      ),
    ],
  });
}

function renderDigitPad(answered, onChooseDigit) {
  return el("div", {
    className: "decimal-digit-pad",
    children: Array.from({ length: 10 }, (_, digit) =>
      el("button", {
        className: "decimal-digit-button",
        text: String(digit),
        attrs: { type: "button", disabled: answered ? "disabled" : null },
        on: { click: () => onChooseDigit(digit) },
      }),
    ),
  });
}

function renderFeedback(result, round, columns) {
  if (!result) {
    return el("p", { className: "decimal-feedback", text: "把公升對公升，毫升對毫升。" });
  }

  const answer = formatValue(round.answer, columns);
  return el("p", {
    className: `decimal-feedback ${result.isCorrect ? "is-correct" : "is-wrong"}`,
    text: result.isCorrect ? `答對了，答案是 ${answer}。` : `再看一次單位，答案是 ${answer}。`,
  });
}

function padValue(value, digits) {
  return String(value).padStart(digits, "0");
}

function getGridTemplate(columns) {
  const totalDigits = columns.reduce((sum, column) => sum + column.digits, 0);
  return `4.4rem repeat(${totalDigits}, minmax(5.6rem, 6.2rem))`;
}

function getGroupStartIndexes(columns) {
  const starts = [];
  let cursor = 0;

  columns.forEach((column, index) => {
    if (index > 0) {
      starts.push(cursor);
    }
    cursor += column.digits;
  });

  return starts;
}

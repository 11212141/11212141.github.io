import { el } from "../utils/dom.js";

export function renderHero({ profile }) {
  const section = el("section", { className: "hero", attrs: { id: "overview" } });
  const container = el("div", { className: "container hero__grid" });

  const leftPanel = el("section", {
    className: "panel",
    children: [
      el("div", {
        className: "panel__content hero-copy",
        children: [
          profile.contextLabel
            ? el("div", {
                className: "eyebrow",
                text: profile.contextLabel,
              })
            : null,
          el("h1", { text: profile.heroTitle }),
          profile.subtitle ? el("p", { text: profile.subtitle }) : null,
        ],
      }),
    ],
  });

  const rightPanel = el("section", {
    className: "panel",
    children: [
      el("div", {
        className: "panel__content hero-side",
        children: [
          el("div", {
            className: "status-card",
            children: [
              el("div", {
                className: "status-top",
                children: [
                  el("div", {
                    children: [
                      el("span", { className: "badge badge--warm", text: "首頁" }),
                      el("h3", { text: profile.focusTitle }),
                    ],
                  }),
                ],
              }),
              el("div", {
                className: "hero-taglist",
                children: profile.highlights.map((tag) => el("span", { text: tag })),
              }),
            ],
          }),
        ],
      }),
    ],
  });

  container.append(leftPanel, rightPanel);
  section.append(container);
  return section;
}

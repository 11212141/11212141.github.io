import { el, sectionTitle } from "../utils/dom.js";

const choiceText = {
  need: {
    label: "需要",
    phrase: "現在需要",
    color: "is-need",
  },
  want: {
    label: "想要",
    phrase: "可以先等",
    color: "is-want",
  },
};

export function renderWantNeedGame({
  challenge,
  state,
  onSelectPlayer,
  onSelectGuardian,
  onDrawCard,
  onChooseNeedType,
  onGuardianVote,
  onNextRound,
  onResetGame,
  onShowResetLock,
  onCancelResetLock,
  onSubmitResetPassword,
}) {
  return el("section", {
    className: "panel want-need-panel",
    attrs: { id: "want-need-game" },
    children: [
      el("div", {
        className: "panel__content",
        children: [
          sectionTitle("願望補給隊", "", el("span", { className: "badge badge--live", text: challenge.badge })),
          state.finished
            ? renderFinished({ state, onShowResetLock, onCancelResetLock, onSubmitResetPassword })
            : renderRound({
                challenge,
                state,
                onSelectPlayer,
                onSelectGuardian,
                onDrawCard,
                onChooseNeedType,
                onGuardianVote,
                onNextRound,
                onResetGame,
                onShowResetLock,
                onCancelResetLock,
                onSubmitResetPassword,
              }),
        ],
      }),
    ],
  });
}

function renderRound({
  challenge,
  state,
  onSelectPlayer,
  onSelectGuardian,
  onDrawCard,
  onChooseNeedType,
  onGuardianVote,
  onNextRound,
  onResetGame,
  onShowResetLock,
  onCancelResetLock,
  onSubmitResetPassword,
}) {
  const activePlayer = state.players[state.activePlayerIndex];
  const guardian = state.players[state.guardianIndex];
  const card = challenge.cards[state.currentCardIndex] ?? challenge.cards[0];

  return el("article", {
    className: "want-need-game",
    children: [
      el("div", {
        className: "want-need-topbar",
        children: [
          renderPlayerPicker({ state, onSelectPlayer }),
          el("button", {
            className: "button button--ghost",
            text: "重新開始",
            attrs: { type: "button" },
            on: { click: onShowResetLock },
          }),
        ],
      }),
      state.resetUnlocked
        ? renderResetLock({ state, onCancelResetLock, onSubmitResetPassword })
        : null,
      renderStoryBanner(challenge, state),
      el("div", {
        className: "want-need-table",
        children: [
          renderMissionDeck({ state, card, activePlayer, onDrawCard }),
          renderDecisionTable({ state, card, activePlayer, guardian, onChooseNeedType, onGuardianVote, onNextRound }),
          el("aside", {
            className: "want-need-table-side",
            children: [
              renderGuardianPanel({ state, guardian, onSelectGuardian }),
              renderResourcePanel(state),
              renderRoundLog(state),
            ],
          }),
        ],
      }),
    ],
  });
}

function renderStoryBanner(challenge, state) {
  return el("div", {
    className: "want-need-story",
    children: [
      el("span", { text: "故事任務" }),
      el("strong", { text: challenge.storyTitle }),
      el("p", { text: challenge.storyText }),
      state.saveStatus ? el("small", { text: state.saveStatus }) : null,
      el("div", {
        className: "want-need-story__progress",
        children: [el("i", { attrs: { style: `width: ${Math.min(100, (state.roundIndex / state.maxRounds) * 100)}%` } })],
      }),
    ],
  });
}

function renderResetLock({ state, onCancelResetLock, onSubmitResetPassword }) {
  const passwordInput = el("input", {
    className: "want-need-reset-input",
    attrs: {
      type: "password",
      inputmode: "numeric",
      maxlength: "4",
      placeholder: "輸入 0000",
      "aria-label": "重新開始密碼",
    },
  });

  return el("section", {
    className: "want-need-reset-lock",
    children: [
      el("strong", { text: "確認重新開始" }),
      el("span", { text: state.resetMessage || "輸入密碼後才會清空目前進度。" }),
      passwordInput,
      el("div", {
        className: "button-row",
        children: [
          el("button", {
            className: "button button--primary",
            text: "確認重開",
            attrs: { type: "button" },
            on: { click: () => onSubmitResetPassword(passwordInput.value) },
          }),
          el("button", {
            className: "button button--secondary",
            text: "取消",
            attrs: { type: "button" },
            on: { click: onCancelResetLock },
          }),
        ],
      }),
    ],
  });
}

function renderPlayerPicker({ state, onSelectPlayer }) {
  return el("div", {
    className: "want-need-player-row",
    children: state.players.map((player, index) =>
      el("button", {
        className: index === state.activePlayerIndex ? "want-need-player is-active" : "want-need-player",
        attrs: { type: "button", disabled: state.phase !== "draw" ? "disabled" : null },
        on: { click: () => onSelectPlayer(index) },
        children: [
          el("strong", { text: player.name }),
          el("span", { text: `${player.score} 星` }),
        ],
      }),
    ),
  });
}

function renderMissionDeck({ state, card, activePlayer, onDrawCard }) {
  const isCovered = state.phase === "draw";

  return el("section", {
    className: "want-need-deck-zone",
    children: [
      el("div", {
        className: state.isDrawing ? "want-need-card-stack is-drawing" : "want-need-card-stack",
        children: [
          el("i"),
          el("i"),
          el("button", {
            className: isCovered ? "want-need-draw-card is-covered" : "want-need-draw-card",
            attrs: { type: "button", disabled: !isCovered || state.isDrawing ? "disabled" : null },
            on: { click: onDrawCard },
            children: isCovered
              ? [
                  el("span", { text: `輪到 ${activePlayer.name}` }),
                  el("strong", { text: state.isDrawing ? "抽卡中" : "抽情境卡" }),
                  el("small", { text: `第 ${state.roundIndex + 1} 回合 / ${state.maxRounds}` }),
                ]
              : [
                  el("span", { text: card.title }),
                  el("strong", { text: card.item }),
                  el("small", { text: card.chinese }),
                ],
          }),
        ],
      }),
      el("div", {
        className: "want-need-phase-track",
        children: [
          renderPhase("抽卡", state.phase === "draw", state.phase !== "draw"),
          renderPhase("判斷", state.phase === "choose", ["guardian", "result"].includes(state.phase)),
          renderPhase("守護", state.phase === "guardian", state.phase === "result"),
          renderPhase("結算", state.phase === "result", false),
        ],
      }),
    ],
  });
}

function renderPhase(label, isActive, isDone) {
  return el("span", {
    className: `${isActive ? "is-active" : ""}${isDone ? " is-done" : ""}`.trim(),
    text: label,
  });
}

function renderDecisionTable({ state, card, activePlayer, guardian, onChooseNeedType, onGuardianVote, onNextRound }) {
  if (state.phase === "draw") {
    return el("section", {
      className: "want-need-decision is-waiting",
      children: [
        el("span", { className: "badge badge--warm", text: "任務桌面" }),
        el("h3", { text: "先抽一張情境卡" }),
        el("p", { text: "抽卡後，隊伍要一起判斷這筆支出是需要，還是想要。" }),
      ],
    });
  }

  const choice = state.choice ? choiceText[state.choice] : null;

  return el("section", {
    className: "want-need-decision",
    children: [
      el("div", {
        className: "want-need-card-head",
        children: [
          el("span", { className: "badge badge--warm", text: "情境卡" }),
          el("strong", { text: card.title }),
        ],
      }),
      el("p", { className: "want-need-scenario", text: card.story }),
      el("div", {
        className: "want-need-item-card",
        children: [
          el("span", { text: card.icon }),
          el("div", {
            children: [
              el("strong", { text: card.item }),
              el("small", { text: card.chinese }),
            ],
          }),
        ],
      }),
      el("div", {
        className: "want-need-sentence",
        children: [
          el("span", { text: `${activePlayer.name} 的理財判斷` }),
          el("strong", { text: state.choice ? `${choice.label}：${card.item}` : "這是需要，還是想要？" }),
        ],
      }),
      state.phase === "choose"
        ? el("div", {
            className: "want-need-choice-grid",
            children: ["need", "want"].map((type) =>
              el("button", {
                className: `want-need-choice ${choiceText[type].color}`,
                attrs: { type: "button" },
                on: { click: () => onChooseNeedType(type) },
                children: [
                  el("span", { text: choiceText[type].phrase }),
                  el("strong", { text: choiceText[type].label }),
                ],
              }),
            ),
          })
        : null,
      state.phase === "guardian" ? renderGuardianVote({ card, choice, guardian, onGuardianVote }) : null,
      state.phase === "result" ? renderResult({ state, card, onNextRound }) : null,
    ],
  });
}

function renderGuardianPanel({ state, guardian, onSelectGuardian }) {
  return el("section", {
    className: "want-need-guardian-card",
    children: [
      el("div", {
        children: [
          el("span", { className: "badge badge--warm", text: "星光裁判" }),
          el("h3", { text: guardian.name }),
          el("p", { text: "用點頭或搖頭決定隊伍是否採用這次判斷。" }),
        ],
      }),
      el("div", {
        className: "want-need-guardian-select",
        children: state.players.map((player, index) =>
          el("button", {
            className: index === state.guardianIndex ? "is-active" : "",
            text: player.name,
            attrs: { type: "button" },
            on: { click: () => onSelectGuardian(index) },
          }),
        ),
      }),
    ],
  });
}

function renderGuardianVote({ card, choice, guardian, onGuardianVote }) {
  return el("div", {
    className: "want-need-guardian-vote",
    children: [
      el("p", { text: `${guardian.name} 判斷「${choice.label}：${card.item}」是否合理。` }),
      el("div", {
        children: [
          el("button", {
            className: "want-need-vote want-need-vote--yes",
            attrs: { type: "button" },
            on: { click: () => onGuardianVote("nod") },
            children: [el("strong", { text: "點頭" }), el("span", { text: "同意這個判斷" })],
          }),
          el("button", {
            className: "want-need-vote want-need-vote--no",
            attrs: { type: "button" },
            on: { click: () => onGuardianVote("shake") },
            children: [el("strong", { text: "搖頭" }), el("span", { text: "想再想一下" })],
          }),
        ],
      }),
    ],
  });
}

function renderResourcePanel(state) {
  return el("section", {
    className: "want-need-resource-grid",
    children: [
      renderResource("星星", state.stars, "團隊分數"),
      renderResource("零用錢", state.coins, "可以花的錢"),
      renderResource("生活力", state.supplies, "必要支出"),
      renderResource("判斷力", state.hearts, "守護力量"),
    ],
  });
}

function renderResource(label, value, helper) {
  return el("div", {
    className: "want-need-resource",
    children: [
      el("span", { text: label }),
      el("strong", { text: String(value) }),
      el("small", { text: helper }),
    ],
  });
}

function renderRoundLog(state) {
  return el("section", {
    className: "want-need-log",
    children: [
      el("span", { text: "任務紀錄" }),
      el("strong", { text: `第 ${state.roundIndex + 1} 回合` }),
      el("p", { text: state.lastResult?.title ?? "還沒有結算，先完成本回合任務。" }),
    ],
  });
}

function renderResult({ state, card, onNextRound }) {
  const result = state.lastResult;

  return el("div", {
    className: result.success ? "want-need-result is-success" : "want-need-result",
    children: [
      el("strong", { text: result.title }),
      el("p", { text: result.message }),
      el("div", {
        className: "want-need-reason",
        children: [
          el("span", { text: "小提醒" }),
          el("p", { text: card.reason }),
        ],
      }),
      el("button", {
        className: "button button--primary button--full",
        text: state.roundIndex + 1 >= state.maxRounds ? "看結局" : "下一回合",
        attrs: { type: "button" },
        on: { click: onNextRound },
      }),
    ],
  });
}

function renderFinished({ state, onShowResetLock, onCancelResetLock, onSubmitResetPassword }) {
  const bestPlayer = [...state.players].sort((a, b) => b.score - a.score)[0];
  const success = state.supplies >= 8 && state.hearts >= 3;

  return el("article", {
    className: "want-need-finished",
    children: [
      el("span", { className: "badge badge--warm", text: success ? "任務成功" : "再挑戰一次" }),
      el("h2", { text: success ? "願望補給隊完成理財任務" : "願望補給隊還需要再想一想" }),
      el("p", {
        text: success
          ? "大家分清楚想要和需要，也讓星光裁判幫隊伍做出重要決定。"
          : "再玩一次時，可以多想想哪些是必要支出，哪些可以先等一等。",
      }),
      el("div", {
        className: "want-need-final-grid",
        children: [
          renderResource("星星", state.stars, "團隊分數"),
          renderResource("生活力", state.supplies, "必要支出"),
          renderResource("判斷力", state.hearts, "合作力量"),
          renderResource("最佳隊友", bestPlayer?.name ?? "大家", `${bestPlayer?.score ?? 0} 星`),
        ],
      }),
      state.resetUnlocked
        ? renderResetLock({ state, onCancelResetLock, onSubmitResetPassword })
        : null,
      el("button", {
        className: "button button--primary",
        text: "重新開始",
        attrs: { type: "button" },
        on: { click: onShowResetLock },
      }),
    ],
  });
}

import { renderHero } from "../components/hero.js";
import { renderPageHub } from "../components/pageHub.js";
import { programProfile, sitePages } from "../data/siteData.js?v=20260917-decimal-intro11";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260917-decimal-intro11";

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("home");
  const overviewPages = sitePages.filter((page) => page.id !== "phonics-game");

  renderPage({
    currentPageId: "home",
    actionText,
    actionHref,
    pages: overviewPages,
    children: [
      renderHero({
        profile: programProfile,
      }),
      mountDashboard([
        renderPageHub({
          pages: overviewPages.filter((page) => page.id !== "home"),
        }),
      ]),
    ],
  });
}

import { renderCanDoGame } from "../components/canDoGame.js?v=20260618-cardplay1";
import { renderPageLead } from "../components/pageLead.js";
import { canDoChallenge, studentProfiles } from "../data/siteData.js?v=20260616-board1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = createGameState();
const gameRoot = document.createElement("div");

renderShell();
renderGame();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("can-do-game");

  renderPage({
    currentPageId: "can-do-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "can-do-top",
        eyebrow: "英文卡牌頁",
        title: "可不可以",
        description: "",
        badge: canDoChallenge.badge,
        stats: [
          { value: "抽雙卡", label: "動作＋夥伴" },
          { value: "自由回答", label: "Yes 或 No 都可以" },
          { value: "with", label: "一起做" },
        ],
        actions: [
          { label: "這那問答", href: "./this-that-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([gameRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderCanDoGame({
      challenge: canDoChallenge,
      state,
      onSelectPlayer: (playerIndex) => {
        if (state.selectedActionId || state.selectedPartnerId || state.isAnswered || state.finished) return;
        state.activePlayerIndex = playerIndex;
        renderGame();
      },
      onPickAction: (actionId) => {
        if (state.isAnswered || state.finished) return;
        state.selectedActionId = actionId;
        renderGame();
      },
      onPickPartner: (partnerId) => {
        if (state.isAnswered || state.finished) return;
        state.selectedPartnerId = partnerId;
        renderGame();
      },
      onChooseAnswer: (answer) => {
        chooseAnswer(answer);
        renderGame();
      },
      onNextRound: () => {
        nextRound();
        renderGame();
      },
      onResetGame: () => {
        Object.assign(state, createGameState());
        renderGame();
      },
    }),
  );
}

function createGameState() {
  const players = studentProfiles.slice(0, 4).map((student) => ({ id: student.id, name: student.name, score: 0 }));

  return {
    activePlayerIndex: 0,
    roundIndex: 0,
    actionOptions: drawOptions(canDoChallenge.actions, 4),
    partnerOptions: drawOptions(canDoChallenge.partners, 4),
    selectedActionId: "",
    selectedPartnerId: "",
    selectedAnswer: "",
    isAnswered: false,
    lastResult: null,
    finished: false,
    players,
  };
}

function chooseAnswer(answer) {
  if (!state.selectedActionId || !state.selectedPartnerId || state.isAnswered || state.finished) return;
  const score = answer === "sentence" ? 3 : 2;

  state.selectedAnswer = answer;
  state.isAnswered = true;
  state.players[state.activePlayerIndex].score += score;
  state.lastResult = { answer, score };
}

function nextRound() {
  if (!state.isAnswered || state.finished) return;

  if (state.roundIndex >= 15) {
    state.finished = true;
    return;
  }

  state.roundIndex += 1;
  state.activePlayerIndex = (state.activePlayerIndex + 1) % state.players.length;
  state.actionOptions = drawOptions(canDoChallenge.actions, 4);
  state.partnerOptions = drawOptions(canDoChallenge.partners, 4);
  state.selectedActionId = "";
  state.selectedPartnerId = "";
  state.selectedAnswer = "";
  state.isAnswered = false;
  state.lastResult = null;
}

function drawOptions(items, count) {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled.slice(0, count);
}

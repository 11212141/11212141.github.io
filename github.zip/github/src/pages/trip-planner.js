import { renderPageLead } from "../components/pageLead.js";
import { renderTripPlanner } from "../components/tripPlanner.js?v=20260509-trip2";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const API_URL = "./api/travel-items";

const state = {
  items: [],
  isLoading: true,
  isSaving: false,
  error: "",
};

render();
loadItems();

function render() {
  const { actionText, actionHref } = getDefaultAction("trip-planner");
  const summary = getTripSummary(state.items);

  renderPage({
    currentPageId: "trip-planner",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "trip-planner-top",
        eyebrow: "活動頁",
        title: "行程旅遊規劃",
        description: "",
        badge: "旅行活動",
        stats: [
          { value: `${summary.itemCount} 站`, label: "目前行程" },
          { value: `${summary.totalDuration} 分`, label: "總時間" },
          { value: `$${summary.totalBudget}`, label: "預估花費" },
        ],
        actions: [
          { label: "時間活動", href: "./time-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderTripPlanner({
          state,
          summary,
          onSubmit: createItem,
          onDelete: deleteItem,
          onRefresh: loadItems,
        }),
      ]),
    ],
  });
}

async function loadItems() {
  state.isLoading = true;
  state.error = "";
  render();

  try {
    const response = await fetch(API_URL);
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "讀取失敗");
    }
    state.items = payload.items;
  } catch (error) {
    state.error = "暫時讀不到行程，請稍後再試。";
  } finally {
    state.isLoading = false;
    render();
  }
}

async function createItem(item) {
  state.isSaving = true;
  state.error = "";
  render();

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(item),
    });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "新增失敗");
    }
    state.items = [...state.items, payload.item].sort(compareItems);
  } catch (error) {
    state.error = error.message || "新增失敗";
  } finally {
    state.isSaving = false;
    render();
  }
}

async function deleteItem(itemId) {
  state.error = "";
  render();

  try {
    const response = await fetch(`${API_URL}/${itemId}`, { method: "DELETE" });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "刪除失敗");
    }
    state.items = state.items.filter((item) => item.id !== itemId);
  } catch (error) {
    state.error = error.message || "刪除失敗";
  } finally {
    render();
  }
}

function compareItems(a, b) {
  return `${a.tripDay || "9999"} ${a.startTime || "99:99"} ${a.id}`.localeCompare(
    `${b.tripDay || "9999"} ${b.startTime || "99:99"} ${b.id}`,
  );
}

function getTripSummary(items) {
  const totalDuration = items.reduce((sum, item) => sum + Number(item.durationMinutes || 0), 0);
  const totalBudget = items.reduce((sum, item) => sum + Number(item.budget || 0), 0);
  const transportCounts = countBy(items.map((item) => item.transport).filter(Boolean));
  const categoryCounts = countBy(items.map((item) => item.category).filter(Boolean));
  const mainTransport = getTopKey(transportCounts);
  const categoryText = Object.entries(categoryCounts)
    .map(([category, count]) => `${category} ${count}`)
    .join(" · ");

  return {
    itemCount: items.length,
    totalDuration,
    totalBudget,
    mainTransport,
    categoryText,
  };
}

function countBy(values) {
  return values.reduce((counts, value) => {
    counts[value] = (counts[value] || 0) + 1;
    return counts;
  }, {});
}

function getTopKey(counts) {
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "";
}

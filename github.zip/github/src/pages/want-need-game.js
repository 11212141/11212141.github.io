import { renderPageLead } from "../components/pageLead.js";
import { renderWantNeedGame } from "../components/wantNeedGame.js?v=20260617-want-need-finance1";
import { studentProfiles } from "../data/siteData.js?v=20260617-want-need-finance1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const STATE_API_URL = "./api/want-need-state";

const challenge = {
  badge: "理財觀念",
  storyTitle: "願望補給隊",
  storyText: "四位隊員要用有限的零用錢完成一天任務。每次遇到物品或事件，都要判斷這是現在需要，還是只是想要。",
  cards: [
    {
      title: "下雨的早晨",
      story: "上學前突然下雨，書包裡沒有雨衣。隊伍要決定要不要先買雨衣。",
      item: "雨衣",
      chinese: "保護自己和書本",
      icon: "雨",
      answer: "need",
      reason: "雨衣可以讓身體和書本不被淋濕，屬於現在比較需要的支出。",
    },
    {
      title: "可愛貼紙",
      story: "文具店有一包很漂亮的貼紙，可是今天已經有足夠的文具可以上課。",
      item: "貼紙",
      chinese: "讓東西變漂亮",
      icon: "星",
      answer: "want",
      reason: "貼紙很有趣，但沒有它也能完成今天的學習，所以比較像想要。",
    },
    {
      title: "鉛筆斷掉了",
      story: "數學課快開始了，隊員的鉛筆斷掉，鉛筆盒裡沒有其他鉛筆。",
      item: "鉛筆",
      chinese: "完成課堂書寫",
      icon: "筆",
      answer: "need",
      reason: "沒有鉛筆會影響上課和作答，所以這是需要。",
    },
    {
      title: "新口味糖果",
      story: "同學說新口味糖果很好吃，但是隊伍等一下還要買午餐。",
      item: "糖果",
      chinese: "吃起來開心",
      icon: "糖",
      answer: "want",
      reason: "糖果可以帶來快樂，但午餐更重要，糖果比較像想要。",
    },
    {
      title: "午餐時間",
      story: "到了午餐時間，大家肚子餓，需要有力氣完成下午的任務。",
      item: "午餐",
      chinese: "補充體力",
      icon: "餐",
      answer: "need",
      reason: "午餐能補充體力，是照顧身體的必要支出。",
    },
    {
      title: "玩具小車",
      story: "商店門口有一台玩具小車，看起來很好玩，但隊伍已經有玩具。",
      item: "玩具小車",
      chinese: "休閒娛樂",
      icon: "車",
      answer: "want",
      reason: "玩具很好玩，但不是現在必須要買的東西。",
    },
    {
      title: "水壺空了",
      story: "天氣很熱，水壺已經空了，下一站還要走一段路。",
      item: "飲用水",
      chinese: "補充水分",
      icon: "水",
      answer: "need",
      reason: "喝水可以照顧身體，尤其天氣熱時是需要。",
    },
    {
      title: "漂亮吊飾",
      story: "書包上已經有吊飾了，但店裡出現新的可愛吊飾。",
      item: "新吊飾",
      chinese: "裝飾書包",
      icon: "飾",
      answer: "want",
      reason: "吊飾能讓書包更漂亮，但不是完成任務必須的。",
    },
    {
      title: "作業本用完",
      story: "國語作業本最後一頁用完了，老師明天會收新的作業。",
      item: "作業本",
      chinese: "完成作業",
      icon: "本",
      answer: "need",
      reason: "作業本會影響完成作業，所以是需要。",
    },
    {
      title: "限量卡片",
      story: "朋友說今天有限量卡片，錯過可能買不到，但隊伍還沒存到夢想基金。",
      item: "限量卡片",
      chinese: "收藏與開心",
      icon: "卡",
      answer: "want",
      reason: "限量會讓人想立刻買，但它仍然不是生活或學習必要品。",
    },
    {
      title: "鞋子破洞",
      story: "隊員的鞋底破洞，走路時會進水，也可能跌倒。",
      item: "修鞋或新鞋",
      chinese: "安全走路",
      icon: "鞋",
      answer: "need",
      reason: "鞋子和安全有關，會影響行動，是需要。",
    },
    {
      title: "飲料第二杯",
      story: "已經有水可以喝了，店員說第二杯飲料半價。",
      item: "第二杯飲料",
      chinese: "想再喝一杯",
      icon: "飲",
      answer: "want",
      reason: "半價不一定代表需要，已經有水時第二杯飲料比較像想要。",
    },
    {
      title: "眼鏡鬆了",
      story: "眼鏡螺絲鬆掉，看黑板會一直滑下來，今天還有很多課要上。",
      item: "修眼鏡",
      chinese: "看清楚上課內容",
      icon: "鏡",
      answer: "need",
      reason: "看清楚會影響學習與安全，修眼鏡屬於需要。",
    },
    {
      title: "遊戲抽抽樂",
      story: "便利商店有抽抽樂，可能抽到很棒的獎品，也可能只抽到普通小物。",
      item: "抽抽樂",
      chinese: "靠運氣得到獎品",
      icon: "抽",
      answer: "want",
      reason: "抽抽樂不一定得到想要的東西，屬於娛樂支出，比較像想要。",
    },
    {
      title: "感冒口罩",
      story: "隊員有點咳嗽，明天還要到學校上課，需要保護自己和同學。",
      item: "口罩",
      chinese: "保護健康",
      icon: "罩",
      answer: "need",
      reason: "健康和保護他人很重要，口罩在這個情境是需要。",
    },
    {
      title: "新造型髮夾",
      story: "家裡已經有可以使用的髮夾，但商店的新髮夾顏色很好看。",
      item: "新髮夾",
      chinese: "讓造型更好看",
      icon: "夾",
      answer: "want",
      reason: "已有可用髮夾時，新髮夾主要是讓自己更開心，屬於想要。",
    },
    {
      title: "搭車回家",
      story: "天色變暗了，回家的路有點遠，隊伍需要安全回到家。",
      item: "車票",
      chinese: "安全回家",
      icon: "票",
      answer: "need",
      reason: "交通和安全有關，車票在這個情境是需要。",
    },
    {
      title: "角色造型",
      story: "遊戲裡的新造型很帥，但不買也可以繼續玩遊戲。",
      item: "遊戲造型",
      chinese: "讓角色變好看",
      icon: "裝",
      answer: "want",
      reason: "遊戲造型不影響基本生活或學習，屬於想要。",
    },
    {
      title: "早餐沒吃",
      story: "早上出門太趕沒有吃早餐，現在肚子餓到上課很難專心。",
      item: "早餐",
      chinese: "補充能量",
      icon: "早",
      answer: "need",
      reason: "早餐能補充能量，幫助專心上課，屬於需要。",
    },
    {
      title: "同款筆袋",
      story: "朋友買了很流行的新筆袋，可是自己的筆袋還很完整。",
      item: "新筆袋",
      chinese: "跟朋友同款",
      icon: "袋",
      answer: "want",
      reason: "原本筆袋還能用時，新筆袋比較像想要，不是必要。",
    },
    {
      title: "牙刷壞了",
      story: "牙刷刷毛分岔，已經刷不乾淨，家裡也沒有備用牙刷。",
      item: "牙刷",
      chinese: "保持牙齒健康",
      icon: "牙",
      answer: "need",
      reason: "牙刷和健康有關，沒有可用牙刷時是需要。",
    },
    {
      title: "驚喜盲盒",
      story: "盲盒外盒很漂亮，但不知道裡面是哪一款，可能不是最喜歡的。",
      item: "盲盒",
      chinese: "未知驚喜",
      icon: "盒",
      answer: "want",
      reason: "盲盒是娛樂和驚喜，風險也比較高，屬於想要。",
    },
    {
      title: "雨鞋太小",
      story: "雨鞋已經太小，穿起來腳會痛，雨天走路也不舒服。",
      item: "合腳雨鞋",
      chinese: "保護腳和安全走路",
      icon: "靴",
      answer: "need",
      reason: "鞋子合不合腳會影響安全和健康，所以是需要。",
    },
    {
      title: "漂亮包裝紙",
      story: "要送卡片給同學，家裡已經有普通信封，但商店有更漂亮的包裝紙。",
      item: "漂亮包裝紙",
      chinese: "讓禮物更漂亮",
      icon: "紙",
      answer: "want",
      reason: "有普通信封可用時，漂亮包裝紙比較像想要。",
    },
    {
      title: "學校通知單",
      story: "老師提醒明天要帶資料夾整理通知單，不然容易弄丟重要資料。",
      item: "資料夾",
      chinese: "整理重要文件",
      icon: "夾",
      answer: "need",
      reason: "整理重要資料會影響學校生活，沒有可用資料夾時是需要。",
    },
    {
      title: "冰淇淋加料",
      story: "已經買了一球冰淇淋，店員問要不要多加巧克力脆片。",
      item: "加料",
      chinese: "吃起來更開心",
      icon: "脆",
      answer: "want",
      reason: "加料會更享受，但不是必要支出。",
    },
    {
      title: "運動水壺破了",
      story: "體育課常常需要喝水，原本水壺漏水，書包也會被弄濕。",
      item: "水壺",
      chinese: "裝水和保護書包",
      icon: "壺",
      answer: "need",
      reason: "水壺能補充水分，也避免書包弄濕，在這裡是需要。",
    },
    {
      title: "主題鉛筆組",
      story: "鉛筆盒裡已經有三支鉛筆，但架上有喜歡角色的鉛筆組。",
      item: "主題鉛筆組",
      chinese: "喜歡角色圖案",
      icon: "圖",
      answer: "want",
      reason: "已有足夠鉛筆時，主題鉛筆組比較像想要。",
    },
    {
      title: "護眼檯燈",
      story: "晚上寫作業時房間太暗，常常看不清楚字。",
      item: "檯燈",
      chinese: "保護眼睛",
      icon: "燈",
      answer: "need",
      reason: "光線不足會影響眼睛和學習，適合的檯燈是需要。",
    },
    {
      title: "特別版杯子",
      story: "家裡已經有杯子可以喝水，但商店的特別版杯子很好看。",
      item: "特別版杯子",
      chinese: "收藏和喜歡",
      icon: "杯",
      answer: "want",
      reason: "已有杯子可用時，特別版杯子比較像想要。",
    },
  ],
};

const gameRoot = document.createElement("div");
let state = createGameState();

renderShell();
renderGame();
loadSavedState();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("want-need-game");

  renderPage({
    currentPageId: "want-need-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "want-need-top",
        eyebrow: "活動遊戲頁",
        title: "想要需要",
        description: "",
        badge: "理財觀念",
        stats: [
          { value: `${challenge.cards.length} 張`, label: "情境卡" },
          { value: "點頭搖頭", label: "關鍵角色" },
          { value: "24 回合", label: "可長時間玩" },
        ],
        actions: [{ label: "回到活動總覽", href: "./index.html", variant: "button--primary" }],
      }),
      mountDashboard([gameRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderWantNeedGame({
      challenge,
      state,
      onSelectPlayer: (playerIndex) => {
        if (state.phase !== "draw") return;
        state.activePlayerIndex = playerIndex;
        renderGame();
        saveGameState();
      },
      onSelectGuardian: (playerIndex) => {
        state.guardianIndex = playerIndex;
        renderGame();
        saveGameState();
      },
      onDrawCard: drawCard,
      onChooseNeedType: chooseNeedType,
      onGuardianVote: guardianVote,
      onNextRound: nextRound,
      onResetGame: resetGame,
      onShowResetLock: () => {
        state.resetUnlocked = true;
        state.resetMessage = "";
        renderGame();
      },
      onCancelResetLock: () => {
        state.resetUnlocked = false;
        state.resetMessage = "";
        renderGame();
      },
      onSubmitResetPassword: (password) => {
        if (password !== "0000") {
          state.resetMessage = "密碼錯誤";
          renderGame();
          return;
        }

        resetGame();
      },
    }),
  );
}

async function loadSavedState() {
  state.saveStatus = "讀取進度中";
  renderGame();

  try {
    const response = await fetch(STATE_API_URL);
    if (!response.ok) {
      throw new Error("load failed");
    }

    const data = await response.json();
    if (data.state) {
      state = normalizeSavedState(data.state);
      state.saveStatus = "已載入上次進度";
    } else {
      state.saveStatus = "新遊戲";
    }
  } catch (error) {
    state.saveStatus = "資料庫未連線";
  }

  renderGame();
}

async function saveGameState() {
  try {
    const stateToSave = { ...state, isDrawing: false, resetUnlocked: false, resetMessage: "" };
    const response = await fetch(STATE_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ state: stateToSave }),
    });

    if (!response.ok) {
      throw new Error("save failed");
    }

    state.saveStatus = "進度已保存";
  } catch (error) {
    state.saveStatus = "進度保存失敗";
  }

  renderGame();
}

function resetGame() {
  state = createGameState();
  state.saveStatus = "已重新開始";
  renderGame();
  saveGameState();
}

function normalizeSavedState(savedState) {
  const fresh = createGameState();
  const savedPlayers = Array.isArray(savedState.players) ? savedState.players : [];

  return {
    ...fresh,
    ...savedState,
    players: fresh.players.map((player, index) => ({
      ...player,
      score: Number(savedPlayers[index]?.score ?? player.score) || 0,
    })),
    activePlayerIndex: clampIndex(savedState.activePlayerIndex, fresh.players.length),
    guardianIndex: clampIndex(savedState.guardianIndex, fresh.players.length),
    roundIndex: clampNumber(savedState.roundIndex, 0, fresh.maxRounds),
    currentCardIndex: clampNumber(savedState.currentCardIndex, 0, challenge.cards.length - 1),
    phase: ["draw", "choose", "guardian", "result"].includes(savedState.phase) ? savedState.phase : "draw",
    cardOrder: normalizeCardOrder(savedState.cardOrder, fresh.cardOrder),
    usedCardIndexes: normalizeUsedCards(savedState.usedCardIndexes),
    isDrawing: false,
    resetUnlocked: false,
    resetMessage: "",
    saveStatus: "已載入上次進度",
    choice: ["need", "want", ""].includes(savedState.choice) ? savedState.choice : "",
    guardianDecision: ["nod", "shake", ""].includes(savedState.guardianDecision) ? savedState.guardianDecision : "",
    lastResult: savedState.lastResult && typeof savedState.lastResult === "object" ? savedState.lastResult : null,
    stars: clampNumber(savedState.stars, 0, 999),
    coins: clampNumber(savedState.coins, 0, 999),
    supplies: clampNumber(savedState.supplies, 0, 999),
    hearts: clampNumber(savedState.hearts, 0, 999),
    finished: Boolean(savedState.finished),
  };
}

function clampIndex(value, length) {
  return clampNumber(value, 0, Math.max(0, length - 1));
}

function clampNumber(value, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return min;
  }

  return Math.min(max, Math.max(min, Math.round(parsed)));
}

function createGameState() {
  const players = studentProfiles.slice(0, 4).map((student) => ({
    id: student.id,
    name: student.name,
    score: 0,
  }));

  return {
    players,
    activePlayerIndex: 0,
    guardianIndex: 2,
    roundIndex: 0,
    maxRounds: 24,
    cardOrder: shuffleIndexes(challenge.cards.length),
    usedCardIndexes: [],
    currentCardIndex: 0,
    phase: "draw",
    isDrawing: false,
    choice: "",
    guardianDecision: "",
    lastResult: null,
    stars: 0,
    coins: 20,
    supplies: 0,
    hearts: 4,
    finished: false,
    resetUnlocked: false,
    resetMessage: "",
    saveStatus: "新遊戲",
  };
}

function drawCard() {
  if (state.phase !== "draw" || state.isDrawing) return;

  state.isDrawing = true;
  renderGame();

  window.setTimeout(() => {
    if (!state.cardOrder.length) {
      state.cardOrder = shuffleIndexes(challenge.cards.length, state.usedCardIndexes.at(-1));
      state.usedCardIndexes = [];
    }

    const orderSeed = state.cardOrder.shift() ?? 0;

    state.currentCardIndex = orderSeed;
    state.usedCardIndexes = [...state.usedCardIndexes, orderSeed].slice(-challenge.cards.length);
    state.phase = "choose";
    state.choice = "";
    state.guardianDecision = "";
    state.lastResult = null;
    state.isDrawing = false;
    renderGame();
    saveGameState();
  }, 700);
}

function chooseNeedType(choice) {
  if (state.phase !== "choose") return;
  state.choice = choice;
  state.phase = "guardian";
  renderGame();
  saveGameState();
}

function guardianVote(decision) {
  if (state.phase !== "guardian") return;

  const card = challenge.cards[state.currentCardIndex] ?? challenge.cards[0];
  const player = state.players[state.activePlayerIndex];
  const choiceIsCorrect = state.choice === card.answer;
  const guardianSupports = decision === "nod";
  const guardianIsWise = (choiceIsCorrect && guardianSupports) || (!choiceIsCorrect && !guardianSupports);

  state.guardianDecision = decision;
  state.phase = "result";

  if (guardianIsWise && choiceIsCorrect) {
    state.stars += 2;
    state.supplies += card.answer === "need" ? 2 : 1;
    state.coins += card.answer === "want" ? 1 : -2;
    state.hearts += 1;
    player.score += 3;
    state.lastResult = {
      success: true,
      title: "隊伍判斷成功",
      message: card.answer === "need" ? "這是需要，隊伍願意把錢用在重要的地方。" : "這是想要，隊伍知道可以先等一等。",
    };
  } else if (guardianIsWise && !choiceIsCorrect) {
    state.stars += 1;
    state.hearts += 1;
    player.score += 1;
    state.lastResult = {
      success: true,
      title: "守護者救回隊伍",
      message: "原本的判斷有點危險，但守護者用搖頭提醒大家重新想一想。",
    };
  } else {
    state.coins -= card.answer === "want" ? 3 : 1;
    state.hearts = Math.max(0, state.hearts - 1);
    state.lastResult = {
      success: false,
      title: "隊伍需要再討論",
      message: "這次判斷還可以更精準，先看看小提醒，下回合再試試。",
    };
  }

  state.coins = Math.max(0, state.coins);
  renderGame();
  saveGameState();
}

function nextRound() {
  if (state.phase !== "result") return;

  if (state.roundIndex + 1 >= state.maxRounds) {
    state.finished = true;
    renderGame();
    saveGameState();
    return;
  }

  state.roundIndex += 1;
  state.activePlayerIndex = (state.activePlayerIndex + 1) % state.players.length;
  state.phase = "draw";
  state.choice = "";
  state.guardianDecision = "";
  state.lastResult = null;
  renderGame();
  saveGameState();
}

function shuffleIndexes(length, avoidFirstIndex = null) {
  const indexes = Array.from({ length }, (_, index) => index);

  for (let index = indexes.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [indexes[index], indexes[swapIndex]] = [indexes[swapIndex], indexes[index]];
  }

  if (indexes.length > 1 && indexes[0] === avoidFirstIndex) {
    [indexes[0], indexes[1]] = [indexes[1], indexes[0]];
  }

  return indexes;
}

function normalizeCardOrder(savedOrder, fallbackOrder) {
  if (!Array.isArray(savedOrder)) {
    return fallbackOrder;
  }

  const validCards = savedOrder
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 0 && value < challenge.cards.length);

  return validCards.length ? [...new Set(validCards)] : fallbackOrder;
}

function normalizeUsedCards(savedUsedCards) {
  if (!Array.isArray(savedUsedCards)) {
    return [];
  }

  return savedUsedCards
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 0 && value < challenge.cards.length)
    .slice(-challenge.cards.length);
}

import { renderMoneyBuilderGame } from "../components/moneyBuilderGame.js?v=20260527-money-ui2";
import { renderPageLead } from "../components/pageLead.js";
import { moneyNumberChallenge } from "../data/siteData.js?v=20260527-money-ui2";
import {
  addMoneyValue,
  advanceMoneyRound,
  clearMoneyValues,
  createMoneyGameState,
  removeMoneyValue,
  submitMoneyRound,
  toggleMoneyTarget,
} from "../pageState.js?v=20260527-money-ui2";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  moneyGame: createMoneyGameState(),
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("money-game");

  renderPage({
    currentPageId: "money-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "money-top",
        eyebrow: "數學遊戲頁",
        title: "金錢拼數字一對四互動遊戲",
        description: "",
        badge: moneyNumberChallenge.badge,
        stats: [
          { value: `${moneyNumberChallenge.rounds.length} 題`, label: "題目數" },
          { value: `${state.moneyGame.players.length} 位`, label: "輪流學生" },
          { value: `${moneyNumberChallenge.denominations.length} 種`, label: "可用面額" },
        ],
        actions: [
          { label: "除法分東西", href: "./division-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderMoneyBuilderGame({
          challenge: moneyNumberChallenge,
          gameState: state.moneyGame,
          onSelectPlayer: (playerIndex) => {
            if (state.moneyGame.finished || state.moneyGame.solved) {
              return;
            }

            state.moneyGame.activePlayerIndex = playerIndex;
            render();
          },
          onAddValue: (value) => {
            addMoneyValue(state.moneyGame, value);
            render();
          },
          onRemoveValue: () => {
            removeMoneyValue(state.moneyGame);
            render();
          },
          onClearValues: () => {
            clearMoneyValues(state.moneyGame);
            render();
          },
          onSubmitRound: () => {
            submitMoneyRound(state.moneyGame);
            render();
          },
          onToggleTarget: () => {
            toggleMoneyTarget(state.moneyGame);
            render();
          },
          onNextRound: () => {
            advanceMoneyRound(state.moneyGame);
            render();
          },
          onResetGame: () => {
            state.moneyGame = createMoneyGameState();
            render();
          },
        }),
      ]),
    ],
  });
}

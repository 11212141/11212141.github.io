import { renderEnglishNumberGames } from "../components/englishNumberGame.js";
import { renderPageLead } from "../components/pageLead.js";
import { englishNumberChallenge } from "../data/siteData.js";
import {
  advanceEnglishNumberRound,
  chooseEnglishNumberAnswer,
  createEnglishNumberGameState,
} from "../pageState.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  listenGame: createEnglishNumberGameState(englishNumberChallenge.listenRounds),
  mathGame: createEnglishNumberGameState(englishNumberChallenge.mathRounds),
  listenAnswerMode: "number",
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("english-numbers");

  renderPage({
    currentPageId: "english-numbers",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "english-numbers-top",
        eyebrow: "英文遊戲頁",
        title: englishNumberChallenge.title,
        description: "",
        badge: englishNumberChallenge.badge,
        stats: [
          { value: "1-20", label: "數字範圍" },
          { value: "2 個", label: "遊戲" },
          { value: "加減乘除", label: "算式題" },
        ],
        actions: [
          { label: "聽母音遊戲", href: "./phonics-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderEnglishNumberGames({
          challenge: englishNumberChallenge,
          listenState: state.listenGame,
          mathState: state.mathGame,
          listenAnswerMode: state.listenAnswerMode,
          onToggleListenMode: () => {
            state.listenAnswerMode = state.listenAnswerMode === "number" ? "equation" : "number";
            render();
          },
          onSelectListenPlayer: (playerIndex) => {
            if (state.listenGame.finished || state.listenGame.isAnswered) {
              return;
            }

            state.listenGame.activePlayerIndex = playerIndex;
            render();
          },
          onSelectMathPlayer: (playerIndex) => {
            if (state.mathGame.finished || state.mathGame.isAnswered) {
              return;
            }

            state.mathGame.activePlayerIndex = playerIndex;
            render();
          },
          onChooseListenAnswer: (value) => {
            chooseEnglishNumberAnswer(state.listenGame, englishNumberChallenge.listenRounds, value);
            render();
          },
          onChooseMathAnswer: (value) => {
            chooseEnglishNumberAnswer(state.mathGame, englishNumberChallenge.mathRounds, value);
            render();
          },
          onNextListenRound: () => {
            advanceEnglishNumberRound(state.listenGame);
            render();
          },
          onNextMathRound: () => {
            advanceEnglishNumberRound(state.mathGame);
            render();
          },
          onResetListenGame: () => {
            state.listenGame = createEnglishNumberGameState(englishNumberChallenge.listenRounds);
            render();
          },
          onResetMathGame: () => {
            state.mathGame = createEnglishNumberGameState(englishNumberChallenge.mathRounds);
            render();
          },
        }),
      ]),
    ],
  });
}

import { renderAngleAdjustGame } from "../components/angleAdjustGame.js";
import { renderPageLead } from "../components/pageLead.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  angle: 60,
  showRightAngle: true,
  showAngleHint: true,
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("angle-game");

  renderPage({
    currentPageId: "angle-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "angle-top",
        eyebrow: "數學遊戲頁",
        title: "角度調整活動",
        description: "",
        badge: "數學遊戲",
        stats: [
          { value: "0°-180°", label: "自由調整" },
          { value: "90°", label: "直角比較" },
          { value: "銳角 / 鈍角", label: "即時判斷" },
        ],
        actions: [
          { label: "時間活動", href: "./time-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderAngleAdjustGame({
          angle: state.angle,
          showRightAngle: state.showRightAngle,
          showAngleHint: state.showAngleHint,
          onSetAngle: (angle) => {
            state.angle = clampAngle(angle);
          },
          onToggleRightAngle: () => {
            state.showRightAngle = !state.showRightAngle;
            render();
          },
          onNudgeAngle: (amount) => {
            state.angle = clampAngle(state.angle + amount);
            render();
          },
          onSetPreset: (angle) => {
            state.angle = clampAngle(angle);
            render();
          },
          onToggleAngleHint: () => {
            state.showAngleHint = !state.showAngleHint;
            render();
          },
        }),
      ]),
    ],
  });
}

function clampAngle(angle) {
  return Math.min(180, Math.max(0, Math.round(Number(angle) || 0)));
}

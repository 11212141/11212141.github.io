import { renderDivisionShareGame } from "../components/divisionShareGame.js";
import { renderMathConceptGame } from "../components/mathConceptGame.js?v=20260509-split1";
import { renderPageLead } from "../components/pageLead.js";
import { divisionShareChallenge, mathConceptChallenge } from "../data/siteData.js?v=20260509-split1";
import {
  advanceDivisionRound,
  createDivisionGameState,
  placeDivisionItem,
  resetDivisionRound,
  setDivisionPrediction,
  shareDivisionCycle,
  submitDivisionRound,
  undoDivisionMove,
} from "../pageState.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const divisionConceptChallenge = {
  title: "乘除關係與餘數",
  badge: "數學遊戲",
  modes: mathConceptChallenge.modes.filter((mode) => ["relation", "remainder"].includes(mode.id)),
};

const state = {
  pageMode: "share",
  divisionGame: createDivisionGameState(),
  conceptGame: {
    mode: divisionConceptChallenge.modes[0].id,
    roundIndexes: Object.fromEntries(divisionConceptChallenge.modes.map((mode) => [mode.id, 0])),
    selectedAnswers: Object.fromEntries(divisionConceptChallenge.modes.map((mode) => [mode.id, ""])),
    results: Object.fromEntries(divisionConceptChallenge.modes.map((mode) => [mode.id, null])),
  },
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("division-game");

  renderPage({
    currentPageId: "division-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "division-top",
        eyebrow: "數學遊戲頁",
        title: "平均分東西",
        description: "",
        badge: divisionShareChallenge.badge,
        stats: [
          { value: `${divisionShareChallenge.rounds.length} 題`, label: "題目數" },
          { value: "30 題", label: "乘除關係" },
          { value: "30 題", label: "餘數除法" },
        ],
        actions: [
          { label: "金錢拼數字", href: "./money-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderDivisionModeTabs(),
        state.pageMode === "share" ? renderShareGame() : renderConceptGame(),
      ]),
    ],
  });
}

function renderDivisionModeTabs() {
  const wrapper = document.createElement("div");
  wrapper.className = "decimal-mode-switch";

  [
    { id: "share", label: "平均分東西" },
    { id: "concept", label: "乘除關係與餘數" },
  ].forEach((mode) => {
    const button = document.createElement("button");
    button.className = `button ${state.pageMode === mode.id ? "button--primary" : "button--secondary"}`;
    button.type = "button";
    button.textContent = mode.label;
    button.addEventListener("click", () => {
      state.pageMode = mode.id;
      render();
    });
    wrapper.append(button);
  });

  return wrapper;
}

function renderShareGame() {
  return renderDivisionShareGame({
    challenge: divisionShareChallenge,
    gameState: state.divisionGame,
    onSelectPlayer: (playerIndex) => {
      if (state.divisionGame.finished || state.divisionGame.solved) {
        return;
      }

      state.divisionGame.activePlayerIndex = playerIndex;
      render();
    },
    onSetPrediction: (value) => {
      setDivisionPrediction(state.divisionGame, value);
      render();
    },
    onPlaceItem: (basketIndex) => {
      placeDivisionItem(state.divisionGame, basketIndex);
      render();
    },
    onShareCycle: () => {
      shareDivisionCycle(state.divisionGame);
      render();
    },
    onUndoMove: () => {
      undoDivisionMove(state.divisionGame);
      render();
    },
    onResetRound: () => {
      resetDivisionRound(state.divisionGame);
      render();
    },
    onSubmitRound: () => {
      submitDivisionRound(state.divisionGame);
      render();
    },
    onNextRound: () => {
      advanceDivisionRound(state.divisionGame);
      render();
    },
    onResetGame: () => {
      state.divisionGame = createDivisionGameState();
      render();
    },
  });
}

function renderConceptGame() {
  return renderMathConceptGame({
    challenge: divisionConceptChallenge,
    state: state.conceptGame,
    onSetMode: (mode) => {
      state.conceptGame.mode = mode;
      render();
    },
    onChooseAnswer: (answer) => {
      chooseConceptAnswer(answer);
      render();
    },
    onNextRound: () => {
      advanceConceptRound();
      render();
    },
  });
}

function chooseConceptAnswer(answer) {
  const mode = getActiveConceptMode();
  const round = mode.rounds[state.conceptGame.roundIndexes[mode.id]];

  state.conceptGame.selectedAnswers[mode.id] = answer;
  state.conceptGame.results[mode.id] = {
    isCorrect: answer === round.answer,
  };
}

function advanceConceptRound() {
  const mode = getActiveConceptMode();

  state.conceptGame.roundIndexes[mode.id] =
    (state.conceptGame.roundIndexes[mode.id] + 1) % mode.rounds.length;
  state.conceptGame.selectedAnswers[mode.id] = "";
  state.conceptGame.results[mode.id] = null;
}

function getActiveConceptMode() {
  return (
    divisionConceptChallenge.modes.find((mode) => mode.id === state.conceptGame.mode) ??
    divisionConceptChallenge.modes[0]
  );
}

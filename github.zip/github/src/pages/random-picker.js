import { renderPageLead } from "../components/pageLead.js?v=20260603-random-picker-cardlight2";
import { renderRandomPickerGame } from "../components/randomPickerGame.js?v=20260603-random-picker-cardlight2";
import { studentProfiles } from "../data/siteData.js?v=20260603-random-picker1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const WEIGHTS_STORAGE_KEY = "ai-digital-random-picker-weights";

const students = studentProfiles.map((student) => ({
  id: student.id,
  name: student.name,
}));

let finishTimer = null;

const state = {
  mode: "wheel",
  isPicking: false,
  highlightedId: "",
  selectedId: "",
  selectedName: "",
  wheelStartRotation: 0,
  wheelRotation: 0,
  animationId: 0,
  showSettings: false,
  weights: loadSavedWeights(),
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("random-picker");

  renderPage({
    currentPageId: "random-picker",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "random-picker-top",
        eyebrow: "活動遊戲頁",
        title: "隨機挑人",
        description: "",
        badge: "活動遊戲",
        stats: [
          { value: "4 位", label: "固定學生" },
          { value: "4 種", label: "抽選玩法" },
          { value: "可調整", label: "隱藏機率" },
        ],
        actions: [
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderRandomPickerGame({
          students,
          state,
          onSetMode: (mode) => {
            if (state.isPicking) return;
            state.mode = mode;
            state.highlightedId = "";
            state.selectedId = "";
            state.selectedName = "";
            render();
          },
          onStartPick: startPick,
          onToggleSettings: () => {
            state.showSettings = !state.showSettings;
            render();
          },
          onSetWeight: (studentId, weight) => {
            state.weights[studentId] = Math.max(0, Number(weight) || 0);
            saveWeights();
            render();
          },
          onResetWeights: () => {
            students.forEach((student) => {
              state.weights[student.id] = 1;
            });
            saveWeights();
            render();
          },
        }),
      ]),
    ],
  });
}

function startPick() {
  if (state.isPicking) {
    return;
  }

  const winner = pickWeightedStudent();
  clearPickTimer();

  state.isPicking = true;
  state.selectedId = "";
  state.selectedName = "";
  state.highlightedId = winner.id;
  state.animationId += 1;
  state.wheelStartRotation = state.wheelRotation;
  state.wheelRotation += getWheelRotationForWinner(winner.id, state.wheelRotation);
  render();

  finishTimer = window.setTimeout(() => {
    clearPickTimer();
    state.isPicking = false;
    state.highlightedId = winner.id;
    state.selectedId = winner.id;
    state.selectedName = winner.name;
    render();
  }, 1900);
}

function clearPickTimer() {
  if (finishTimer) {
    window.clearTimeout(finishTimer);
    finishTimer = null;
  }
}

function pickWeightedStudent() {
  const weightedStudents = students
    .map((student) => ({ ...student, weight: Math.max(0, Number(state.weights[student.id]) || 0) }))
    .filter((student) => student.weight > 0);
  const pool = weightedStudents.length ? weightedStudents : students.map((student) => ({ ...student, weight: 1 }));
  const total = pool.reduce((sum, student) => sum + student.weight, 0);
  let target = Math.random() * total;

  for (const student of pool) {
    target -= student.weight;
    if (target <= 0) {
      return student;
    }
  }

  return pool[pool.length - 1];
}

function getWheelRotationForWinner(winnerId, currentRotation) {
  const winnerIndex = Math.max(0, students.findIndex((student) => student.id === winnerId));
  const targetAngles = [45, 135, 225, 315];
  const pointerAngle = 0;
  const targetAngle = targetAngles[winnerIndex] ?? 45;
  const correction = pointerAngle - targetAngle;
  const currentModulo = ((currentRotation % 360) + 360) % 360;
  const targetModulo = ((correction % 360) + 360) % 360;
  const alignDelta = (targetModulo - currentModulo + 360) % 360;
  const extraTurns = 1440 + Math.floor(Math.random() * 2) * 360;
  return extraTurns + alignDelta;
}

function getDefaultWeights() {
  return students.reduce((weights, student) => {
    weights[student.id] = 1;
    return weights;
  }, {});
}

function loadSavedWeights() {
  const defaults = getDefaultWeights();

  try {
    const savedWeights = JSON.parse(localStorage.getItem(WEIGHTS_STORAGE_KEY) || "{}");
    students.forEach((student) => {
      const savedValue = Number(savedWeights[student.id]);
      defaults[student.id] = Number.isFinite(savedValue) ? Math.min(10, Math.max(0, savedValue)) : defaults[student.id];
    });
  } catch (error) {
    return defaults;
  }

  return defaults;
}

function saveWeights() {
  localStorage.setItem(WEIGHTS_STORAGE_KEY, JSON.stringify(state.weights));
}

import { renderGratitudeCards } from "../components/gratitudeCards.js?v=20260512-card1";
import { renderPageLead } from "../components/pageLead.js";
import { studentProfiles } from "../data/siteData.js?v=20260512-card1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const API_URL = "./api/gratitude-cards";
const students = studentProfiles.slice(0, 4);

const state = {
  activeStudentIndex: 0,
  cards: [],
  drafts: Object.fromEntries(students.map((student) => [student.id, createDraft(student)])),
  isLoading: true,
  isSaving: false,
  error: "",
};

render();
loadCards();

function render() {
  const { actionText, actionHref } = getDefaultAction("gratitude-cards");

  renderPage({
    currentPageId: "gratitude-cards",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "gratitude-cards-top",
        eyebrow: "活動頁",
        title: "感謝卡片活動",
        description: "",
        badge: "四人卡片牆",
        stats: [
          { value: "4 位", label: "學生" },
          { value: `${state.cards.length} 張`, label: "已保存" },
          { value: "Thank you", label: "主題" },
        ],
        actions: [
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderGratitudeCards({
          state,
          students,
          onSelectStudent: (index) => {
            state.activeStudentIndex = index;
            render();
          },
          onUpdateDraft: (key, value) => {
            const student = students[state.activeStudentIndex];
            state.drafts[student.id] = { ...state.drafts[student.id], [key]: value };
          },
          onSubmit: saveCard,
          onDelete: deleteCard,
          onRefresh: loadCards,
        }),
      ]),
    ],
  });
}

async function loadCards() {
  state.isLoading = true;
  state.error = "";
  render();

  try {
    const response = await fetch(API_URL);
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "讀取失敗");
    }
    state.cards = payload.cards;
  } catch (error) {
    state.error = "暫時讀不到卡片，請稍後再試。";
  } finally {
    state.isLoading = false;
    render();
  }
}

async function saveCard() {
  const student = students[state.activeStudentIndex];
  const draft = state.drafts[student.id];
  state.isSaving = true;
  state.error = "";
  render();

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        studentId: student.id,
        studentName: student.name,
        ...draft,
        signature: draft.signature || student.name,
      }),
    });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "保存失敗");
    }
    state.cards = [payload.card, ...state.cards];
    state.drafts[student.id] = createDraft(student);
  } catch (error) {
    state.error = error.message || "保存失敗";
  } finally {
    state.isSaving = false;
    render();
  }
}

async function deleteCard(cardId) {
  state.error = "";
  render();

  try {
    const response = await fetch(`${API_URL}/${cardId}`, { method: "DELETE" });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "刪除失敗");
    }
    state.cards = state.cards.filter((card) => card.id !== cardId);
  } catch (error) {
    state.error = error.message || "刪除失敗";
  } finally {
    render();
  }
}

function createDraft(student) {
  return {
    recipient: "",
    reason: "",
    message: "",
    signature: student.name,
    theme: "aqua",
  };
}

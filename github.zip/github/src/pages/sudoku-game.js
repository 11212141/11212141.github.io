import { renderPageLead } from "../components/pageLead.js";
import { renderSudokuGame } from "../components/sudokuGame.js?v=20260617-sudoku2";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const difficultyKeepRatio = {
  easy: 0.62,
  medium: 0.48,
  hard: 0.36,
};

let state = createSudokuState(4, "easy");
const gameRoot = document.createElement("div");

renderShell();
renderGame();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("sudoku-game");

  renderPage({
    currentPageId: "sudoku-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "sudoku-top",
        eyebrow: "數學遊戲頁",
        title: "數獨挑戰",
        description: "",
        badge: "數學活動",
        stats: [
          { value: "4/6/9", label: "可調格數" },
          { value: "拖動", label: "數字卡操作" },
          { value: "3 種", label: "難度" },
        ],
        actions: [{ label: "回到活動總覽", href: "./index.html", variant: "button--primary" }],
      }),
      mountDashboard([gameRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderSudokuGame({
      state,
      onSetSize: (size) => {
        state = createSudokuState(size, state.difficulty);
        renderGame();
      },
      onSetDifficulty: (difficulty) => {
        state = createSudokuState(state.size, difficulty);
        renderGame();
      },
      onNewPuzzle: () => {
        state = createSudokuState(state.size, state.difficulty);
        renderGame();
      },
      onSelectNumber: (value) => {
        state.selectedNumber = value;
        renderGame();
      },
      onPlaceNumber: (row, col, value) => {
        placeNumber(row, col, value);
      },
      onClearCell: (row, col) => {
        clearCell(row, col);
      },
      onCheckAnswer: () => {
        checkAnswer();
        renderGame();
      },
      onRevealAnswer: () => {
        state.grid = cloneGrid(state.solution);
        state.conflicts = [];
        state.message = "答案已顯示。";
        renderGame();
      },
    }),
  );
}

function createSudokuState(size, difficulty) {
  const solution = createSolution(size);
  const { puzzle, fixed } = createPuzzle(solution, difficulty);

  return {
    size,
    difficulty,
    solution,
    grid: puzzle,
    fixed,
    selectedNumber: 0,
    conflicts: [],
    message: "把數字卡拖進空格。",
  };
}

function createSolution(size) {
  const box = getBoxShape(size);
  const base = Array.from({ length: size }, (_, index) => index + 1);
  const rowOrder = shuffleGroupedIndexes(size, box.height);
  const colOrder = shuffleGroupedIndexes(size, box.width);
  const numbers = shuffleArray(base);

  return rowOrder.map((row) =>
    colOrder.map((col) => {
      const valueIndex = (box.width * (row % box.height) + Math.floor(row / box.height) + col) % size;
      return numbers[valueIndex];
    }),
  );
}

function createPuzzle(solution, difficulty) {
  const size = solution.length;
  const total = size * size;
  const keepCount = Math.max(size, Math.round(total * (difficultyKeepRatio[difficulty] ?? difficultyKeepRatio.easy)));
  const keepIndexes = new Set(shuffleArray(Array.from({ length: total }, (_, index) => index)).slice(0, keepCount));
  const puzzle = cloneGrid(solution);
  const fixed = solution.map((row) => row.map(() => false));

  for (let index = 0; index < total; index += 1) {
    const row = Math.floor(index / size);
    const col = index % size;
    if (keepIndexes.has(index)) {
      fixed[row][col] = true;
    } else {
      puzzle[row][col] = 0;
    }
  }

  return { puzzle, fixed };
}

function placeNumber(row, col, value) {
  if (state.fixed[row]?.[col]) return;
  if (value < 1 || value > state.size) return;

  state.grid[row][col] = value;
  state.conflicts = findConflicts(state.grid, state.solution, false);
  const emptyCount = state.grid.flat().filter((cell) => !cell).length;
  state.message = emptyCount ? `已放入 ${value}，還有 ${emptyCount} 格。` : "都填完了，可以按檢查。";
  renderGame();
}

function clearCell(row, col) {
  if (state.fixed[row]?.[col]) return;

  state.grid[row][col] = 0;
  state.conflicts = findConflicts(state.grid, state.solution, false);
  state.message = "已清除這一格。";
  renderGame();
}

function checkAnswer() {
  const conflicts = findConflicts(state.grid, state.solution, true);
  state.conflicts = conflicts;

  if (conflicts.length) {
    state.message = `有 ${conflicts.length} 格需要再想想。`;
    return;
  }

  if (state.grid.flat().some((value) => !value)) {
    state.message = "目前沒有錯，還有空格要完成。";
    return;
  }

  state.message = "完成了，這盤數獨成功！";
}

function findConflicts(grid, solution, includeEmpty) {
  const conflicts = [];

  for (let row = 0; row < grid.length; row += 1) {
    for (let col = 0; col < grid.length; col += 1) {
      const value = grid[row][col];
      if (!value && !includeEmpty) continue;
      if (value !== solution[row][col]) {
        conflicts.push({ row, col });
      }
    }
  }

  return conflicts;
}

function shuffleGroupedIndexes(size, groupSize) {
  const groups = [];
  for (let start = 0; start < size; start += groupSize) {
    groups.push(shuffleArray(Array.from({ length: groupSize }, (_, index) => start + index)));
  }

  return shuffleArray(groups).flat();
}

function getBoxShape(size) {
  if (size === 6) return { width: 3, height: 2 };
  if (size === 4) return { width: 2, height: 2 };
  return { width: 3, height: 3 };
}

function shuffleArray(items) {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
  }
  return copy;
}

function cloneGrid(grid) {
  return grid.map((row) => [...row]);
}

import { renderColorEnglishMatchGame } from "../components/colorEnglishMatchGame.js?v=20260424-color-mix9";
import { renderColorListenGame } from "../components/colorListenGame.js?v=20260424-color-mix9";
import { renderColorMixLab } from "../components/colorMixLab.js?v=20260424-color-mix9";
import { renderPageLead } from "../components/pageLead.js?v=20260424-color-mix9";
import { colorLearningChallenge, colorMixLabChallenge } from "../data/siteData.js?v=20260424-color-mix9";
import {
  buildEnglishOptions,
  chooseEnglishColor,
  chooseListenColor,
  createColorEnglishGameState,
  createColorListenGameState,
  getColorRoundTarget,
  nextColorEnglishRound,
  nextColorListenRound,
  revealListenColor,
} from "../utils/colorLearningGameState.js?v=20260424-color-mix9";
import {
  chooseColorMixPrimary as chooseMixPrimary,
  createColorMixGameState as createMixState,
  getMixedColor as getMixColor,
  nextColorMixRound as nextMixRound,
  selectColorMixRole as selectMixRole,
  submitColorMixAnswer as submitMixAnswer,
} from "../utils/colorMixGameState.js?v=20260424-color-mix9";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  colorListenGame: createColorListenGameState(),
  colorEnglishGame: createColorEnglishGameState(),
  colorMixGame: createMixState(),
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("color-mix");
  const mixedColor = getMixColor(state.colorMixGame);
  const englishTarget = getColorRoundTarget(state.colorEnglishGame);
  const englishOptions = buildEnglishOptions(state.colorEnglishGame);

  renderPage({
    currentPageId: "color-mix",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "color-mix-top",
        eyebrow: "英文遊戲頁",
        title: "顏色小遊戲",
        description: "",
        badge: colorMixLabChallenge.badge,
        stats: [
          { value: `${state.colorMixGame.players.length} 位`, label: "輪流學生" },
          { value: `${colorLearningChallenge.palette.length} 色`, label: "認識顏色" },
          { value: "3 種", label: "顏色玩法" },
        ],
        actions: [
          { label: "聽母音遊戲", href: "./phonics-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderColorListenGame({
          challenge: colorLearningChallenge,
          gameState: state.colorListenGame,
          onChooseColor: (colorId) => {
            chooseListenColor(state.colorListenGame, colorId);
            render();
          },
          onRevealColor: (colorId) => {
            revealListenColor(state.colorListenGame, colorId);
            render();
          },
          onNextRound: () => {
            nextColorListenRound(state.colorListenGame);
            render();
          },
          onResetGame: () => {
            state.colorListenGame = createColorListenGameState();
            render();
          },
        }),
        renderColorEnglishMatchGame({
          challenge: colorLearningChallenge,
          gameState: state.colorEnglishGame,
          targetColor: englishTarget,
          options: englishOptions,
          onChooseEnglish: (colorId) => {
            chooseEnglishColor(state.colorEnglishGame, colorId);
            render();
          },
          onNextRound: () => {
            nextColorEnglishRound(state.colorEnglishGame);
            render();
          },
          onResetGame: () => {
            state.colorEnglishGame = createColorEnglishGameState();
            render();
          },
        }),
        renderColorMixLab({
          challenge: colorMixLabChallenge,
          gameState: state.colorMixGame,
          mixedColor,
          onSelectRole: (role, playerIndex) => {
            selectMixRole(state.colorMixGame, role, playerIndex);
            render();
          },
          onChoosePrimary: (role, colorId) => {
            chooseMixPrimary(state.colorMixGame, role, colorId);
            render();
          },
          onSubmitAnswer: (answerId) => {
            submitMixAnswer(state.colorMixGame, answerId);
            render();
          },
          onNextRound: () => {
            nextMixRound(state.colorMixGame);
            render();
          },
          onResetGame: () => {
            state.colorMixGame = createMixState();
            render();
          },
        }),
      ]),
    ],
  });
}

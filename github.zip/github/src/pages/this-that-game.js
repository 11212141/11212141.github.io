import { renderPageLead } from "../components/pageLead.js";
import { renderThisThatGame } from "../components/thisThatGame.js?v=20260618-cardplay1";
import { studentProfiles, thisThatChallenge } from "../data/siteData.js?v=20260616-board1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = createGameState();
const gameRoot = document.createElement("div");

renderShell();
renderGame();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("this-that-game");

  renderPage({
    currentPageId: "this-that-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "this-that-top",
        eyebrow: "英文卡牌頁",
        title: thisThatChallenge.title,
        description: "",
        badge: thisThatChallenge.badge,
        stats: [
          { value: "翻卡搜查", label: "找 this / that" },
          { value: "Yes / No", label: "判斷任務" },
          { value: "完整句", label: "口說得分" },
        ],
        actions: [
          { label: "可不可以", href: "./can-do-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([gameRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderThisThatGame({
      challenge: thisThatChallenge,
      state,
      onSelectPlayer: (playerIndex) => {
        if (state.selectedCardIndex !== null || state.isAnswered || state.finished) return;
        state.activePlayerIndex = playerIndex;
        renderGame();
      },
      onPickCard: (cardIndex) => {
        if (state.selectedCardIndex !== null || state.finished) return;
        state.selectedCardIndex = cardIndex;
        state.currentRoundIndex = state.cardOptions[cardIndex] ?? state.cardOptions[0];
        renderGame();
      },
      onChooseAnswer: (answer) => {
        chooseAnswer(answer);
        renderGame();
      },
      onNextRound: () => {
        nextRound();
        renderGame();
      },
      onResetGame: () => {
        Object.assign(state, createGameState());
        renderGame();
      },
    }),
  );
}

function createGameState() {
  const players = studentProfiles.slice(0, 4).map((student) => ({ id: student.id, name: student.name, score: 0 }));
  const roundOrder = shuffleIndexes(thisThatChallenge.rounds.length);

  return {
    activePlayerIndex: 0,
    roundIndex: 0,
    roundOrder,
    cardOptions: createCardOptions(roundOrder[0]),
    selectedCardIndex: null,
    currentRoundIndex: null,
    selectedAnswer: "",
    isAnswered: false,
    lastResult: null,
    correctStreak: 0,
    finished: false,
    players,
  };
}

function chooseAnswer(answer) {
  if (state.selectedCardIndex === null || state.isAnswered || state.finished) return;
  const round = getCurrentRound();
  const correctAnswer = round.item === round.guess ? "yes" : "no";
  const isCorrect = answer === correctAnswer;
  const streak = isCorrect ? state.correctStreak + 1 : 0;
  const streakBonus = streak > 0 && streak % 3 === 0 ? 1 : 0;

  state.selectedAnswer = answer;
  state.isAnswered = true;
  state.lastResult = { isCorrect, answer: correctAnswer, streakBonus };
  state.correctStreak = streak;

  state.players[state.activePlayerIndex].score += isCorrect ? 2 + streakBonus : 1;
}

function nextRound() {
  if (!state.isAnswered || state.finished) return;

  if (state.roundIndex >= 15) {
    state.finished = true;
    return;
  }

  state.roundIndex += 1;
  state.activePlayerIndex = (state.activePlayerIndex + 1) % state.players.length;
  const answerIndex = state.roundOrder[state.roundIndex % state.roundOrder.length] ?? 0;
  state.cardOptions = createCardOptions(answerIndex);
  state.selectedCardIndex = null;
  state.currentRoundIndex = null;
  state.selectedAnswer = "";
  state.isAnswered = false;
  state.lastResult = null;
}

function getCurrentRound() {
  return thisThatChallenge.rounds[state.currentRoundIndex] ?? thisThatChallenge.rounds[0];
}

function createCardOptions(answerIndex) {
  const options = [answerIndex];
  const pool = shuffleIndexes(thisThatChallenge.rounds.length).filter((index) => index !== answerIndex);
  while (options.length < 4 && pool.length) {
    options.push(pool.shift());
  }
  return shuffleValues(options);
}

function shuffleIndexes(length) {
  const indexes = Array.from({ length }, (_, index) => index);
  return shuffleValues(indexes);
}

function shuffleValues(values) {
  const output = [...values];
  for (let index = output.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [output[index], output[swapIndex]] = [output[swapIndex], output[index]];
  }
  return output;
}

import { renderPageLead } from "../components/pageLead.js";
import { renderTimeLearningGame } from "../components/timeLearningGame.js?v=20260526-time-hands6";
import { timeLearningChallenge } from "../data/siteData.js?v=20260509-time1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  mode: "clock",
  clockRoundIndex: 0,
  clockTime: createClockTime(timeLearningChallenge.clockRounds[0]),
  clockAnswer: createSlots(6),
  clockActiveSlot: 0,
  clockAnswered: false,
  clockResult: null,
  clockHands: {
    hour: true,
    minute: true,
    second: true,
  },
  conversionRoundIndex: 0,
  conversionSelected: "",
  conversionResult: null,
  calcRoundIndex: 0,
  calcAnswer: createSlots(getAnswerSize(timeLearningChallenge.columns)),
  calcActiveSlot: 0,
  calcAnswered: false,
  calcResult: null,
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("time-game");

  renderPage({
    currentPageId: "time-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "time-top",
        eyebrow: "數學遊戲頁",
        title: timeLearningChallenge.title,
        description: "",
        badge: timeLearningChallenge.badge,
        stats: [
          { value: "30 題", label: "看時鐘" },
          { value: "30 題", label: "時間換算" },
          { value: "30 題", label: "時間直式" },
        ],
        actions: [
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderTimeLearningGame({
          challenge: timeLearningChallenge,
          state,
          onSetMode: (mode) => {
            state.mode = mode;
            render();
          },
          onChooseClockDigit: (digit) => {
            chooseDigit(state.clockAnswer, "clockActiveSlot", "clockAnswered", digit);
            render();
          },
          onSelectClockSlot: (slot) => {
            state.clockActiveSlot = slot;
            render();
          },
          onClearClock: () => {
            resetClockAnswer();
            render();
          },
          onSubmitClock: () => {
            submitClockAnswer();
            render();
          },
          onNextClock: () => {
            state.clockRoundIndex = (state.clockRoundIndex + 1) % timeLearningChallenge.clockRounds.length;
            state.clockTime = createClockTime(timeLearningChallenge.clockRounds[state.clockRoundIndex]);
            resetClockAnswer();
            render();
          },
          onAdjustClock: (unit, amount) => {
            adjustClock(unit, amount);
            resetClockAnswer();
            render();
          },
          onResetClockHands: () => {
            state.clockTime = createClockTime(timeLearningChallenge.clockRounds[state.clockRoundIndex]);
            resetClockAnswer();
            render();
          },
          onToggleClockHand: (hand) => {
            const nextHands = { ...state.clockHands, [hand]: !state.clockHands[hand] };
            state.clockHands = nextHands;
            resetClockAnswer();
            render();
          },
          onSetClockTime: (time) => {
            state.clockTime = createClockTime(time);
            resetClockAnswer();
          },
          onChooseConversion: (answer) => {
            const round = timeLearningChallenge.conversionRounds[state.conversionRoundIndex];
            state.conversionSelected = answer;
            state.conversionResult = { isCorrect: answer === round.answer };
            render();
          },
          onNextConversion: () => {
            state.conversionRoundIndex = (state.conversionRoundIndex + 1) % timeLearningChallenge.conversionRounds.length;
            state.conversionSelected = "";
            state.conversionResult = null;
            render();
          },
          onChooseCalcDigit: (digit) => {
            chooseDigit(state.calcAnswer, "calcActiveSlot", "calcAnswered", digit);
            render();
          },
          onSelectCalcSlot: (slot) => {
            state.calcActiveSlot = slot;
            render();
          },
          onClearCalc: () => {
            resetCalcAnswer();
            render();
          },
          onSubmitCalc: () => {
            submitCalcAnswer();
            render();
          },
          onNextCalc: () => {
            state.calcRoundIndex = (state.calcRoundIndex + 1) % timeLearningChallenge.calculationRounds.length;
            resetCalcAnswer();
            render();
          },
        }),
      ]),
    ],
  });
}

function chooseDigit(answer, activeSlotKey, answeredKey, digit) {
  if (state[answeredKey]) {
    return;
  }

  answer[state[activeSlotKey]] = String(digit);
  state[activeSlotKey] = Math.min(state[activeSlotKey] + 1, answer.length - 1);
}

function submitClockAnswer() {
  if (state.clockAnswer.some((digit) => digit === "")) {
    return;
  }

  state.clockAnswered = true;
  state.clockResult = { isCorrect: state.clockAnswer.join("") === getClockAnswerDigits(state.clockTime, state.clockHands).join("") };
}

function submitCalcAnswer() {
  if (state.calcAnswer.some((digit) => digit === "")) {
    return;
  }

  const round = timeLearningChallenge.calculationRounds[state.calcRoundIndex];
  const expected = timeLearningChallenge.columns.flatMap((column) =>
    String(round.answer[column.key] ?? 0).padStart(column.pad, "0").split(""),
  );

  state.calcAnswered = true;
  state.calcResult = { isCorrect: state.calcAnswer.join("") === expected.join("") };
}

function resetClockAnswer() {
  state.clockAnswer = createSlots(getClockAnswerDigits(state.clockTime, state.clockHands).length);
  state.clockActiveSlot = 0;
  state.clockAnswered = false;
  state.clockResult = null;
}

function adjustClock(unit, amount) {
  const current = state.clockTime ?? createClockTime(timeLearningChallenge.clockRounds[state.clockRoundIndex]);
  const totalSeconds = current.hour * 3600 + current.minute * 60 + current.second;
  const delta = unit === "hour" ? amount * 3600 : unit === "minute" ? amount * 60 : amount;
  const nextTotal = ((totalSeconds + delta - 1) % (12 * 3600)) + 1;

  state.clockTime = {
    hour: Math.floor(nextTotal / 3600) || 12,
    minute: Math.floor((nextTotal % 3600) / 60),
    second: nextTotal % 60,
  };
}

function createClockTime(round) {
  return {
    hour: round.hour,
    minute: round.minute,
    second: round.second,
  };
}

function formatClockAnswer(time) {
  return `${String(time.hour).padStart(2, "0")}:${String(time.minute).padStart(2, "0")}:${String(time.second).padStart(2, "0")}`;
}

function getClockAnswerDigits(time, clockHands = {}) {
  return [
    { key: "hour", value: time.hour },
    { key: "minute", value: time.minute },
    { key: "second", value: time.second },
  ].flatMap((part) => (clockHands[part.key] === false ? [] : String(part.value).padStart(2, "0").split("")));
}

function resetCalcAnswer() {
  state.calcAnswer = createSlots(getAnswerSize(timeLearningChallenge.columns));
  state.calcActiveSlot = 0;
  state.calcAnswered = false;
  state.calcResult = null;
}

function createSlots(size) {
  return Array.from({ length: size }, () => "");
}

function getAnswerSize(columns) {
  return columns.reduce((sum, column) => sum + column.digits, 0);
}

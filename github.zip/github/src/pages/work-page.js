import { renderPageLead } from "../components/pageLead.js";
import { renderWorkPage } from "../components/workPage.js";
import { studentProfiles } from "../data/siteData.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const STORAGE_KEY = "aidigital-work-page-v1";

const state = loadWorkState();

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("work-page");

  renderPage({
    currentPageId: "work-page",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "work-top",
        eyebrow: "活動頁",
        title: "工作頁面",
        description: "",
        badge: "活動頁",
        stats: [
          { value: `${state.students.length} 位`, label: "學生" },
          { value: `${state.tasks.length} 項`, label: "工作項目" },
          { value: "可記錄", label: "課堂紀錄" },
        ],
        actions: [
          { label: "學生資料", href: "./students.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderWorkPage({
          state,
          onSelectStudent: (index) => {
            state.activeStudentIndex = index;
            saveWorkState();
            render();
          },
          onToggleTask: (taskId) => {
            const task = state.tasks.find((item) => item.id === taskId);

            if (task) {
              task.done = !task.done;
              saveWorkState();
              render();
            }
          },
          onUpdateNote: (note) => {
            state.note = note;
            saveWorkState();
          },
          onSetFocus: (focus) => {
            state.focus = focus;
            saveWorkState();
            render();
          },
          onResetWork: () => {
            const nextState = createDefaultWorkState();
            Object.assign(state, nextState);
            saveWorkState();
            render();
          },
        }),
      ]),
    ],
  });
}

function createDefaultWorkState() {
  return {
    activeStudentIndex: 0,
    focus: "課中練習",
    note: "",
    students: studentProfiles.slice(0, 4).map((student) => ({
      id: student.id,
      name: student.name,
      account: student.account,
    })),
    tasks: [
      { id: "ready", title: "準備好上課", note: "打開教材、確認聲音與畫面。", done: false },
      { id: "answer", title: "完成一次回答", note: "可以用說、指、選答案的方式。", done: false },
      { id: "practice", title: "完成一個練習", note: "依今天課程選英文或數學活動。", done: false },
      { id: "review", title: "回顧今天重點", note: "說出一件今天學到的事。", done: false },
    ],
  };
}

function loadWorkState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null");

    if (saved?.tasks && saved?.students) {
      return saved;
    }
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }

  return createDefaultWorkState();
}

function saveWorkState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

import { renderPageLead } from "../components/pageLead.js";
import { renderSportsEnglishGame } from "../components/sportsEnglishGame.js?v=20260619-remove-g4-location1";
import {
  canDoChallenge,
  colorLearningChallenge,
  sportsEnglishChallenge,
  studentProfiles,
  thisThatChallenge,
} from "../data/siteData.js?v=20260619-remove-g4-location1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const animalChinese = {
  fox: "狐狸",
  bear: "熊",
  monkey: "猴子",
  elephant: "大象",
  tiger: "老虎",
  lion: "獅子",
  zebra: "斑馬",
  mouse: "老鼠",
  horse: "馬",
  panda: "熊貓",
  rabbit: "兔子",
  goat: "山羊",
};

const fruitChinese = {
  apple: "蘋果",
  banana: "香蕉",
  orange: "橘子",
  star: "星星",
  moon: "月亮",
  sun: "太陽",
};

const objectChinese = {
  pencil: "鉛筆",
  eraser: "橡皮擦",
  pen: "筆",
  marker: "麥克筆",
  book: "書",
  ruler: "尺",
  cake: "蛋糕",
  card: "卡片",
  flower: "花",
  gift: "禮物",
  family: "家人",
  hat: "帽子",
};

const decks = createPictureDecks();
const state = createGameState("sports");
const gameRoot = document.createElement("div");

renderShell();
renderGame();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("sports-game");

  renderPage({
    currentPageId: "sports-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "sports-top",
        eyebrow: "英文遊戲頁",
        title: "圖卡配對",
        description: "",
        badge: "配對翻卡",
        stats: [
          { value: `${decks.length} 種`, label: "圖卡牌組" },
          { value: "12 張", label: "翻卡牌組" },
          { value: `${state.players.length} 位`, label: "輪流學生" },
        ],
        actions: [
          { label: "可不可以", href: "./can-do-game.html", variant: "button--secondary" },
          { label: "這那問答", href: "./this-that-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([gameRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderSportsEnglishGame({
      challenge: { ...sportsEnglishChallenge, title: "圖卡配對" },
      decks,
      state,
      onSelectDeck: (deckId) => {
        Object.assign(state, createGameState(deckId));
        renderGame();
      },
      onStartGame: () => {
        startGame();
      },
      onSelectPlayer: (playerIndex) => {
        if (!state.started || state.isShuffling || state.flippedCardIds.length || state.pendingMismatch || state.finished) return;
        state.activePlayerIndex = playerIndex;
        refreshGameDom();
      },
      onFlipCard: (cardId) => {
        flipCard(cardId);
        refreshGameDom();
      },
      onCoverCards: () => {
        coverCards();
        refreshGameDom();
      },
      onResetGame: () => {
        Object.assign(state, createGameState(state.deckId));
        renderGame();
      },
    }),
  );
}

function createGameState(deckId = "sports") {
  return {
    deckId,
    started: false,
    isShuffling: false,
    activePlayerIndex: 0,
    cards: createCards(deckId),
    flippedCardIds: [],
    matchedSportIds: [],
    pendingMismatch: false,
    lastResult: null,
    attempts: 0,
    finished: false,
    shuffleRound: 0,
    players: studentProfiles.slice(0, 4).map((student) => ({ id: student.id, name: student.name, score: 0 })),
  };
}

function startGame() {
  if (state.isShuffling) return;
  state.started = true;
  state.isShuffling = true;
  state.cards = createCards(state.deckId);
  state.flippedCardIds = [];
  state.matchedSportIds = [];
  state.pendingMismatch = false;
  state.lastResult = null;
  state.attempts = 0;
  state.shuffleRound += 1;
  state.players.forEach((player) => {
    player.score = 0;
  });
  renderGame();

  window.setTimeout(() => {
    state.cards = createCards(state.deckId);
    state.isShuffling = false;
    renderGame();
  }, 900);
}

function createCards(deckId) {
  const deck = decks.find((item) => item.id === deckId) ?? decks[0];
  const cards = deck.items.flatMap((item) => [
    {
      id: `${item.id}-english`,
      sportId: item.id,
      kind: "english",
      text: item.english,
      color: item.color,
      visual: item.visual,
      english: item.english,
      chinese: item.chinese,
    },
    {
      id: `${item.id}-chinese`,
      sportId: item.id,
      kind: "chinese",
      text: item.chinese,
      color: item.color,
      visual: item.visual,
      english: item.english,
      chinese: item.chinese,
    },
  ]);

  return shuffleCards(cards).map((card, index) => ({ ...card, positionLabel: getPositionLabel(index) }));
}

function flipCard(cardId) {
  if (!state.started || state.isShuffling || state.finished || state.pendingMismatch || state.flippedCardIds.includes(cardId)) return;

  const card = state.cards.find((item) => item.id === cardId);
  if (!card || state.matchedSportIds.includes(card.sportId) || state.flippedCardIds.length >= 2) return;

  state.flippedCardIds.push(cardId);

  if (state.flippedCardIds.length < 2) {
    state.lastResult = null;
    return;
  }

  state.attempts += 1;
  resolvePair();
}

function resolvePair() {
  const [firstCard, secondCard] = state.flippedCardIds.map((id) => state.cards.find((card) => card.id === id));
  const isMatch = firstCard?.sportId === secondCard?.sportId && firstCard?.kind !== secondCard?.kind;

  if (isMatch) {
    state.matchedSportIds.push(firstCard.sportId);
    state.players[state.activePlayerIndex].score += 1;
    state.lastResult = {
      isMatch: true,
      english: firstCard.english,
      chinese: firstCard.chinese,
    };
    state.flippedCardIds = [];
    advancePlayer();

    if (state.matchedSportIds.length >= getCurrentDeck().items.length) {
      state.finished = true;
    }
    return;
  }

  state.pendingMismatch = true;
  state.lastResult = { isMatch: false };
}

function coverCards() {
  if (!state.pendingMismatch) return;
  state.flippedCardIds = [];
  state.pendingMismatch = false;
  state.lastResult = null;
  advancePlayer();
}

function advancePlayer() {
  state.activePlayerIndex = (state.activePlayerIndex + 1) % state.players.length;
}

function refreshGameDom() {
  if (state.finished) {
    renderGame();
    return;
  }

  updateMemoryStats();
  updatePlayerChips();
  updateMemoryTiles();
  updateTurnTitle();
  updateFeedback();
}

function updateMemoryStats() {
  const matchedText = gameRoot.querySelector(".sports-memory-stat--matched strong");
  const attemptsText = gameRoot.querySelector(".sports-memory-stat--attempts strong");
  if (matchedText) matchedText.textContent = `${state.matchedSportIds.length} / ${getCurrentDeck().items.length}`;
  if (attemptsText) attemptsText.textContent = String(state.attempts);
}

function updatePlayerChips() {
  gameRoot.querySelectorAll(".sports-player-chip[data-player-index]").forEach((chip) => {
    const playerIndex = Number(chip.dataset.playerIndex);
    const player = state.players[playerIndex];
    chip.classList.toggle("is-active", playerIndex === state.activePlayerIndex);
    chip.disabled = Boolean(state.isShuffling || state.flippedCardIds.length || state.pendingMismatch);
    const score = chip.querySelector("span");
    if (score && player) score.textContent = `${player.score} 分`;
  });
}

function updateMemoryTiles() {
  gameRoot.querySelectorAll(".sports-memory-tile[data-card-id]").forEach((tile) => {
    const cardId = tile.dataset.cardId;
    const sportId = tile.dataset.sportId;
    const isMatched = state.matchedSportIds.includes(sportId);
    const isFlipped = isMatched || state.flippedCardIds.includes(cardId);
    const isLocked = state.isShuffling || isMatched || state.pendingMismatch || state.flippedCardIds.length >= 2;

    tile.classList.toggle("is-flipped", isFlipped);
    tile.classList.toggle("is-matched", isMatched);
    tile.classList.toggle("is-shuffling", state.isShuffling);
    tile.disabled = isLocked;
  });
}

function updateTurnTitle() {
  const activePlayer = state.players[state.activePlayerIndex];
  const badge = gameRoot.querySelector(".sports-memory-head .badge");
  const title = gameRoot.querySelector(".sports-memory-head h3");
  if (badge) badge.textContent = state.isShuffling ? "洗牌中" : `輪到 ${activePlayer.name}`;
  if (title) title.textContent = state.isShuffling ? "卡片正在洗牌" : `${getCurrentDeck().label}配對`;
}

function updateFeedback() {
  const feedbackSlot = gameRoot.querySelector(".sports-feedback-slot");
  if (!feedbackSlot) return;

  feedbackSlot.replaceChildren(createFeedbackNode());
}

function createFeedbackNode() {
  if (state.isShuffling) {
    return paragraph("sports-feedback", "洗牌中，等等就可以開始翻卡。");
  }

  if (!state.lastResult) {
    return paragraph("sports-feedback", "先翻兩張卡，找出英文和中文是不是同一張圖卡。");
  }

  if (state.lastResult.isMatch) {
    const wrapper = document.createElement("div");
    wrapper.className = "sports-feedback is-correct";
    const title = document.createElement("strong");
    title.textContent = "配對成功";
    const text = document.createElement("span");
    text.textContent = `${state.lastResult.english} = ${state.lastResult.chinese}`;
    wrapper.append(title, text);
    return wrapper;
  }

  const wrapper = document.createElement("div");
  wrapper.className = "sports-feedback is-wrong";
  const title = document.createElement("strong");
  title.textContent = "沒有配對";
  const text = document.createElement("span");
  text.textContent = "看清楚兩張卡，再把它們蓋回去。";
  const button = document.createElement("button");
  button.className = "button button--secondary";
  button.type = "button";
  button.textContent = "蓋回卡片";
  button.addEventListener("click", () => {
    coverCards();
    refreshGameDom();
  });
  wrapper.append(title, text, button);
  return wrapper;
}

function paragraph(className, text) {
  const node = document.createElement("p");
  node.className = className;
  node.textContent = text;
  return node;
}

function getCurrentDeck() {
  return decks.find((deck) => deck.id === state.deckId) ?? decks[0];
}

function createPictureDecks() {
  const objectWords = createRoundItems(["pencil", "eraser", "pen", "marker", "book", "ruler"], objectChinese, "#57aeb2");
  const dailyWords = createRoundItems(["cake", "card", "flower", "gift", "family", "hat"], objectChinese, "#f0b35b");
  const animalWords = createRoundItems(["fox", "bear", "monkey", "elephant", "tiger", "lion"], animalChinese, "#77b96c");
  const animalWords2 = createRoundItems(["zebra", "mouse", "horse", "panda", "rabbit", "goat"], animalChinese, "#70a6df");
  const fruitWords = createRoundItems(["apple", "banana", "orange", "star", "moon", "sun"], fruitChinese, "#f18a5b");
  const partnerWords = canDoChallenge.partners.slice(0, 6).map((partner) => ({
    id: partner.id,
    english: partner.label,
    chinese: partner.chinese,
    visual: partner.emoji,
    color: "#8bb2f0",
  }));

  return [
    {
      id: "sports",
      label: "運動圖卡",
      items: sportsEnglishChallenge.sports.map((sport) => ({
        id: sport.id,
        english: sport.english,
        chinese: sport.chinese,
        visual: sport.emoji,
        color: sport.color,
      })),
    },
    {
      id: "colors2",
      label: "更多顏色",
      items: colorLearningChallenge.palette.slice(5, 11).map((color) => ({
        id: color.id,
        english: color.english,
        chinese: color.chinese,
        visual: "",
        color: color.swatch,
      })),
    },
    {
      id: "actions",
      label: "動作圖卡",
      items: canDoChallenge.actions.slice(0, 6).map((action) => ({
        id: action.id,
        english: action.label,
        chinese: action.chinese,
        visual: action.emoji,
        color: "#f0b35b",
      })),
    },
    {
      id: "colors",
      label: "顏色圖卡",
      items: colorLearningChallenge.palette.slice(0, 6).map((color) => ({
        id: color.id,
        english: color.english,
        chinese: color.chinese,
        visual: "",
        color: color.swatch,
      })),
    },
    {
      id: "objects",
      label: "物品圖卡",
      items: objectWords,
    },
    {
      id: "daily",
      label: "生活圖卡",
      items: dailyWords,
    },
    {
      id: "animals",
      label: "動物圖卡",
      items: animalWords,
    },
    {
      id: "animals2",
      label: "更多動物",
      items: animalWords2,
    },
    {
      id: "fruits",
      label: "水果天空",
      items: fruitWords,
    },
    {
      id: "partners",
      label: "夥伴圖卡",
      items: partnerWords,
    },
  ];
}

function createRoundItems(itemIds, dictionary, color) {
  return uniqueBy(
    thisThatChallenge.rounds
      .filter((round) => itemIds.includes(round.item))
      .map((round) => ({
        id: round.item,
        english: round.item,
        chinese: dictionary[round.item] ?? round.item,
        visual: round.emoji,
        color,
      })),
    "id",
  );
}

function uniqueBy(items, key) {
  const seen = new Set();
  return items.filter((item) => {
    if (seen.has(item[key])) return false;
    seen.add(item[key]);
    return true;
  });
}

function getPositionLabel(index) {
  const column = ["A", "B", "C", "D"][index % 4];
  const row = Math.floor(index / 4) + 1;
  return `${column}${row}`;
}

function shuffleCards(cards) {
  const shuffled = [...cards];

  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = randomInt(index + 1);
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }

  return shuffled;
}

function randomInt(max) {
  if (window.crypto?.getRandomValues) {
    const values = new Uint32Array(1);
    window.crypto.getRandomValues(values);
    return values[0] % max;
  }

  return Math.floor(Math.random() * max);
}

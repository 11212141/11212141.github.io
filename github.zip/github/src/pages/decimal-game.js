import { renderDecimalArithmeticGame } from "../components/decimalArithmeticGame.js?v=20260917-decimal-intro11";
import { renderPageLead } from "../components/pageLead.js";
import { decimalArithmeticChallenge } from "../data/siteData.js?v=20260917-decimal-intro11";
import {
  advanceDecimalRound,
  chooseDecimalDigit,
  clearDecimalDigits,
  createDecimalGameState,
  setDecimalAnswerSlot,
  setDecimalMode,
  skipDecimalRound,
  submitDecimalAnswer,
} from "../pageState.js?v=20260917-decimal-intro11";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260917-decimal-intro11";

const state = {
  decimalGame: createDecimalGameState(),
};
const gameRoot = document.createElement("div");

renderShell();
renderGame();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("decimal-game");

  renderPage({
    currentPageId: "decimal-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "decimal-top",
        eyebrow: "數學遊戲頁",
        title: decimalArithmeticChallenge.title,
        description: "",
        badge: decimalArithmeticChallenge.badge,
        stats: [
          { value: `${decimalArithmeticChallenge.rounds.length} 題`, label: "題目數" },
          { value: "直式", label: "對齊練習" },
          { value: `${state.decimalGame.players.length} 位`, label: "輪流學生" },
        ],
        actions: [
          { label: "金錢拼數字", href: "./money-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([gameRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderDecimalArithmeticGame({
      challenge: decimalArithmeticChallenge,
      gameState: state.decimalGame,
      onSelectPlayer: (playerIndex) => {
        if (state.decimalGame.finished || state.decimalGame.isAnswered) {
          return;
        }

        state.decimalGame.activePlayerIndex = playerIndex;
        renderGame();
      },
      onChooseDigit: (digit) => {
        chooseDecimalDigit(state.decimalGame, digit);
        updateDecimalInteraction();
      },
      onDropDigit: (slotIndex, digit) => {
        setDecimalAnswerSlot(state.decimalGame, slotIndex);
        chooseDecimalDigit(state.decimalGame, digit);
        updateDecimalInteraction();
      },
      onSelectAnswerSlot: (slotIndex) => {
        setDecimalAnswerSlot(state.decimalGame, slotIndex);
        updateDecimalInteraction();
      },
      onSetMode: (mode) => {
        setDecimalMode(state.decimalGame, mode);
        renderGame();
      },
      onClearDigits: () => {
        clearDecimalDigits(state.decimalGame);
        renderGame();
      },
      onSubmitAnswer: () => {
        submitDecimalAnswer(state.decimalGame);
        renderGame();
      },
      onShowProcess: () => {
        if (!isReadyToShowProcess()) return;
        state.decimalGame.processStep = 0;
        renderGame();
      },
      onNextProcess: () => {
        if (state.decimalGame.processStep === null) return;
        state.decimalGame.processStep += 1;
        renderGame();
      },
      onHideProcess: () => {
        state.decimalGame.processStep = null;
        renderGame();
      },
      onNextRound: () => {
        advanceDecimalRound(state.decimalGame);
        renderGame();
      },
      onSkipRound: () => {
        skipDecimalRound(state.decimalGame);
        renderGame();
      },
      onResetGame: () => {
        state.decimalGame = createDecimalGameState();
        renderGame();
      },
    }),
  );
}

function updateDecimalInteraction() {
  gameRoot.querySelectorAll(".vertical-equation__slot").forEach((slot) => {
    const slotIndex = Number(slot.dataset.slotIndex);
    slot.textContent = state.decimalGame.verticalDigits[slotIndex] || "□";
    slot.classList.toggle("is-active", slotIndex === state.decimalGame.activeVerticalSlot);
  });

  const submitButton = gameRoot.querySelector("[data-decimal-submit]");
  if (submitButton) {
    submitButton.toggleAttribute("disabled", !isReadyToSubmit());
  }

  gameRoot.querySelectorAll("[data-decimal-process-trigger]").forEach((button) => {
    button.toggleAttribute("disabled", !isReadyToShowProcess());
  });
}

function isReadyToSubmit() {
  if (state.decimalGame.isAnswered) return false;
  if (state.decimalGame.mode === "challenge") {
    return state.decimalGame.verticalDigits.slice(4, 6).every(Boolean);
  }
  return state.decimalGame.verticalDigits.every(Boolean);
}

function isReadyToShowProcess() {
  if (state.decimalGame.mode === "challenge") {
    return true;
  }

  const [topOnes, topTenths, bottomOnes, bottomTenths] = state.decimalGame.verticalDigits;
  if ([topOnes, topTenths, bottomOnes, bottomTenths].some((digit) => digit === "")) {
    return false;
  }

  const top = Number(`${topOnes}.${topTenths}`);
  const bottom = Number(`${bottomOnes}.${bottomTenths}`);
  const round = decimalArithmeticChallenge.rounds[state.decimalGame.roundIndex];
  return round.operator === "+" || top >= bottom;
}

import { renderCapacityCalculationGame } from "../components/capacityCalculationGame.js?v=20260509-time1";
import { renderMathConceptGame } from "../components/mathConceptGame.js?v=20260509-split1";
import { renderPageLead } from "../components/pageLead.js";
import { capacityCalculationChallenge, mathConceptChallenge } from "../data/siteData.js?v=20260509-time1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const mode = {
  ...mathConceptChallenge.modes.find((item) => item.id === "capacity"),
  detailCards: [
    { kicker: "單位", title: "公升 L", text: "水桶、牛奶、湯鍋這種比較多的液體常用公升。" },
    { kicker: "單位", title: "毫升 mL", text: "杯子、藥水、果汁盒這種比較少的液體常用毫升。" },
    { kicker: "計算", title: "1000 毫升 = 1 公升", text: "加減時先看毫升，滿 1000 就換成 1 公升。" },
  ],
};
const challenge = { title: "容量加減", badge: "數學遊戲", modes: [mode] };
const state = {
  pageMode: "choice",
  choice: createChoiceState(mode.id),
  calculation: createCalculationState(),
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("capacity-game");

  renderPage({
    currentPageId: "capacity-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "capacity-top",
        eyebrow: "數學遊戲頁",
        title: challenge.title,
        description: "",
        badge: challenge.badge,
        stats: [
          { value: "30 題", label: "容量題" },
          { value: "公升 / 毫升", label: "單位" },
          { value: "30 題", label: "直式計算" },
        ],
        actions: [
          { label: "時間活動", href: "./time-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([renderModeTabs(), state.pageMode === "choice" ? renderSingleModeGame() : renderCalculationGame()]),
    ],
  });
}

function renderModeTabs() {
  const wrapper = document.createElement("div");
  wrapper.className = "decimal-mode-switch";

  [
    { id: "choice", label: "容量選一選" },
    { id: "calculation", label: "容量直式" },
  ].forEach((item) => {
    const button = document.createElement("button");
    button.className = `button ${state.pageMode === item.id ? "button--primary" : "button--secondary"}`;
    button.type = "button";
    button.textContent = item.label;
    button.addEventListener("click", () => {
      state.pageMode = item.id;
      render();
    });
    wrapper.append(button);
  });

  return wrapper;
}

function renderSingleModeGame() {
  return renderMathConceptGame({
    challenge,
    state: state.choice,
    onSetMode: () => {},
    onChooseAnswer: (answer) => {
      chooseAnswer(answer);
      render();
    },
    onNextRound: () => {
      advanceRound();
      render();
    },
  });
}

function renderCalculationGame() {
  return renderCapacityCalculationGame({
    challenge: capacityCalculationChallenge,
    state: state.calculation,
    onChooseDigit: (digit) => {
      chooseDigit(digit);
      render();
    },
    onSelectSlot: (slot) => {
      state.calculation.activeSlot = slot;
      render();
    },
    onClearAnswer: () => {
      state.calculation.answer = createAnswerSlots(capacityCalculationChallenge.columns);
      state.calculation.activeSlot = 0;
      state.calculation.answered = false;
      state.calculation.result = null;
      render();
    },
    onSubmitAnswer: () => {
      submitCalculationAnswer();
      render();
    },
    onNextRound: () => {
      advanceCalculationRound();
      render();
    },
  });
}

function createChoiceState(modeId) {
  return {
    mode: modeId,
    roundIndexes: { [modeId]: 0 },
    selectedAnswers: { [modeId]: "" },
    results: { [modeId]: null },
  };
}

function createCalculationState() {
  return {
    roundIndex: 0,
    answer: createAnswerSlots(capacityCalculationChallenge.columns),
    activeSlot: 0,
    answered: false,
    result: null,
  };
}

function chooseAnswer(answer) {
  const round = mode.rounds[state.choice.roundIndexes[mode.id]];
  state.choice.selectedAnswers[mode.id] = answer;
  state.choice.results[mode.id] = { isCorrect: answer === round.answer };
}

function advanceRound() {
  state.choice.roundIndexes[mode.id] = (state.choice.roundIndexes[mode.id] + 1) % mode.rounds.length;
  state.choice.selectedAnswers[mode.id] = "";
  state.choice.results[mode.id] = null;
}

function chooseDigit(digit) {
  if (state.calculation.answered) {
    return;
  }

  state.calculation.answer[state.calculation.activeSlot] = String(digit);
  state.calculation.activeSlot = Math.min(state.calculation.activeSlot + 1, state.calculation.answer.length - 1);
}

function submitCalculationAnswer() {
  if (state.calculation.answer.some((digit) => digit === "")) {
    return;
  }

  const round = capacityCalculationChallenge.rounds[state.calculation.roundIndex];
  const expected = capacityCalculationChallenge.columns.flatMap((column) =>
    String(round.answer[column.key] ?? 0).padStart(column.pad, "0").split(""),
  );
  state.calculation.answered = true;
  state.calculation.result = { isCorrect: state.calculation.answer.join("") === expected.join("") };
}

function advanceCalculationRound() {
  state.calculation.roundIndex = (state.calculation.roundIndex + 1) % capacityCalculationChallenge.rounds.length;
  state.calculation.answer = createAnswerSlots(capacityCalculationChallenge.columns);
  state.calculation.activeSlot = 0;
  state.calculation.answered = false;
  state.calculation.result = null;
}

function createAnswerSlots(columns) {
  return Array.from({ length: columns.reduce((sum, column) => sum + column.digits, 0) }, () => "");
}

import { renderFooter } from "../components/footer.js";
import { renderHeader } from "../components/header.js?v=20260917-decimal-intro11";
import { programProfile, sitePages } from "../data/siteData.js?v=20260917-decimal-intro11";
import { applyNameVisibility, installNameVisibilityObserver } from "../utils/nameVisibility.js?v=20260624-menu-clean2";

const headerRoot = document.querySelector("#site-header");
const appRoot = document.querySelector("#app");
const footerRoot = document.querySelector("#site-footer");

export function renderPage({ currentPageId, children, actionText, actionHref, pages = sitePages }) {
  headerRoot.replaceChildren(
    renderHeader(programProfile, {
      currentPageId,
      pages,
      actionText,
      actionHref,
    }),
  );
  footerRoot.replaceChildren(renderFooter());
  appRoot.replaceChildren(...children);
  installNameVisibilityObserver();
  applyNameVisibility(document.body);
}

export function mountDashboard(children) {
  const wrapper = document.createElement("section");
  wrapper.className = "dashboard-grid";

  const inner = document.createElement("div");
  inner.className = "container dashboard-grid__column";
  inner.append(...children);
  wrapper.append(inner);
  return wrapper;
}

export function getDefaultAction(currentPageId) {
  if (currentPageId === "home") {
    return {
      actionText: "",
      actionHref: "",
    };
  }

  return {
    actionText: "回到活動總覽",
    actionHref: "./index.html",
  };
}

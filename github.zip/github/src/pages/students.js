import { renderPageLead } from "../components/pageLead.js";
import { renderStudentProfiles } from "../components/studentProfiles.js?v=20260624-menu-clean2";
import { studentProfiles } from "../data/siteData.js?v=20260624-menu-clean2";
import { getNameVisibilityRows, areStudentNamesVisible, setStudentNamesVisible } from "../utils/nameVisibility.js?v=20260624-menu-clean2";
import { el } from "../utils/dom.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260624-menu-clean2";

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("students");

  renderPage({
    currentPageId: "students",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "students-top",
        eyebrow: "學生頁",
        title: "學生資料",
        description: "",
        badge: "學生資料",
        stats: [],
        actions: [
          { label: "金錢拼數字", href: "./money-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderNameVisibilityPanel(),
        renderStudentProfiles({
          students: studentProfiles,
        }),
      ]),
    ],
  });
}

function renderNameVisibilityPanel() {
  const isVisible = areStudentNamesVisible();

  return el("section", {
    className: "panel name-settings-panel",
    attrs: { "data-name-visibility-skip": "true" },
    children: [
      el("div", {
        className: "panel__content name-settings name-settings--inline",
        children: [
          el("div", {
            className: "name-settings__hero",
            children: [
              el("div", {
                children: [
                  el("span", { className: "badge badge--live", text: "全站名字" }),
                  el("h2", { text: isVisible ? "活動中顯示姓名" : "活動中隱藏姓名" }),
                ],
              }),
              el("button", {
                className: `name-settings-toggle${isVisible ? " is-on" : ""}`,
                attrs: { type: "button", "aria-pressed": String(isVisible) },
                on: {
                  click: () => {
                    setStudentNamesVisible(!areStudentNamesVisible());
                    render();
                  },
                },
                children: [
                  el("span", { text: isVisible ? "顯示名字" : "隱藏名字" }),
                  el("i"),
                ],
              }),
            ],
          }),
          el("div", {
            className: "name-settings-preview name-settings-preview--compact",
            children: getNameVisibilityRows().map((row) =>
              el("article", {
                className: "name-settings-card",
                children: [
                  el("span", { text: row.mask }),
                  el("strong", { text: row.name }),
                  el("small", { text: isVisible ? "目前顯示姓名" : `目前顯示 ${row.mask}` }),
                ],
              }),
            ),
          }),
        ],
      }),
    ],
  });
}

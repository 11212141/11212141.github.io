import { renderDateMathGame } from "../components/dateMathGame.js?v=20260527-date-math4";
import { renderPageLead } from "../components/pageLead.js";
import { dateMathChallenge, studentProfiles } from "../data/siteData.js?v=20260527-date-math4";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  mode: "all",
  visualMode: "day",
  roundIndex: 0,
  activePlayerIndex: 0,
  selectedAnswer: "",
  answered: false,
  result: null,
  players: studentProfiles.map((student) => ({
    name: student.name,
    score: 0,
  })),
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("date-math-game");
  const rounds = getActiveRounds();
  const currentRound = rounds[state.roundIndex] ?? rounds[0];
  const activePlayer = state.players[state.activePlayerIndex];

  renderPage({
    currentPageId: "date-math-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "date-math-top",
        eyebrow: "數學遊戲頁",
        title: dateMathChallenge.title,
        description: "",
        badge: dateMathChallenge.badge,
        stats: [
          { value: `${dateMathChallenge.rounds.length} 題`, label: "題目數" },
          { value: "5 種", label: "日期模式" },
          { value: `${state.players.length} 位`, label: "輪流學生" },
        ],
        actions: [
          { label: "時間時鐘", href: "./time-game.html", variant: "button--secondary" },
          { label: "理財富翁", href: "./date-finance-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderDateMathGame({
          challenge: dateMathChallenge,
          state,
          rounds,
          currentRound,
          activePlayer,
          onSetMode: (mode) => {
            state.mode = mode;
            resetQuestion();
            state.roundIndex = 0;
            render();
          },
          onSetVisualMode: (mode) => {
            state.visualMode = mode;
            render();
          },
          onSelectPlayer: (index) => {
            if (state.answered) return;
            state.activePlayerIndex = index;
            render();
          },
          onChooseAnswer: (answer) => {
            if (state.answered) return;
            state.selectedAnswer = answer;
            state.answered = true;
            state.result = { isCorrect: answer === currentRound.answer };
            if (state.result.isCorrect) {
              activePlayer.score += 1;
            }
            render();
          },
          onNextRound: () => {
            state.roundIndex = state.roundIndex >= rounds.length - 1 ? 0 : state.roundIndex + 1;
            state.activePlayerIndex = (state.activePlayerIndex + 1) % state.players.length;
            resetQuestion();
            render();
          },
          onReset: () => {
            state.mode = "all";
            state.visualMode = "day";
            state.roundIndex = 0;
            state.activePlayerIndex = 0;
            resetQuestion();
            state.players.forEach((player) => {
              player.score = 0;
            });
            render();
          },
        }),
      ]),
    ],
  });
}

function getActiveRounds() {
  if (state.mode === "all") {
    return dateMathChallenge.rounds;
  }

  return dateMathChallenge.rounds.filter((round) => round.mode === state.mode);
}

function resetQuestion() {
  state.selectedAnswer = "";
  state.answered = false;
  state.result = null;
}

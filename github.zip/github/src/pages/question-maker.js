import { renderPageLead } from "../components/pageLead.js";
import { renderQuestionMakerGame } from "../components/questionMakerGame.js?v=20260617-question-maker1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const STORAGE_KEY = "ai-digital-question-maker";

const emptyDraft = {
  type: "math",
  prompt: "",
  choices: "",
  answer: "",
};

const state = {
  draft: { ...emptyDraft },
  questions: loadQuestions(),
  activeQuestionId: "",
  showAnswer: false,
};

if (state.questions.length) {
  state.activeQuestionId = state.questions[0].id;
}

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("question-maker");

  renderPage({
    currentPageId: "question-maker",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "question-maker-top",
        eyebrow: "活動遊戲頁",
        title: "應用出題",
        description: "",
        badge: "活動遊戲",
        stats: [
          { value: `${state.questions.length} 題`, label: "題目庫" },
          { value: "抽題", label: "立即展示" },
          { value: "本機", label: "自動保存" },
        ],
        actions: [{ label: "回到活動總覽", href: "./index.html", variant: "button--primary" }],
      }),
      mountDashboard([
        renderQuestionMakerGame({
          state,
          onUpdateDraft: updateDraft,
          onAddQuestion: addQuestion,
          onPickQuestion: pickQuestion,
          onSelectQuestion: selectQuestion,
          onToggleAnswer: toggleAnswer,
          onMarkDone: markDone,
          onDeleteQuestion: deleteQuestion,
          onResetDraft: resetDraft,
        }),
      ]),
    ],
  });
}

function updateDraft(field, value) {
  state.draft = { ...state.draft, [field]: value };
  if (field === "type") {
    render();
  }
}

function addQuestion() {
  const prompt = state.draft.prompt.trim();
  if (!prompt) {
    return;
  }

  const question = {
    id: `question-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type: state.draft.type,
    prompt,
    choices: state.draft.choices.trim(),
    answer: state.draft.answer.trim(),
    done: false,
    createdAt: new Date().toISOString(),
  };

  state.questions = [question, ...state.questions];
  state.activeQuestionId = question.id;
  state.showAnswer = false;
  state.draft = { ...emptyDraft, type: state.draft.type };
  saveQuestions();
  render();
}

function pickQuestion() {
  const availableQuestions = state.questions.filter((question) => question.id !== state.activeQuestionId);
  const pool = availableQuestions.length ? availableQuestions : state.questions;
  const picked = pool[Math.floor(Math.random() * pool.length)];
  if (!picked) {
    return;
  }

  state.activeQuestionId = picked.id;
  state.showAnswer = false;
  render();
}

function selectQuestion(questionId) {
  state.activeQuestionId = questionId;
  state.showAnswer = false;
  render();
}

function toggleAnswer() {
  state.showAnswer = !state.showAnswer;
  render();
}

function markDone() {
  state.questions = state.questions.map((question) =>
    question.id === state.activeQuestionId ? { ...question, done: !question.done } : question,
  );
  saveQuestions();
  render();
}

function deleteQuestion(questionId) {
  state.questions = state.questions.filter((question) => question.id !== questionId);
  if (state.activeQuestionId === questionId) {
    state.activeQuestionId = state.questions[0]?.id ?? "";
    state.showAnswer = false;
  }
  saveQuestions();
  render();
}

function resetDraft() {
  state.draft = { ...emptyDraft, type: state.draft.type };
  render();
}

function loadQuestions() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch (error) {
    return [];
  }
}

function saveQuestions() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.questions));
}

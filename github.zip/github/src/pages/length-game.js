import { renderLengthLearningGame } from "../components/lengthLearningGame.js?v=20260509-split1";
import { renderPageLead } from "../components/pageLead.js";
import { lengthLearningChallenge } from "../data/siteData.js?v=20260509-split1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const LENGTH_UNITS = ["公尺", "公分", "毫米"];
const DEFAULT_CALC_UNITS = ["公尺", "公分"];

const state = {
  mode: "units",
  unitRoundIndex: 0,
  unitSelected: "",
  unitResult: null,
  compareRoundIndex: 0,
  compareSelected: "",
  compareResult: null,
  buildRoundIndex: 0,
  buildRevealed: false,
  selectedCalcUnits: [...DEFAULT_CALC_UNITS],
  calculationRoundIndexes: Object.fromEntries(
    lengthLearningChallenge.calculationModes.map((mode) => [mode.id, 0]),
  ),
  lengthAnswer: createAnswerSlots(getCalculationMode(DEFAULT_CALC_UNITS)),
  activeLengthSlot: 0,
  lengthAnswered: false,
  lengthResult: null,
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("length-game");
  const calculationMode = getCalculationMode(state.selectedCalcUnits);
  const totalCalculationRounds = calculationMode?.rounds.length ?? 30;

  renderPage({
    currentPageId: "length-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "length-top",
        eyebrow: "數學遊戲頁",
        title: lengthLearningChallenge.title,
        description: "",
        badge: lengthLearningChallenge.badge,
        stats: [
          { value: "4 個", label: "長度活動" },
          { value: "三選二", label: "直式單位" },
          { value: `${totalCalculationRounds} 題`, label: "計算題" },
        ],
        actions: [
          { label: "小數加減法", href: "./decimal-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderLengthLearningGame({
          challenge: lengthLearningChallenge,
          state,
          calculationMode,
          onSetMode: (mode) => {
            state.mode = mode;
            render();
          },
          onChooseUnit: (value) => {
            chooseChoice("unit", value);
            render();
          },
          onNextUnit: () => {
            advanceChoice("unit", lengthLearningChallenge.unitRounds.length);
            render();
          },
          onChooseCompare: (value) => {
            chooseChoice("compare", value);
            render();
          },
          onNextCompare: () => {
            advanceChoice("compare", lengthLearningChallenge.compareRounds.length);
            render();
          },
          onRevealBuild: () => {
            state.buildRevealed = true;
            render();
          },
          onNextBuild: () => {
            state.buildRoundIndex = (state.buildRoundIndex + 1) % lengthLearningChallenge.buildRounds.length;
            state.buildRevealed = false;
            render();
          },
          onToggleCalcUnit: (unit) => {
            toggleCalcUnit(unit);
            render();
          },
          onSelectLengthSlot: (slotIndex) => {
            if (state.lengthAnswered || !calculationMode) {
              return;
            }

            state.activeLengthSlot = slotIndex;
            render();
          },
          onChooseLengthDigit: (digit) => {
            if (state.lengthAnswered || !calculationMode) {
              return;
            }

            state.lengthAnswer[state.activeLengthSlot] = String(digit);
            state.activeLengthSlot = (state.activeLengthSlot + 1) % state.lengthAnswer.length;
            state.lengthResult = null;
            render();
          },
          onClearLengthAnswer: () => {
            clearLengthAnswer();
            render();
          },
          onSubmitLengthAnswer: () => {
            submitLengthAnswer(calculationMode);
            render();
          },
          onNextCalculation: () => {
            advanceCalculationRound(calculationMode);
            render();
          },
        }),
      ]),
    ],
  });
}

function chooseChoice(kind, value) {
  const round =
    kind === "unit"
      ? lengthLearningChallenge.unitRounds[state.unitRoundIndex]
      : lengthLearningChallenge.compareRounds[state.compareRoundIndex];

  state[`${kind}Selected`] = value;
  state[`${kind}Result`] = {
    isCorrect: value === round.answer,
  };
}

function advanceChoice(kind, total) {
  state[`${kind}RoundIndex`] = (state[`${kind}RoundIndex`] + 1) % total;
  state[`${kind}Selected`] = "";
  state[`${kind}Result`] = null;
}

function submitLengthAnswer(calculationMode) {
  if (!calculationMode || state.lengthAnswer.some((digit) => digit === "")) {
    return;
  }

  const roundIndex = state.calculationRoundIndexes[calculationMode.id] ?? 0;
  const round = calculationMode.rounds[roundIndex];
  const expectedDigits = calculationMode.columns.flatMap((column) =>
    String(round.answer[column.key] ?? 0)
      .padStart(column.pad, "0")
      .split(""),
  );
  const isCorrect = state.lengthAnswer.join("") === expectedDigits.join("");

  state.lengthAnswered = true;
  state.lengthResult = { isCorrect };
}

function clearLengthAnswer() {
  const calculationMode = getCalculationMode(state.selectedCalcUnits);
  state.lengthAnswer = createAnswerSlots(calculationMode);
  state.activeLengthSlot = 0;
  state.lengthAnswered = false;
  state.lengthResult = null;
}

function toggleCalcUnit(unit) {
  if (!LENGTH_UNITS.includes(unit)) {
    return;
  }

  if (state.selectedCalcUnits.includes(unit)) {
    state.selectedCalcUnits = state.selectedCalcUnits.filter((item) => item !== unit);
  } else if (state.selectedCalcUnits.length < 2) {
    state.selectedCalcUnits = [...state.selectedCalcUnits, unit];
  } else {
    return;
  }

  state.selectedCalcUnits = LENGTH_UNITS.filter((item) => state.selectedCalcUnits.includes(item));
  clearLengthAnswer();
}

function getCalculationMode(selectedUnits) {
  if (selectedUnits.length !== 2) {
    return null;
  }

  return (
    lengthLearningChallenge.calculationModes.find(
      (mode) => mode.units.length === 2 && mode.units.every((unit) => selectedUnits.includes(unit)),
    ) ?? null
  );
}

function createAnswerSlots(calculationMode) {
  const size = calculationMode
    ? calculationMode.columns.reduce((sum, column) => sum + column.digits, 0)
    : 0;

  return Array(size).fill("");
}

function advanceCalculationRound(calculationMode) {
  if (!calculationMode) {
    return;
  }

  state.calculationRoundIndexes[calculationMode.id] =
    ((state.calculationRoundIndexes[calculationMode.id] ?? 0) + 1) % calculationMode.rounds.length;
  clearLengthAnswer();
}

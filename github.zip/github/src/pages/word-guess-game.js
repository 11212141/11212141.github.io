import { renderPageLead } from "../components/pageLead.js";
import { renderWordGuessGame } from "../components/wordGuessGame.js";
import { studentProfiles } from "../data/siteData.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  game: createWordGuessState(),
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("word-guess-game");

  renderPage({
    currentPageId: "word-guess-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "word-guess-top",
        eyebrow: "英文遊戲頁",
        title: "猜單字遊戲",
        description: "",
        badge: "英文遊戲",
        stats: [
          { value: "老師出題", label: "自訂單字" },
          { value: "可設定", label: "錯誤次數" },
          { value: "四位", label: "學生計分" },
        ],
        actions: [
          { label: "聽母音遊戲", href: "./phonics-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderWordGuessGame({
          state: state.game,
          onUpdateSetup: (key, value) => {
            if (key === "word") {
              state.game.setup.word = normalizeGuessWord(value);
            } else if (key === "hint") {
              state.game.setup.hint = value.slice(0, 28);
            } else if (key === "maxWrong") {
              state.game.setup.maxWrong = normalizeGuessLimit(value);
            }
          },
          onStartGame: () => {
            const word = normalizeGuessWord(state.game.setup.word);

            if (!word) {
              return;
            }

            state.game.targetWord = word;
            state.game.hint = state.game.setup.hint.trim();
            state.game.maxWrong = state.game.setup.maxWrong;
            state.game.guessedLetters = [];
            state.game.hintVisible = false;
            state.game.status = "playing";
            render();
          },
          onSelectPlayer: (playerIndex) => {
            state.game.activePlayerIndex = playerIndex;
            render();
          },
          onGuessLetter: (letter) => {
            if (state.game.status !== "playing" || state.game.guessedLetters.includes(letter)) {
              return;
            }

            state.game.guessedLetters.push(letter);
            updateGameStatus();
            render();
          },
          onToggleHint: () => {
            state.game.hintVisible = !state.game.hintVisible;
            render();
          },
          onNewRound: () => {
            const players = state.game.players;
            const activePlayerIndex = (state.game.activePlayerIndex + 1) % players.length;
            const roundNumber = state.game.roundNumber + 1;
            const setup = { ...state.game.setup };
            state.game = createWordGuessState({ players, activePlayerIndex, roundNumber, setup });
            render();
          },
          onResetScores: () => {
            state.game.players = createPlayers();
            render();
          },
        }),
      ]),
    ],
  });
}

function createWordGuessState({ players = createPlayers(), activePlayerIndex = 0, roundNumber = 1, setup } = {}) {
  return {
    activePlayerIndex,
    players,
    roundNumber,
    setup: setup ?? {
      word: "apple",
      hint: "fruit",
      maxWrong: 6,
    },
    targetWord: "",
    hint: "",
    hintVisible: false,
    maxWrong: setup?.maxWrong ?? 6,
    guessedLetters: [],
    status: "setup",
  };
}

function createPlayers() {
  return studentProfiles.slice(0, 4).map((student) => ({
    id: student.id,
    name: student.name,
    score: 0,
  }));
}

function normalizeGuessWord(value) {
  return value.replace(/[^a-z]/gi, "").toLowerCase().slice(0, 14);
}

function normalizeGuessLimit(value) {
  const parsed = Number.parseInt(value, 10);

  if (!Number.isFinite(parsed)) {
    return 6;
  }

  return Math.min(12, Math.max(1, parsed));
}

function updateGameStatus() {
  const targetLetters = new Set(state.game.targetWord.split(""));
  const guessed = new Set(state.game.guessedLetters);
  const wrongCount = state.game.guessedLetters.filter((letter) => !targetLetters.has(letter)).length;
  const isComplete = [...targetLetters].every((letter) => guessed.has(letter));

  if (isComplete) {
    state.game.status = "won";
    state.game.players[state.game.activePlayerIndex].score += 1;
    return;
  }

  if (wrongCount >= state.game.maxWrong) {
    state.game.status = "lost";
  }
}

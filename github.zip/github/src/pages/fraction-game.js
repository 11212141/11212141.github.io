import {
  buildFractionQuestion,
  createFractionQuestions,
  createFractionState,
  createRandomFractionQuestion,
  renderFractionAnswerNumber,
  renderFractionAnswerSummary,
  renderFractionPizza,
  renderFractionSameDenominatorGame,
} from "../components/fractionSameDenominatorGame.js?v=20260610-fraction-gameplay2";
import {
  createFractionExtraState,
  getFractionDenominatorQuestion,
  renderFractionDenominatorGames,
  resetMatchGame,
  resolveMatchFlip,
} from "../components/fractionDenominatorGames.js?v=20260610-fraction-gameplay2";
import { renderPageLead } from "../components/pageLead.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const questions = createFractionQuestions();
const state = {
  game: createFractionState(),
  extra: createFractionExtraState(),
};
const gameRoot = document.createElement("div");
const extraRoot = document.createElement("div");

renderShell();
renderGame();
renderExtraGames();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("fraction-game");

  renderPage({
    currentPageId: "fraction-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "fraction-top",
        eyebrow: "數學遊戲頁",
        title: "同分母分數",
        description: "",
        badge: "數學遊戲",
        stats: [
          { value: `${questions.length} 題`, label: "題目數" },
          { value: "圓餅", label: "圖像分數" },
          { value: "長條", label: "分量比較" },
        ],
        actions: [
          { label: "面積數格", href: "./area-grid-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([gameRoot, extraRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderFractionSameDenominatorGame({
      questions,
      state: state.game,
      onNext: () => {
        if (!state.game.isAnswered) return;
        if (state.game.roundIndex < questions.length - 1) {
          state.game.roundIndex += 1;
          state.game.selected = null;
          state.game.answerNumerator = 0;
          state.game.isAnswered = false;
          state.game.activeQuestion = null;
          state.game.missionIndex += 1;
        }
        renderGame();
      },
      onReset: () => {
        state.game = createFractionState();
        renderGame();
      },
      onSetVisual: (visual) => {
        state.game.visual = visual;
        gameRoot.querySelectorAll(".fraction-visual-toggle button").forEach((button) => {
          button.classList.toggle("is-active", button.dataset.visual === visual);
        });
        renderGame();
      },
      onSetCustomField: (field, value) => {
        state.game.custom[field] = field === "operator" ? value : Number(value);
      },
      onApplyCustom: () => {
        const customQuestion = buildFractionQuestion({
          id: "fraction-custom",
          title: "自訂題",
          denominator: state.game.custom.denominator,
          first: state.game.custom.first,
          second: state.game.custom.second,
          operator: state.game.custom.operator,
          optionSeed: Date.now(),
        });
        state.game.activeQuestion = customQuestion;
        state.game.custom = {
          denominator: customQuestion.denominator,
          first: customQuestion.first,
          second: customQuestion.second,
          operator: customQuestion.operator,
        };
        state.game.selected = null;
        state.game.answerNumerator = 0;
        state.game.isAnswered = false;
        state.game.missionIndex += 1;
        renderGame();
      },
      onRandomQuestion: () => {
        const randomQuestion = createRandomFractionQuestion(Date.now());
        state.game.activeQuestion = randomQuestion;
        state.game.custom = {
          denominator: randomQuestion.denominator,
          first: randomQuestion.first,
          second: randomQuestion.second,
          operator: randomQuestion.operator,
        };
        state.game.selected = null;
        state.game.answerNumerator = 0;
        state.game.isAnswered = false;
        state.game.missionIndex += 1;
        renderGame();
      },
      onAdjustAnswer: (delta) => {
        if (state.game.isAnswered) return;
        const max = getActiveQuestion().denominator * 2;
        state.game.answerNumerator = Math.min(max, Math.max(0, state.game.answerNumerator + delta));
        updatePizzaAnswer();
      },
      onSubmitPizzaAnswer: () => {
        if (state.game.isAnswered) return;
        state.game.selected = state.game.answerNumerator;
        state.game.isAnswered = true;
        if (state.game.answerNumerator === getActiveQuestion().answer) {
          state.game.streak += 1;
          state.game.score += state.game.streak >= 3 ? 2 : 1;
        } else {
          state.game.streak = 0;
        }
        renderGame();
      },
    }),
  );
}

function renderExtraGames() {
  extraRoot.replaceChildren(
    renderFractionDenominatorGames({
      state: state.extra,
      onChooseDenominator: (answer) => {
        if (state.extra.denominatorSelected !== null) return;
        const question = getDenominatorQuestion();
        state.extra.denominatorSelected = answer;
        if (answer === question.denominator) {
          state.extra.denominatorScore += 1;
        }
        renderExtraGames();
      },
      onNextDenominator: () => {
        state.extra.denominatorRound += 1;
        state.extra.denominatorSelected = null;
        renderExtraGames();
      },
      onSetCutDenominator: (value) => {
        state.extra.cutDenominator = value;
        renderExtraGames();
      },
      onFlipMatchCard: (index) => {
        state.extra = resolveMatchFlip(state.extra, index);
        renderExtraGames();
      },
      onResetMatch: () => {
        state.extra = resetMatchGame(state.extra);
        renderExtraGames();
      },
    }),
  );
}

function getActiveQuestion() {
  return state.game.activeQuestion ?? questions[state.game.roundIndex];
}

function getDenominatorQuestion() {
  return getFractionDenominatorQuestion(state.extra.denominatorRound);
}

function updatePizzaAnswer() {
  const question = getActiveQuestion();
  const numberRoot = gameRoot.querySelector("[data-fraction-answer-number]");
  const pizzaRoot = gameRoot.querySelector("[data-fraction-answer-pizza]");
  const summaryRoot = gameRoot.querySelector("[data-fraction-answer-summary]");

  numberRoot?.replaceChildren(renderFractionAnswerNumber(state.game.answerNumerator, question.denominator));
  pizzaRoot?.replaceChildren(renderFractionPizza(state.game.answerNumerator, question.denominator, true));
  summaryRoot?.replaceChildren(renderFractionAnswerSummary(state.game.answerNumerator, question.denominator));
}

import { renderPageLead } from "../components/pageLead.js?v=20260604-phonics-no-short2";
import { renderPhonicsGame } from "../components/phonicsGame.js?v=20260604-phonics-no-short2";
import { phonicsChallenge } from "../data/siteData.js?v=20260602-phonics-oo1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const state = {
  longShort: {
    index: 0,
    selected: "",
    answer: "",
    revealed: false,
  },
  longA: {
    patternId: phonicsChallenge.longAWorkshop.patterns[0].id,
    practiceMode: "front",
    wordIndexes: phonicsChallenge.longAWorkshop.patterns.reduce((indexes, pattern) => {
      indexes[`${pattern.id}-front`] = 0;
      indexes[`${pattern.id}-middle`] = 0;
      return indexes;
    }, {}),
    customLetters: phonicsChallenge.longAWorkshop.patterns.reduce((letters, pattern) => {
      letters[pattern.id] = getLongAParts(pattern, pattern.words[0]);
      return letters;
    }, {}),
  },
  freeBlend: {
    length: 3,
    activeSlot: 0,
    letters: ["b", "a", "t"],
  },
};

render();

function render() {
  const { actionText, actionHref } = getDefaultAction("phonics-game");

  renderPage({
    currentPageId: "phonics-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "phonics-top",
        eyebrow: "英文遊戲頁",
        title: "母音練習",
        description: "",
        badge: phonicsChallenge.badge,
        stats: [
          { value: "short / long", label: "長短音比較" },
          { value: "A E I O U OO", label: "長母音" },
          { value: "任二／任三", label: "自由拼音" },
        ],
        actions: [
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([
        renderPhonicsGame({
          challenge: phonicsChallenge,
          longShortState: state.longShort,
          longAState: state.longA,
          freeBlendState: state.freeBlend,
          onChooseLongShort: (choiceId) => {
            state.longShort.selected = choiceId;
            state.longShort.answer = "";
            state.longShort.revealed = false;
            render();
          },
          onRevealLongShort: (choiceId) => {
            if (!state.longShort.selected) {
              return;
            }

            state.longShort.answer = choiceId;
            state.longShort.revealed = true;
            render();
          },
          onNextLongShort: () => {
            state.longShort.index = (state.longShort.index + 1) % phonicsChallenge.longShortComparison.pairs.length;
            resetLongShort();
            render();
          },
          onResetLongShort: () => {
            resetLongShort();
            render();
          },
          onSelectLongAPattern: (patternId) => {
            state.longA.patternId = patternId;
            render();
          },
          onSetLongAPractice: (practiceMode) => {
            state.longA.practiceMode = practiceMode;
            render();
          },
          onUpdateLongACustom: (patternId, key, value) => {
            if (!state.longA.customLetters[patternId]) {
              state.longA.customLetters[patternId] = { before: "", middle: "", after: "" };
            }

            state.longA.customLetters[patternId][key] = normalizeLetterInput(value);
          },
          onNextLongAWord: () => {
            stepLongAWord(1);
            render();
          },
          onPreviousLongAWord: () => {
            stepLongAWord(-1);
            render();
          },
          onSetFreeBlendLength: (length) => {
            state.freeBlend.length = length;
            state.freeBlend.activeSlot = 1;
            render();
          },
          onSelectFreeBlendSlot: (slotIndex) => {
            state.freeBlend.activeSlot = slotIndex;
            render();
          },
          onChooseFreeBlendLetter: (letter) => {
            state.freeBlend.letters[state.freeBlend.activeSlot] = letter;
            render();
          },
          onClearFreeBlend: () => {
            state.freeBlend = {
              length: 3,
              activeSlot: 0,
              letters: ["b", "a", "t"],
            };
            render();
          },
        }),
      ]),
    ],
  });
}

function resetLongShort() {
  state.longShort.selected = "";
  state.longShort.answer = "";
  state.longShort.revealed = false;
}

function stepLongAWord(step) {
  const pattern = phonicsChallenge.longAWorkshop.patterns.find((item) => item.id === state.longA.patternId);

  if (!pattern) {
    return;
  }

  const practiceMode = state.longA.practiceMode ?? "front";
  const words = pattern.practice?.[practiceMode] ?? pattern.words;
  const indexKey = `${pattern.id}-${practiceMode}`;
  const currentIndex = state.longA.wordIndexes[indexKey] ?? 0;
  const nextIndex = (currentIndex + step + words.length) % words.length;
  state.longA.wordIndexes[indexKey] = nextIndex;
  state.longA.customLetters[pattern.id] = getLongAParts(pattern, words[nextIndex]);
}

function normalizeLetterInput(value) {
  return value.replace(/[^a-z]/gi, "").toLowerCase();
}

function getLongAParts(pattern, word) {
  if (isSplitVowelPattern(pattern.label)) {
    const [firstLetter, lastLetter] = pattern.label.split("_");
    const firstIndex = word.toLowerCase().indexOf(firstLetter);
    const lastIndex = word.toLowerCase().lastIndexOf(lastLetter);

    if (firstIndex === -1 || lastIndex === -1 || lastIndex <= firstIndex) {
      return { before: "", middle: "", after: "" };
    }

    return {
      before: word.slice(0, firstIndex),
      middle: word.slice(firstIndex + 1, lastIndex),
      after: word.slice(lastIndex + 1),
    };
  }

  const patternIndex = word.toLowerCase().indexOf(pattern.label);

  if (patternIndex === -1) {
    return { before: "", middle: "", after: "" };
  }

  return {
    before: word.slice(0, patternIndex),
    middle: "",
    after: word.slice(patternIndex + pattern.label.length),
  };
}

function isSplitVowelPattern(patternLabel) {
  return patternLabel.includes("_");
}

import {
  buildCustomAreaQuestion,
  buildRandomAreaQuestion,
  createAreaGridQuestions,
  createAreaGridState,
  renderAreaGridGame,
} from "../components/areaGridGame.js?v=20260610-area-connected-game1";
import { renderPageLead } from "../components/pageLead.js";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260618-name-settings2";

const questions = createAreaGridQuestions();
const state = {
  game: createAreaGridState(),
};
const gameRoot = document.createElement("div");

renderShell();
renderGame();

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("area-grid-game");

  renderPage({
    currentPageId: "area-grid-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "area-grid-top",
        eyebrow: "數學遊戲頁",
        title: "面積數格",
        description: "",
        badge: "數學遊戲",
        stats: [
          { value: `${questions.length} 題`, label: "題目數" },
          { value: "四方向", label: "半格" },
          { value: "不先公布", label: "答案" },
        ],
        actions: [
          { label: "同分母分數", href: "./fraction-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([gameRoot]),
    ],
  });
}

function renderGame() {
  gameRoot.replaceChildren(
    renderAreaGridGame({
      questions,
      state: state.game,
      onChoose: (answer) => {
        if (state.game.isAnswered) return;
        state.game.selected = answer;
        state.game.isAnswered = true;
        if (answer === getActiveQuestion().answer) {
          state.game.score += 1;
        }
        renderGame();
      },
      onNext: () => {
        if (!state.game.isAnswered) return;
        if (state.game.activeQuestion) {
          state.game.activeQuestion = null;
          state.game.selected = null;
          state.game.isAnswered = false;
        } else if (state.game.roundIndex < questions.length - 1) {
          state.game.roundIndex += 1;
          state.game.selected = null;
          state.game.isAnswered = false;
        }
        renderGame();
      },
      onReset: () => {
        state.game = createAreaGridState();
        renderGame();
      },
      onToggleCustomCell: (key, cellElement) => {
        const next = getCustomToolValue(state.game.customTool);
        if (next === 0) {
          delete state.game.customCells[key];
        } else {
          state.game.customCells[key] = next;
        }
        updateCustomCellElement(cellElement, next);
      },
      onApplyCustom: () => {
        state.game.activeQuestion = buildCustomAreaQuestion(state.game);
        state.game.selected = null;
        state.game.isAnswered = false;
        renderGame();
      },
      onClearCustom: () => {
        state.game.customCells = {};
        state.game.activeQuestion = null;
        state.game.selected = null;
        state.game.isAnswered = false;
        renderGame();
      },
      onRandomQuestion: () => {
        state.game.activeQuestion = buildRandomAreaQuestion(Date.now());
        state.game.selected = null;
        state.game.isAnswered = false;
        renderGame();
      },
      onSetCustomSize: (field, value) => {
        if (field === "rows") state.game.customRows = value;
        if (field === "cols") state.game.customCols = value;
        state.game.activeQuestion = null;
        renderGame();
      },
      onSetCustomTool: (tool, buttonElement) => {
        state.game.customTool = tool;
        gameRoot.querySelectorAll(".area-custom-tool").forEach((button) => {
          button.classList.toggle("is-active", button === buttonElement);
        });
      },
    }),
  );
}

function getActiveQuestion() {
  return state.game.activeQuestion ?? questions[state.game.roundIndex];
}

function getCustomToolValue(tool) {
  if (tool.startsWith("half-")) return tool;
  if (tool === "erase") return 0;
  return 1;
}

function updateCustomCellElement(cellElement, value) {
  if (!cellElement) return;
  ["is-half-tl", "is-half-tr", "is-half-br", "is-half-bl"].forEach((className) => {
    cellElement.classList.remove(className);
  });
  cellElement.classList.toggle("is-filled", value === 1);
  cellElement.classList.toggle("is-half", isHalfToolValue(value));
  if (value === "half-tr") cellElement.classList.add("is-half-tr");
  if (value === "half-br") cellElement.classList.add("is-half-br");
  if (value === "half-bl") cellElement.classList.add("is-half-bl");
  if (value === "half-tl" || value === 0.5) cellElement.classList.add("is-half-tl");
  const label = value === 1 ? "完整方格" : isHalfToolValue(value) ? "半格" : "空白方格";
  cellElement.setAttribute("aria-label", label);
}

function isHalfToolValue(value) {
  return value === 0.5 || String(value).startsWith("half-");
}

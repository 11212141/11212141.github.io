import {
  advanceDateFinanceTurn,
  answerDateFinanceQuestion,
  applyDateFinanceRoll,
  buildFinanceRecord,
  buildQuestion,
  createDateFinanceState,
  decideDateFinanceCard,
  renderDateFinanceGame,
} from "../components/dateFinanceGame.js?v=20260624-cashflow-teams1";
import { renderPageLead } from "../components/pageLead.js";
import { dateFinanceChallenge } from "../data/siteData.js?v=20260624-cashflow-teams1";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260624-menu-clean2";

const financeTeams = [
  { name: "依萱依辰隊", members: "王依萱、洪依辰" },
  { name: "昕哲維奕隊", members: "葉昕哲、阮維奕" },
  { name: "老師隊", members: "老師" },
];

let state = createDateFinanceState(dateFinanceChallenge, financeTeams);
const API_URL = "./api/finance-records";
const STATE_API_URL = "./api/finance-state";
let records = [];
let recordsStatus = "讀取中";
let stateStatus = "棋盤讀取中";
let interactionScroll = null;
let gameHost = null;
let hasMountedPage = false;

window.history.scrollRestoration = "manual";
document.addEventListener(
  "pointerdown",
  () => {
    interactionScroll = { x: window.scrollX, y: window.scrollY, time: Date.now() };
  },
  true,
);

render();
loadSavedState();
loadRecords();

function render({ preserveScroll = true } = {}) {
  const useInteractionScroll = interactionScroll && Date.now() - interactionScroll.time < 1200;
  const scrollX = useInteractionScroll ? interactionScroll.x : window.scrollX;
  const scrollY = useInteractionScroll ? interactionScroll.y : window.scrollY;
  const { actionText, actionHref } = getDefaultAction("date-finance-game");
  const gameElement = buildDateFinanceElement();

  if (hasMountedPage && gameHost) {
    gameHost.replaceChildren(gameElement);
    restorePageScroll({ preserveScroll, scrollX, scrollY });
    return;
  }

  const dashboard = mountDashboard([gameElement]);
  gameHost = dashboard.querySelector(".dashboard-grid__column");

  renderPage({
    currentPageId: "date-finance-game",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "date-finance-top",
        eyebrow: "活動遊戲頁",
        title: dateFinanceChallenge.title,
        description: "",
        badge: dateFinanceChallenge.badge,
        stats: [
          { value: "三隊", label: "分組對戰" },
          { value: "夢想", label: "目標鎖定" },
          { value: "現金流", label: "收入支出" },
        ],
        actions: [],
      }),
      dashboard,
    ],
  });
  hasMountedPage = true;

  restorePageScroll({ preserveScroll, scrollX, scrollY });
}

function restorePageScroll({ preserveScroll, scrollX, scrollY }) {
  if (!preserveScroll) return;

  const restoreScroll = () => {
    window.scrollTo(scrollX, scrollY);
  };

  window.requestAnimationFrame(restoreScroll);
  window.setTimeout(restoreScroll, 40);
  window.setTimeout(restoreScroll, 120);
}

function buildDateFinanceElement() {
  return renderDateFinanceGame({
    challenge: dateFinanceChallenge,
    state,
    stateStatus,
    onSetMonthDays: (monthDays) => {
      state = createDateFinanceState(dateFinanceChallenge, financeTeams);
      state.monthDays = monthDays;
      render();
      saveGameState();
    },
    onSetStartWeekday: (weekday) => {
      state = createDateFinanceState(dateFinanceChallenge, financeTeams);
      state.startWeekday = weekday;
      render();
      saveGameState();
    },
    onSetPlayerJob: (jobId) => {
      const player = state.players[state.activePlayerIndex];
      player.jobId = jobId;
      refreshCurrentQuestion();
      render();
      saveGameState();
    },
    onSetPlayerDream: (dreamId) => {
      const player = state.players[state.activePlayerIndex];
      player.dreamId = dreamId;
      recalculateDreamProgress(player);
      refreshCurrentQuestion();
      render();
      saveGameState();
    },
    onSelectPlayer: (playerIndex) => {
      state.activePlayerIndex = playerIndex;
      state.lastRoll = 0;
      state.isRolling = false;
      state.selectedAnswer = "";
      state.answered = false;
      state.result = null;
      state.currentQuestion = null;
      render();
      saveGameState();
    },
    onRollDice: () => {
      if (state.isRolling || state.lastRoll) {
        return;
      }

      state.isRolling = true;
      state.lastRoll = 0;
      render();

      const roll = Math.floor(Math.random() * 6) + 1;
      window.setTimeout(() => {
        state.isRolling = false;
        applyDateFinanceRoll(dateFinanceChallenge, state, roll);
        render();
        saveGameState();
      }, 780);
    },
    onChooseAnswer: (answer, currentQuestion) => {
      if (state.pendingCard) {
        return;
      }

      const player = state.players[state.activePlayerIndex];
      const question = currentQuestion ?? state.currentQuestion ?? buildQuestion(dateFinanceChallenge, state, player);
      answerDateFinanceQuestion(state, answer, question);
      render();
      saveGameState();
      saveRecord(buildFinanceRecord(dateFinanceChallenge, state, question));
    },
    onChooseCardDecision: (takeCard) => {
      decideDateFinanceCard(dateFinanceChallenge, state, takeCard);
      render();
      saveGameState();
    },
    onNextTurn: () => {
      if (state.pendingCard) {
        return;
      }

      advanceDateFinanceTurn(state);
      render();
      saveGameState();
    },
    onReset: () => {
    },
    onUpdatePlayerSetup: (playerIndex, patch) => {
      const player = state.players[playerIndex];
      if (!player || state.setupComplete) return;
      Object.assign(player, patch);
      recalculateDreamProgress(player);
      render();
      saveGameState();
    },
    onStartSetup: () => {
      state.setupComplete = true;
      state.activePlayerIndex = 0;
      state.players.forEach((player) => {
        player.name = player.name.trim() || "玩家";
        player.day = 1;
        player.money = dateFinanceChallenge.startMoney;
        player.saved = 0;
        player.assets = 0;
        player.passiveIncome = 0;
        player.dreamProgress = 0;
        player.stars = 0;
        player.streak = 0;
        player.badges = [];
        player.finished = false;
        player.correct = 0;
        player.log = [`${player.name} 建立角色，準備追夢`];
      });
      render();
      saveGameState();
    },
    onShowResetLock: () => {
      state.resetUnlocked = true;
      render();
    },
    onCancelResetLock: () => {
      state.resetUnlocked = false;
      render();
    },
    onSubmitResetPassword: (password) => {
      if (password !== "0000") {
        stateStatus = "密碼錯誤";
        render();
        return;
      }

      state = createDateFinanceState(dateFinanceChallenge, financeTeams);
      stateStatus = "已重新開始";
      render();
      saveGameState();
    },
  });
}

async function loadSavedState() {
  stateStatus = "棋盤讀取中";
  render();

  try {
    const response = await fetch(STATE_API_URL);
    if (!response.ok) {
      throw new Error("state load failed");
    }

    const data = await response.json();
    if (data.state) {
      state = normalizeSavedState(data.state);
      stateStatus = "已載入上次進度";
    } else {
      stateStatus = "新遊戲";
    }
  } catch (error) {
    stateStatus = "棋盤未連線";
  }

  render();
}

async function loadRecords() {
  recordsStatus = "讀取中";
  render();

  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error("load failed");
    }

    const data = await response.json();
    records = data.records ?? [];
    recordsStatus = `${records.length} 筆`;
  } catch (error) {
    recordsStatus = "資料庫未連線";
  }

  render();
}

async function saveRecord(record) {
  recordsStatus = "儲存中";

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(record),
    });

    if (!response.ok) {
      throw new Error("save failed");
    }

    const data = await response.json();
    records = [data.record, ...records].slice(0, 80);
    recordsStatus = `${records.length} 筆`;
  } catch (error) {
    recordsStatus = "儲存失敗";
  }
}

async function saveGameState() {
  stateStatus = "儲存棋盤中";

  try {
    const response = await fetch(STATE_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ state }),
    });

    if (!response.ok) {
      throw new Error("state save failed");
    }

    stateStatus = "棋盤已保存";
  } catch (error) {
    stateStatus = "棋盤保存失敗";
  }
}

async function deleteRecord(recordId) {
  recordsStatus = "刪除中";
  render();

  try {
    const response = await fetch(`${API_URL}/${recordId}`, { method: "DELETE" });
    if (!response.ok) {
      throw new Error("delete failed");
    }

    records = records.filter((record) => record.id !== recordId);
    recordsStatus = `${records.length} 筆`;
  } catch (error) {
    recordsStatus = "刪除失敗";
  }

  render();
}

function normalizeSavedState(savedState) {
  const fallback = createDateFinanceState(dateFinanceChallenge, financeTeams);
  if (savedState.gameVersion !== dateFinanceChallenge.version) {
    return fallback;
  }

  const players = Array.isArray(savedState.players) ? savedState.players : [];

  return {
    ...fallback,
    ...savedState,
    monthDays: dateFinanceChallenge.dayOptions.includes(Number(savedState.monthDays))
      ? Number(savedState.monthDays)
      : fallback.monthDays,
    startWeekday: Number.isInteger(savedState.startWeekday) && savedState.startWeekday >= 0 && savedState.startWeekday <= 6
      ? savedState.startWeekday
      : fallback.startWeekday,
    activePlayerIndex: Number.isInteger(savedState.activePlayerIndex)
      ? Math.min(Math.max(savedState.activePlayerIndex, 0), fallback.players.length - 1)
      : fallback.activePlayerIndex,
    isRolling: false,
    resetUnlocked: false,
    pendingCard: getSafePendingCard(savedState),
    currentQuestion: getSafeSavedQuestion(savedState),
    players: fallback.players.map((fallbackPlayer, index) => ({
      ...fallbackPlayer,
      ...(players[index] ?? {}),
      name: normalizePlayerName(players[index]?.name, fallbackPlayer.name),
      members: fallbackPlayer.members,
      avatarId: dateFinanceChallenge.avatarOptions.some((avatar) => avatar.id === players[index]?.avatarId)
        ? players[index].avatarId
        : fallbackPlayer.avatarId,
      assets: Number(players[index]?.assets ?? fallbackPlayer.assets ?? 0),
      passiveIncome: Number(players[index]?.passiveIncome ?? fallbackPlayer.passiveIncome ?? 0),
      dreamProgress: Number(players[index]?.dreamProgress ?? fallbackPlayer.dreamProgress ?? 0),
      stars: Number(players[index]?.stars ?? fallbackPlayer.stars ?? 0),
      streak: Number(players[index]?.streak ?? fallbackPlayer.streak ?? 0),
      badges: Array.isArray(players[index]?.badges) ? players[index].badges.slice(0, 4) : fallbackPlayer.badges,
      jobId: dateFinanceChallenge.jobs.some((job) => job.id === players[index]?.jobId)
        ? players[index].jobId
        : fallbackPlayer.jobId,
      dreamId: dateFinanceChallenge.dreams.some((dream) => dream.id === players[index]?.dreamId)
        ? players[index].dreamId
        : fallbackPlayer.dreamId,
      log: Array.isArray(players[index]?.log) ? players[index].log.slice(0, 4) : fallbackPlayer.log,
    })),
    setupComplete: Boolean(savedState.setupComplete),
  };
}

function normalizePlayerName(value, fallback) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, 8) : fallback;
}

function getSafePendingCard(savedState) {
  const card = savedState.pendingCard;

  if (!card || typeof card.title !== "string" || typeof card.text !== "string") {
    return null;
  }

  return card;
}

function getSafeSavedQuestion(savedState) {
  const question = savedState.lastRoll ? savedState.currentQuestion : null;

  if (!question || typeof question.prompt !== "string" || typeof question.answer !== "string" || !Array.isArray(question.options)) {
    return null;
  }

  return question.options.includes(question.answer) ? question : null;
}

function recalculateDreamProgress(player) {
  const dream = dateFinanceChallenge.dreams.find((item) => item.id === player.dreamId) ?? dateFinanceChallenge.dreams[0];
  const netWorth = player.money + player.saved + player.assets;
  const moneyProgress = Math.min(100, Math.round((netWorth / dream.moneyGoal) * 100));
  const passiveProgress = Math.min(100, Math.round((player.passiveIncome / dream.passiveGoal) * 100));
  player.dreamProgress = Math.min(100, Math.round((moneyProgress + passiveProgress) / 2));
}

function refreshCurrentQuestion() {
  if (!state.lastRoll || state.answered) {
    return;
  }

  const player = state.players[state.activePlayerIndex];
  state.currentQuestion = buildQuestion(dateFinanceChallenge, state, player);
}

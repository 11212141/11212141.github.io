import { renderDecimalIntroLesson } from "../components/decimalArithmeticGame.js?v=20260917-decimal-intro14";
import { renderPageLead } from "../components/pageLead.js";
import { studentProfiles } from "../data/siteData.js?v=20260917-decimal-intro14";
import { getDefaultAction, mountDashboard, renderPage } from "./shared.js?v=20260917-decimal-intro14";

const RECORDS_KEY = "aidigital-decimal-intro-records-v1";
const RECORDS_API = "./api/decimal-intro-records";
const POLL_INTERVAL_MS = 1500;

const state = {
  completed: 0,
  target: 5,
  round: createRound(),
  selectedDigit: null,
  buildDigits: ["", ""],
  isAnswered: false,
  lastResult: null,
  activeStudentId: studentProfiles[0]?.id ?? "student-guest",
  showDashboard: false,
  records: loadRecords(),
};

const lessonRoot = document.createElement("div");

renderShell();
renderLesson();
syncRecordsFromServer({ render: true });
window.setInterval(() => {
  if (state.showDashboard) syncRecordsFromServer({ render: true });
}, POLL_INTERVAL_MS);

function renderShell() {
  const { actionText, actionHref } = getDefaultAction("decimal-intro");

  renderPage({
    currentPageId: "decimal-intro",
    actionText,
    actionHref,
    children: [
      renderPageLead({
        id: "decimal-intro-top",
        eyebrow: "數學活動頁",
        title: "認識小數",
        description: "",
        badge: "數學活動",
        stats: [
          { value: "5 題", label: "完成目標" },
          { value: "隨機", label: "中文小數" },
          { value: "方格", label: "拖放操作" },
        ],
        actions: [
          { label: "小數加減", href: "./decimal-game.html", variant: "button--secondary" },
          { label: "回到活動總覽", href: "./index.html", variant: "button--primary" },
        ],
      }),
      mountDashboard([lessonRoot]),
    ],
  });
}

function renderLesson() {
  lessonRoot.replaceChildren(
    renderDecimalIntroLesson({
      lessonState: state,
      students: studentProfiles,
      records: state.records,
      activeStudentId: state.activeStudentId,
      showDashboard: state.showDashboard,
      onSelectDigit: (digit) => {
        state.selectedDigit = digit;
        updateDecimalIntroInteraction();
      },
      onSelectStudent: (studentId) => {
        state.activeStudentId = studentId;
        state.completed = 0;
        resetRoundOnly();
        renderLesson();
      },
      onToggleDashboard: () => {
        state.showDashboard = !state.showDashboard;
        if (state.showDashboard) syncRecordsFromServer({ render: true });
        renderLesson();
      },
      onClearRecords: () => {
        state.records = [];
        saveRecords();
        state.completed = 0;
        resetRoundOnly();
        clearServerRecords();
        renderLesson();
      },
      onPlaceDigit: (slotIndex, digit) => {
        state.buildDigits[slotIndex] = String(digit);
        state.selectedDigit = digit;
        state.lastResult = null;
        updateDecimalIntroInteraction();
      },
      onPlaceSelectedDigit: (slotIndex) => {
        if (!/^\d$/.test(String(state.selectedDigit))) return;
        state.buildDigits[slotIndex] = String(state.selectedDigit);
        state.lastResult = null;
        updateDecimalIntroInteraction();
      },
      onSubmitBuild: () => {
        if (state.isAnswered) return;
        const answer = state.buildDigits.join(".");
        const isCorrect = answer === state.round.value;
        recordAttempt({ answer, isCorrect });
        state.lastResult = isCorrect ? "correct" : "try-again";
        if (isCorrect) {
          state.completed += 1;
          state.isAnswered = true;
        }
        renderLesson();
      },
      onNextRound: () => {
        state.round = createRound();
        state.selectedDigit = null;
        state.buildDigits = ["", ""];
        state.isAnswered = false;
        state.lastResult = null;
        renderLesson();
      },
      onReset: () => {
        state.completed = 0;
        resetRoundOnly();
        renderLesson();
      },
    }),
  );
}

function updateDecimalIntroInteraction() {
  lessonRoot.querySelectorAll("[data-decimal-intro-digit]").forEach((button) => {
    const digit = Number(button.dataset.decimalIntroDigit);
    button.classList.toggle("is-selected", digit === state.selectedDigit);
  });

  lessonRoot.querySelectorAll("[data-decimal-build-slot]").forEach((slot) => {
    const slotIndex = Number(slot.dataset.decimalBuildSlot);
    const digit = state.buildDigits[slotIndex] || "";
    slot.textContent = digit || "□";
    slot.classList.toggle("is-filled", Boolean(digit));
  });

  const submitButton = lessonRoot.querySelector("[data-decimal-intro-submit]");
  if (submitButton) {
    submitButton.toggleAttribute("disabled", !state.buildDigits.every(Boolean) || state.isAnswered);
  }

  lessonRoot.querySelectorAll(".decimal-intro-feedback").forEach((feedback) => {
    feedback.textContent = " ";
    feedback.classList.remove("is-correct", "is-wrong");
  });
}

function createRound() {
  const ones = randomInt(0, 9);
  const tenths = randomInt(1, 9);
  return {
    type: "build",
    ones,
    tenths,
    value: `${ones}.${tenths}`,
    reading: `${toChineseDigit(ones)}點${toChineseDigit(tenths)}`,
  };
}

function resetRoundOnly() {
  state.round = createRound();
  state.selectedDigit = null;
  state.buildDigits = ["", ""];
  state.isAnswered = false;
  state.lastResult = null;
}

function recordAttempt({ answer, isCorrect }) {
  const student = studentProfiles.find((item) => item.id === state.activeStudentId) ?? studentProfiles[0];
  const record = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    studentId: state.activeStudentId,
    studentName: student?.name ?? "學生",
    prompt: state.round.reading,
    answer,
    correctAnswer: state.round.value,
    isCorrect,
    createdAt: new Date().toISOString(),
  };
  state.records = [
    ...state.records,
    record,
  ].slice(-240);
  saveRecords();
  postRecordToServer(record);
}

async function syncRecordsFromServer({ render = false } = {}) {
  try {
    const response = await fetch(RECORDS_API, { cache: "no-store" });
    if (!response.ok) return;
    const payload = await response.json();
    if (!Array.isArray(payload.records)) return;
    const nextRecords = payload.records.slice().reverse();
    if (JSON.stringify(nextRecords) === JSON.stringify(state.records)) return;
    state.records = nextRecords;
    saveRecords();
    if (render) renderLesson();
  } catch {
    // The page still works locally if the teacher opens it without the SQLite server.
  }
}

async function postRecordToServer(record) {
  try {
    const response = await fetch(RECORDS_API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(record),
    });
    if (!response.ok) return;
    syncRecordsFromServer({ render: state.showDashboard });
  } catch {
    // Keep the local optimistic record if the network is briefly unavailable.
  }
}

async function clearServerRecords() {
  try {
    await fetch(RECORDS_API, { method: "DELETE" });
  } catch {
    // Local clearing already happened; the next successful server sync will recover.
  }
}

function loadRecords() {
  try {
    const parsed = JSON.parse(localStorage.getItem(RECORDS_KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveRecords() {
  localStorage.setItem(RECORDS_KEY, JSON.stringify(state.records));
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function toChineseDigit(digit) {
  return ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"][digit] ?? String(digit);
}

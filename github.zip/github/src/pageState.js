import {
  activityModes,
  decimalArithmeticChallenge,
  divisionShareChallenge,
  mbtiQuestionSet,
  moduleTracks,
  moneyNumberChallenge,
  phonicsChallenge,
  studentProfiles,
} from "./data/siteData.js?v=20260527-money-ui2";

export function getActiveMode(modeId) {
  return activityModes.find((mode) => mode.id === modeId) ?? activityModes[0];
}

export function getModuleViews(modeId) {
  return moduleTracks.map((module) => resolveModule(module, modeId));
}

export function getActiveModule(modeId, moduleId) {
  const modules = getModuleViews(modeId);
  return modules.find((module) => module.id === moduleId) ?? modules[0];
}

export function createPhonicsGameState() {
  return {
    activePlayerIndex: 0,
    roundIndex: 0,
    isAnswered: false,
    selectedChoiceId: "",
    teacherChoiceId: "",
    finished: false,
    lastResult: null,
    totalRounds: phonicsChallenge.rounds.length,
    players: createPlayers(),
  };
}

export function createMbtiState() {
  return {
    questionIndex: 0,
    completed: false,
    resultType: "",
    activeTypeId: "",
    totalQuestions: mbtiQuestionSet.questions.length,
    answers: [],
    scores: {
      E: 0,
      I: 0,
      S: 0,
      N: 0,
      T: 0,
      F: 0,
      J: 0,
      P: 0,
    },
  };
}

export function createMoneyGameState() {
  return {
    activePlayerIndex: 0,
    roundIndex: 0,
    finished: false,
    solved: false,
    showTarget: false,
    totalRounds: moneyNumberChallenge.rounds.length,
    selectedValues: [],
    lastResult: null,
    players: createPlayers(),
  };
}

export function createEnglishNumberGameState(rounds) {
  return {
    activePlayerIndex: 0,
    roundIndex: 0,
    totalRounds: rounds.length,
    selectedAnswer: null,
    isAnswered: false,
    finished: false,
    lastResult: null,
    processStep: null,
    players: createPlayers(),
  };
}

export function createDecimalGameState() {
  const mode = "challenge";
  return {
    mode,
    activePlayerIndex: 0,
    roundIndex: 0,
    totalRounds: decimalArithmeticChallenge.rounds.length,
    verticalDigits: createDecimalDigitsForMode(decimalArithmeticChallenge.rounds[0], mode),
    activeVerticalSlot: getDefaultDecimalSlot(mode),
    isAnswered: false,
    finished: false,
    lastResult: null,
    processStep: null,
    players: createPlayers(),
  };
}

export function answerMbtiQuestion(mbtiState, question, optionId) {
  if (mbtiState.completed) {
    return;
  }

  const option = question.options.find((choice) => choice.id === optionId);

  if (!option) {
    return;
  }

  mbtiState.answers.push({
    questionId: question.id,
    optionId,
    pole: option.pole,
  });
  mbtiState.scores[option.pole] += 1;

  if (mbtiState.questionIndex >= mbtiState.totalQuestions - 1) {
    mbtiState.completed = true;
    mbtiState.resultType = resolveMbtiType(mbtiState.scores);
    mbtiState.activeTypeId = mbtiState.resultType;
    return;
  }

  mbtiState.questionIndex += 1;
}

export function setActiveMbtiType(mbtiState, typeId) {
  mbtiState.activeTypeId = typeId;
}

export function addMoneyValue(gameState, value) {
  if (gameState.finished || gameState.solved) {
    return;
  }

  gameState.selectedValues.push(value);
  gameState.lastResult = null;
}

export function removeMoneyValue(gameState) {
  if (gameState.finished || gameState.solved || gameState.selectedValues.length === 0) {
    return;
  }

  gameState.selectedValues.pop();
  gameState.lastResult = null;
}

export function clearMoneyValues(gameState) {
  if (gameState.finished || gameState.solved) {
    return;
  }

  gameState.selectedValues = [];
  gameState.lastResult = null;
}

export function submitMoneyRound(gameState) {
  if (gameState.finished || gameState.solved) {
    return;
  }

  const round = moneyNumberChallenge.rounds[gameState.roundIndex];
  const total = gameState.selectedValues.reduce((sum, value) => sum + value, 0);
  const difference = round.target - total;

  if (difference === 0) {
    gameState.solved = true;
    gameState.lastResult = { isCorrect: true, total, difference: 0 };
    gameState.players[gameState.activePlayerIndex].score += 1;
    return;
  }

  gameState.lastResult = { isCorrect: false, total, difference };
}

export function advanceMoneyRound(gameState) {
  if (gameState.finished || !gameState.solved) {
    return;
  }

  if (gameState.roundIndex >= gameState.totalRounds - 1) {
    gameState.finished = true;
    return;
  }

  gameState.roundIndex += 1;
  gameState.activePlayerIndex = (gameState.activePlayerIndex + 1) % gameState.players.length;
  resetMoneyRoundState(gameState);
}

export function toggleMoneyTarget(gameState) {
  if (gameState.finished) {
    return;
  }

  gameState.showTarget = !gameState.showTarget;
}

export function chooseEnglishNumberAnswer(gameState, rounds, value) {
  if (gameState.finished || gameState.isAnswered) {
    return;
  }

  const round = rounds[gameState.roundIndex];
  const isCorrect = value === round.answer;

  gameState.selectedAnswer = value;
  gameState.isAnswered = true;
  gameState.lastResult = {
    isCorrect,
    selectedAnswer: value,
    answer: round.answer,
  };

  if (isCorrect && gameState.mode === "challenge") {
    gameState.players[gameState.activePlayerIndex].score += 1;
  }
}

export function advanceEnglishNumberRound(gameState) {
  if (gameState.finished || !gameState.isAnswered) {
    return;
  }

  if (gameState.roundIndex >= gameState.totalRounds - 1) {
    gameState.finished = true;
    return;
  }

  gameState.roundIndex += 1;
  gameState.activePlayerIndex = (gameState.activePlayerIndex + 1) % gameState.players.length;
  resetEnglishNumberRoundState(gameState);
}

export function setDecimalAnswerSlot(gameState, slotIndex) {
  if (gameState.finished || gameState.isAnswered || slotIndex < 0 || slotIndex > 5) {
    return;
  }

  if (gameState.mode === "challenge" && slotIndex < 4) {
    return;
  }

  gameState.activeVerticalSlot = slotIndex;
}

export function chooseDecimalDigit(gameState, digit) {
  if (gameState.finished || gameState.isAnswered) {
    return;
  }

  gameState.verticalDigits[gameState.activeVerticalSlot] = String(digit);
  gameState.activeVerticalSlot = getNextDecimalSlot(gameState);
  gameState.lastResult = null;
}

export function clearDecimalDigits(gameState) {
  if (gameState.finished || gameState.isAnswered) {
    return;
  }

  const round = decimalArithmeticChallenge.rounds[gameState.roundIndex];
  gameState.verticalDigits = createDecimalDigitsForMode(round, gameState.mode);
  gameState.activeVerticalSlot = getDefaultDecimalSlot(gameState.mode);
  gameState.lastResult = null;
}

export function submitDecimalAnswer(gameState) {
  if (gameState.finished || gameState.isAnswered || !isDecimalReadyToSubmit(gameState)) {
    return;
  }

  const round = decimalArithmeticChallenge.rounds[gameState.roundIndex];
  const expectedDigits = getDecimalVerticalDigits(round);
  const isCorrect =
    gameState.mode === "free"
      ? true
      : gameState.verticalDigits[4] === expectedDigits[4] && gameState.verticalDigits[5] === expectedDigits[5];
  const value = `${gameState.verticalDigits[4]}.${gameState.verticalDigits[5]}`;

  gameState.isAnswered = true;
  gameState.lastResult = {
    isCorrect,
    selectedAnswer: value,
    answer: round.answer,
  };

  if (isCorrect) {
    gameState.players[gameState.activePlayerIndex].score += 1;
  }
}

export function setDecimalMode(gameState, mode) {
  if (!["challenge", "free"].includes(mode)) {
    return;
  }

  gameState.mode = mode;
  gameState.roundIndex = 0;
  gameState.activePlayerIndex = 0;
  gameState.finished = false;
  gameState.players = createPlayers();
  resetDecimalRoundState(gameState);
}

export function advanceDecimalRound(gameState) {
  if (gameState.finished || !gameState.isAnswered) {
    return;
  }

  moveToNextDecimalRound(gameState);
}

export function skipDecimalRound(gameState) {
  if (gameState.finished) {
    return;
  }

  moveToNextDecimalRound(gameState);
}

function moveToNextDecimalRound(gameState) {
  if (gameState.roundIndex >= gameState.totalRounds - 1) {
    gameState.finished = true;
    return;
  }

  gameState.roundIndex += 1;
  gameState.activePlayerIndex = (gameState.activePlayerIndex + 1) % gameState.players.length;
  resetDecimalRoundState(gameState);
}

export function createDivisionGameState() {
  const firstRound = divisionShareChallenge.rounds[0];

  return {
    activePlayerIndex: 0,
    roundIndex: 0,
    finished: false,
    solved: false,
    totalRounds: divisionShareChallenge.rounds.length,
    predictedPerGroup: null,
    allocations: Array(firstRound.groups).fill(0),
    remaining: firstRound.total,
    moveHistory: [],
    lastResult: null,
    players: createPlayers(),
  };
}

export function setDivisionPrediction(gameState, value) {
  if (gameState.finished || gameState.solved) {
    return;
  }

  gameState.predictedPerGroup = value;
  gameState.lastResult = null;
}

export function placeDivisionItem(gameState, basketIndex) {
  if (gameState.finished || gameState.solved || gameState.remaining <= 0 || gameState.predictedPerGroup === null) {
    return;
  }

  if (basketIndex < 0 || basketIndex >= gameState.allocations.length) {
    return;
  }

  gameState.allocations[basketIndex] += 1;
  gameState.remaining -= 1;
  gameState.moveHistory.push(basketIndex);
  gameState.lastResult = null;
}

export function shareDivisionCycle(gameState) {
  if (gameState.finished || gameState.solved || gameState.remaining <= 0 || gameState.predictedPerGroup === null) {
    return;
  }

  for (let index = 0; index < gameState.allocations.length && gameState.remaining > 0; index += 1) {
    placeDivisionItem(gameState, index);
  }
}

export function undoDivisionMove(gameState) {
  if (gameState.finished || gameState.solved || gameState.moveHistory.length === 0) {
    return;
  }

  const basketIndex = gameState.moveHistory.pop();
  gameState.allocations[basketIndex] -= 1;
  gameState.remaining += 1;
  gameState.lastResult = null;
}

export function resetDivisionRound(gameState) {
  if (gameState.finished) {
    return;
  }

  const round = divisionShareChallenge.rounds[gameState.roundIndex];
  gameState.allocations = Array(round.groups).fill(0);
  gameState.remaining = round.total;
  gameState.predictedPerGroup = null;
  gameState.moveHistory = [];
  gameState.solved = false;
  gameState.lastResult = null;
}

export function submitDivisionRound(gameState) {
  if (gameState.finished || gameState.solved) {
    return;
  }

  const round = divisionShareChallenge.rounds[gameState.roundIndex];

  if (gameState.remaining > 0) {
    gameState.lastResult = {
      isCorrect: false,
      reason: "remaining",
      remaining: gameState.remaining,
      expected: round.targetPerGroup,
    };
    return;
  }

  const isCorrect = gameState.allocations.every((count) => count === round.targetPerGroup);

  if (isCorrect) {
    gameState.solved = true;
    gameState.lastResult = {
      isCorrect: true,
      expected: round.targetPerGroup,
      predictedPerGroup: gameState.predictedPerGroup,
    };
    gameState.players[gameState.activePlayerIndex].score += 1;
    return;
  }

  gameState.lastResult = {
    isCorrect: false,
    reason: "uneven",
    expected: round.targetPerGroup,
    predictedPerGroup: gameState.predictedPerGroup,
  };
}

export function advanceDivisionRound(gameState) {
  if (gameState.finished || !gameState.solved) {
    return;
  }

  if (gameState.roundIndex >= gameState.totalRounds - 1) {
    gameState.finished = true;
    return;
  }

  gameState.roundIndex += 1;
  gameState.activePlayerIndex = (gameState.activePlayerIndex + 1) % gameState.players.length;
  resetDivisionRound(gameState);
}

export function handlePhonicsChoice(gameState, choiceId) {
  if (gameState.finished || gameState.isAnswered || !findPhonicsChoice(choiceId)) {
    return;
  }

  gameState.selectedChoiceId = choiceId;
  gameState.lastResult = null;
}

export function revealPhonicsAnswer(gameState, choiceId) {
  if (
    gameState.finished ||
    gameState.isAnswered ||
    !gameState.selectedChoiceId ||
    !findPhonicsChoice(choiceId)
  ) {
    return;
  }

  const isCorrect = choiceId === gameState.selectedChoiceId;

  gameState.teacherChoiceId = choiceId;
  gameState.isAnswered = true;
  gameState.lastResult = {
    isCorrect,
    playerId: gameState.players[gameState.activePlayerIndex].id,
    correctChoiceId: choiceId,
    selectedChoiceId: gameState.selectedChoiceId,
  };

  if (isCorrect) {
    gameState.players[gameState.activePlayerIndex].score += 1;
  }
}

export function resetPhonicsSelection(gameState) {
  if (gameState.finished || gameState.isAnswered) {
    return;
  }

  gameState.selectedChoiceId = "";
  gameState.lastResult = null;
}

export function advancePhonicsRound(gameState) {
  if (gameState.finished || !gameState.isAnswered) {
    return;
  }

  if (gameState.roundIndex >= gameState.totalRounds - 1) {
    gameState.finished = true;
    return;
  }

  gameState.roundIndex += 1;
  gameState.activePlayerIndex = (gameState.activePlayerIndex + 1) % gameState.players.length;
  gameState.isAnswered = false;
  gameState.selectedChoiceId = "";
  gameState.teacherChoiceId = "";
  gameState.lastResult = null;
}

function resolveModule(module, modeId) {
  const modeDetail = module.modes[modeId] ?? module.modes.gentle;

  return {
    id: module.id,
    index: module.index,
    name: module.name,
    phase: module.phase,
    summary: module.summary,
    liveWindow: module.liveWindow,
    tools: module.tools,
    checkpoints: module.checkpoints,
    liveTopic: modeDetail.liveTopic,
    mentorPrompt: modeDetail.mentorPrompt,
  };
}

function createPlayers() {
  return studentProfiles.slice(0, 4).map((student) => ({
    id: student.id,
    name: student.name,
    score: 0,
  }));
}

function findPhonicsChoice(choiceId) {
  return phonicsChallenge.answerChoices.find((choice) => choice.id === choiceId);
}

function resolveMbtiType(scores) {
  return [
    scores.E > scores.I ? "E" : "I",
    scores.S > scores.N ? "S" : "N",
    scores.T > scores.F ? "T" : "F",
    scores.J > scores.P ? "J" : "P",
  ].join("");
}

function resetMoneyRoundState(gameState) {
  gameState.selectedValues = [];
  gameState.solved = false;
  gameState.showTarget = false;
  gameState.lastResult = null;
}

function resetEnglishNumberRoundState(gameState) {
  gameState.selectedAnswer = null;
  gameState.isAnswered = false;
  gameState.lastResult = null;
}

function resetDecimalRoundState(gameState) {
  const round = decimalArithmeticChallenge.rounds[gameState.roundIndex];
  gameState.verticalDigits = createDecimalDigitsForMode(round, gameState.mode);
  gameState.activeVerticalSlot = getDefaultDecimalSlot(gameState.mode);
  gameState.isAnswered = false;
  gameState.lastResult = null;
  gameState.processStep = null;
}

function createDecimalDigitsForMode(round, mode) {
  if (mode === "challenge") {
    const [topOnes, topTenths, bottomOnes, bottomTenths] = getDecimalVerticalDigits(round);
    return [topOnes, topTenths, bottomOnes, bottomTenths, "", ""];
  }

  return ["", "", "", "", "", ""];
}

function getDefaultDecimalSlot(mode) {
  return mode === "challenge" ? 4 : 0;
}

function getNextDecimalSlot(gameState) {
  if (gameState.mode === "challenge") {
    return gameState.activeVerticalSlot === 4 ? 5 : 4;
  }

  return (gameState.activeVerticalSlot + 1) % gameState.verticalDigits.length;
}

function isDecimalReadyToSubmit(gameState) {
  if (gameState.mode === "challenge") {
    return gameState.verticalDigits[4] !== "" && gameState.verticalDigits[5] !== "";
  }

  return gameState.verticalDigits.every((digit) => digit !== "");
}

function getDecimalVerticalDigits(round) {
  return [...getDecimalPair(round.top), ...getDecimalPair(round.bottom), ...getDecimalPair(round.answer)];
}

function getDecimalPair(value) {
  const [integerPart, decimalPart = "0"] = String(value).split(".");
  return [integerPart, decimalPart[0] ?? "0"];
}

import { colorLearningChallenge, studentProfiles } from "../data/siteData.js?v=20260424-color-mix9";

export function createColorListenGameState() {
  return {
    roundIndex: 0,
    totalRounds: colorLearningChallenge.listenGame.rounds,
    activePlayerIndex: 0,
    selectedColorId: "",
    teacherColorId: "",
    isAnswered: false,
    lastResult: null,
    finished: false,
    players: createPlayers(),
  };
}

export function createColorEnglishGameState() {
  const rounds = shuffleIds(colorLearningChallenge.palette.map((color) => color.id)).slice(
    0,
    colorLearningChallenge.englishGame.rounds,
  );

  return {
    roundIndex: 0,
    totalRounds: rounds.length,
    activePlayerIndex: 0,
    rounds,
    optionsByRound: rounds.map((colorId) => buildOptionsForTarget(colorId).map((color) => color.id)),
    selectedColorId: "",
    isAnswered: false,
    lastResult: null,
    finished: false,
    players: createPlayers(),
  };
}

export function chooseListenColor(gameState, colorId) {
  if (gameState.finished || gameState.isAnswered || !findPaletteColor(colorId)) {
    return;
  }

  gameState.selectedColorId = colorId;
  gameState.lastResult = null;
}

export function revealListenColor(gameState, colorId) {
  if (
    gameState.finished ||
    gameState.isAnswered ||
    !gameState.selectedColorId ||
    !findPaletteColor(colorId)
  ) {
    return;
  }

  const isCorrect = colorId === gameState.selectedColorId;

  gameState.teacherColorId = colorId;
  gameState.isAnswered = true;
  gameState.lastResult = {
    isCorrect,
    targetColorId: colorId,
    selectedColorId: gameState.selectedColorId,
  };

  if (isCorrect) {
    gameState.players[gameState.activePlayerIndex].score += 1;
  }
}

export function chooseEnglishColor(gameState, colorId) {
  if (gameState.finished || gameState.isAnswered || !findPaletteColor(colorId)) {
    return;
  }

  const targetColorId = gameState.rounds[gameState.roundIndex];
  const isCorrect = colorId === targetColorId;

  gameState.selectedColorId = colorId;
  gameState.isAnswered = true;
  gameState.lastResult = {
    isCorrect,
    targetColorId,
    selectedColorId: colorId,
  };

  if (isCorrect) {
    gameState.players[gameState.activePlayerIndex].score += 1;
  }
}

export function nextColorListenRound(gameState) {
  advanceRound(gameState);
}

export function nextColorEnglishRound(gameState) {
  advanceRound(gameState);
}

export function buildEnglishOptions(gameState) {
  const targetColorId = gameState.rounds[gameState.roundIndex];
  const optionIds = gameState.optionsByRound?.[gameState.roundIndex] ?? [];

  return optionIds
    .map((colorId) => findPaletteColor(colorId))
    .filter(Boolean);
}

export function getColorRoundTarget(gameState) {
  if (!gameState.rounds?.length) {
    return null;
  }

  return findPaletteColor(gameState.rounds[gameState.roundIndex]) ?? null;
}

function advanceRound(gameState) {
  if (gameState.finished || !gameState.isAnswered) {
    return;
  }

  if (gameState.roundIndex >= gameState.totalRounds - 1) {
    gameState.finished = true;
    return;
  }

  gameState.roundIndex += 1;
  gameState.activePlayerIndex = (gameState.activePlayerIndex + 1) % gameState.players.length;
  gameState.selectedColorId = "";
  gameState.teacherColorId = "";
  gameState.isAnswered = false;
  gameState.lastResult = null;
}

function createPlayers() {
  return studentProfiles.slice(0, 4).map((student) => ({
    id: student.id,
    name: student.name,
    score: 0,
  }));
}

function findPaletteColor(colorId) {
  return colorLearningChallenge.palette.find((color) => color.id === colorId);
}

function buildOptionsForTarget(targetColorId) {
  const targetColor = findPaletteColor(targetColorId);

  if (!targetColor) {
    return [];
  }

  const distractors = shuffleColors(
    colorLearningChallenge.palette.filter((color) => color.id !== targetColorId),
  ).slice(0, Math.max(0, colorLearningChallenge.englishGame.optionsPerRound - 1));

  return shuffleColors([targetColor, ...distractors]);
}

function shuffleIds(list) {
  const next = [...list];

  for (let index = next.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [next[index], next[swapIndex]] = [next[swapIndex], next[index]];
  }

  return next;
}

function shuffleColors(list) {
  return shuffleIds(list).map((item) => item);
}

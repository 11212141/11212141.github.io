export function el(
  tag,
  { className, text, html, attrs = {}, dataset = {}, children = [], on = {} } = {},
) {
  const node = document.createElement(tag);

  if (className) {
    node.className = className;
  }

  if (text !== undefined) {
    node.textContent = text;
  }

  if (html !== undefined) {
    node.innerHTML = html;
  }

  Object.entries(attrs).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      node.setAttribute(key, value);
    }
  });

  Object.entries(dataset).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      node.dataset[key] = value;
    }
  });

  Object.entries(on).forEach(([event, handler]) => {
    node.addEventListener(event, handler);
  });

  children.forEach((child) => {
    if (child) {
      node.append(child);
    }
  });

  return node;
}

export function sectionTitle(title, description, trailing) {
  const heading = el("div", {
    className: "section-title",
    children: [
      el("div", {
        children: [el("h2", { text: title }), description ? el("p", { text: description }) : null],
      }),
      trailing ?? null,
    ],
  });

  return heading;
}

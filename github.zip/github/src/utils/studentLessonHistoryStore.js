const STORAGE_KEY = "aidigital-student-history-v1";
const LEGACY_KEY = "aidigital-student-status-v1";

function readAllHistory() {
  if (typeof localStorage === "undefined") {
    return {};
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }

    const legacyRaw = localStorage.getItem(LEGACY_KEY);
    if (!legacyRaw) {
      return {};
    }

    const legacy = JSON.parse(legacyRaw);
    const migrated = Object.fromEntries(
      Object.entries(legacy).map(([studentId, status]) => [
        studentId,
        status.note || status.reminder || status.lessonState || status.participation
          ? [
              {
                id: `${studentId}-legacy`,
                date: extractDate(status.updatedAt),
                subject: "其他",
                lessonState: status.lessonState ?? "",
                note: status.note ?? "",
                reminder: status.reminder ?? "",
                createdAt: status.updatedAt ?? "",
              },
            ]
          : [],
      ]),
    );

    writeAllHistory(migrated);
    return migrated;
  } catch {
    return {};
  }
}

function writeAllHistory(records) {
  if (typeof localStorage === "undefined") {
    return;
  }

  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

export function getStudentLessonHistory(studentId) {
  const records = readAllHistory();
  return records[studentId] ?? [];
}

export function addStudentLessonRecord(studentId, record) {
  const records = readAllHistory();
  const currentRecords = records[studentId] ?? [];

  records[studentId] = [
    {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      ...record,
    },
    ...currentRecords,
  ];

  writeAllHistory(records);
}

function extractDate(timestamp) {
  if (!timestamp) {
    return "";
  }

  const normalized = timestamp.replace(/\//g, "-");
  const matched = normalized.match(/\d{4}-\d{2}-\d{2}/);
  return matched ? matched[0] : "";
}

import { colorMixLabChallenge, studentProfiles } from "../data/siteData.js?v=20260424-color-mix9";

export function createColorMixGameState() {
  return {
    roundNumber: 1,
    pickerOneIndex: 0,
    pickerTwoIndex: 1,
    answererIndex: 2,
    pickerOneColorId: "",
    pickerTwoColorId: "",
    answerChoiceId: "",
    lastResult: null,
    players: studentProfiles.slice(0, 4).map((student) => ({
      id: student.id,
      name: student.name,
      score: 0,
    })),
  };
}

export function selectColorMixRole(state, role, playerIndex) {
  if (playerIndex < 0 || playerIndex >= state.players.length) {
    return;
  }

  if (role === "pickerOne" && playerIndex === state.pickerTwoIndex) {
    return;
  }

  if (role === "pickerTwo" && playerIndex === state.pickerOneIndex) {
    return;
  }

  state[`${role}Index`] = playerIndex;
}

export function chooseColorMixPrimary(state, role, colorId) {
  if (!findColor(colorId)) {
    return;
  }

  state[`${role}ColorId`] = colorId;
  state.answerChoiceId = "";
  state.lastResult = null;
}

export function submitColorMixAnswer(state, answerId) {
  const mixedColorId = getMixedColorId(state);

  if (!mixedColorId || !findAnswer(answerId) || state.lastResult) {
    return;
  }

  const isCorrect = answerId === mixedColorId;
  state.answerChoiceId = answerId;
  state.lastResult = {
    isCorrect,
    mixedColorId,
    answerId,
  };

  if (isCorrect) {
    state.players[state.answererIndex].score += 1;
  }
}

export function nextColorMixRound(state) {
  state.roundNumber += 1;
  state.pickerOneColorId = "";
  state.pickerTwoColorId = "";
  state.answerChoiceId = "";
  state.lastResult = null;
}

export function getMixedColor(state) {
  const mixedColorId = getMixedColorId(state);

  return colorMixLabChallenge.answerColors.find((color) => color.id === mixedColorId) ?? null;
}

function getMixedColorId(state) {
  if (!state.pickerOneColorId || !state.pickerTwoColorId) {
    return "";
  }

  const key = [state.pickerOneColorId, state.pickerTwoColorId].sort().join("+");
  return colorMixLabChallenge.mixes[key] ?? "";
}

function findColor(colorId) {
  return colorMixLabChallenge.primaryColors.find((color) => color.id === colorId);
}

function findAnswer(colorId) {
  return colorMixLabChallenge.answerColors.find((color) => color.id === colorId);
}

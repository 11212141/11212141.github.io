import { mbtiQuickQuiz, studentProfiles } from "../data/siteData.js?v=20260424-mbti-quiz4";

export function createMbtiQuizState() {
  return {
    activePlayerIndex: 0,
    activeTypeId: "INFP",
    players: studentProfiles.slice(0, 4).map((student) => ({
      id: student.id,
      name: student.name,
      answers: {},
      completed: false,
      resultType: "",
    })),
  };
}

export function selectMbtiQuizPlayer(state, playerIndex) {
  if (playerIndex < 0 || playerIndex >= state.players.length) {
    return;
  }

  state.activePlayerIndex = playerIndex;

  const player = state.players[playerIndex];

  if (player.resultType) {
    state.activeTypeId = player.resultType;
  }
}

export function answerMbtiQuizQuestion(state, questionId, optionId) {
  const player = state.players[state.activePlayerIndex];
  const question = mbtiQuickQuiz.questions.find((item) => item.id === questionId);

  if (!player || !question) {
    return;
  }

  const option = question.options.find((item) => item.id === optionId);

  if (!option) {
    return;
  }

  player.answers[question.id] = option.id;
  player.completed = mbtiQuickQuiz.questions.every((item) => player.answers[item.id]);

  if (player.completed) {
    player.resultType = mbtiQuickQuiz.questions.map((item) => player.answers[item.id]).join("");
    state.activeTypeId = player.resultType;
  }
}

export function resetMbtiQuizPlayer(state, playerIndex) {
  const player = state.players[playerIndex];

  if (!player) {
    return;
  }

  player.answers = {};
  player.completed = false;
  player.resultType = "";
}

export function setMbtiQuizActiveType(state, typeId) {
  state.activeTypeId = typeId;
}

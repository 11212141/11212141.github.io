import { studentProfiles } from "../data/siteData.js?v=20260624-menu-clean2";

const STORAGE_KEY = "aidigital-show-student-names";

const aliases = studentProfiles.slice(0, 4).map((student, index) => ({
  name: student.name,
  initial: student.name.slice(0, 1),
  mask: `學生${String.fromCharCode(65 + index)}`,
  shortMask: String.fromCharCode(65 + index),
}));

let observer = null;
let isApplying = false;

export function areStudentNamesVisible() {
  return localStorage.getItem(STORAGE_KEY) !== "false";
}

export function setStudentNamesVisible(isVisible) {
  localStorage.setItem(STORAGE_KEY, String(isVisible));
  applyNameVisibility(document.body);
  window.dispatchEvent(new CustomEvent("aidigital-name-visibility-change", { detail: { isVisible } }));
}

export function getNameVisibilityRows() {
  return aliases.map((item) => ({ ...item }));
}

export function installNameVisibilityObserver() {
  if (observer) return;

  observer = new MutationObserver((mutations) => {
    if (isApplying) return;
    for (const mutation of mutations) {
      if (mutation.type === "childList") {
        mutation.addedNodes.forEach((node) => applyNameVisibility(node));
      }
      if (mutation.type === "characterData") {
        applyNameVisibility(mutation.target);
      }
      if (mutation.type === "attributes") {
        applyElementAttributes(mutation.target);
      }
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true,
    attributeFilter: ["title", "aria-label", "placeholder"],
  });
}

export function applyNameVisibility(root = document.body) {
  if (!root) return;

  isApplying = true;
  try {
    if (root.nodeType === Node.TEXT_NODE) {
      applyTextNode(root);
      return;
    }

    if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) return;

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        return shouldSkipNode(node.parentElement) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
      },
    });

    let node = walker.nextNode();
    while (node) {
      applyTextNode(node);
      node = walker.nextNode();
    }

    if (root.nodeType === Node.ELEMENT_NODE) {
      applyElementAttributes(root);
      root.querySelectorAll("[title], [aria-label], [placeholder]").forEach(applyElementAttributes);
    }
  } finally {
    isApplying = false;
  }
}

function applyTextNode(node) {
  if (!node || shouldSkipNode(node.parentElement)) return;

  if (node.__aidigitalOriginalText === undefined) {
    node.__aidigitalOriginalText = node.nodeValue;
  }

  const original = node.__aidigitalOriginalText;
  const nextValue = areStudentNamesVisible() ? original : maskText(original);
  if (node.nodeValue !== nextValue) {
    node.nodeValue = nextValue;
  }
}

function applyElementAttributes(element) {
  if (!element || element.nodeType !== Node.ELEMENT_NODE || shouldSkipNode(element)) return;

  ["title", "aria-label", "placeholder"].forEach((attr) => {
    if (!element.hasAttribute(attr)) return;
    const storeKey = `aidigitalOriginal${attr.replace(/(^|-)([a-z])/g, (_, __, letter) => letter.toUpperCase())}`;
    if (!element.dataset[storeKey]) {
      element.dataset[storeKey] = element.getAttribute(attr);
    }
    const original = element.dataset[storeKey];
    const nextValue = areStudentNamesVisible() ? original : maskText(original);
    if (element.getAttribute(attr) !== nextValue) {
      element.setAttribute(attr, nextValue);
    }
  });
}

function maskText(text) {
  if (!text) return text;
  let output = text;

  aliases.forEach((item) => {
    output = output.replaceAll(item.name, item.mask);
  });

  aliases.forEach((item) => {
    if (output.trim() === item.initial) {
      output = output.replace(item.initial, item.shortMask);
    }
  });

  return output;
}

function shouldSkipNode(element) {
  if (!element) return false;
  return Boolean(
    element.closest(
      "script, style, textarea, input, select, option, [data-name-visibility-skip='true']",
    ),
  );
}

from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "travel_planner.sqlite"


def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS itinerary_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trip_day TEXT NOT NULL DEFAULT '',
            start_time TEXT NOT NULL DEFAULT '',
            title TEXT NOT NULL,
            location TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT '',
            transport TEXT NOT NULL DEFAULT '',
            duration_minutes INTEGER NOT NULL DEFAULT 0,
            budget INTEGER NOT NULL DEFAULT 0,
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS gratitude_cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            student_name TEXT NOT NULL,
            recipient TEXT NOT NULL,
            reason TEXT NOT NULL DEFAULT '',
            message TEXT NOT NULL,
            signature TEXT NOT NULL DEFAULT '',
            theme TEXT NOT NULL DEFAULT 'aqua',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS finance_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            day INTEGER NOT NULL DEFAULT 1,
            weekday TEXT NOT NULL DEFAULT '',
            week_label TEXT NOT NULL DEFAULT '',
            money INTEGER NOT NULL DEFAULT 0,
            saved INTEGER NOT NULL DEFAULT 0,
            correct_count INTEGER NOT NULL DEFAULT 0,
            roll INTEGER NOT NULL DEFAULT 0,
            card_type TEXT NOT NULL DEFAULT '',
            card_title TEXT NOT NULL DEFAULT '',
            event_text TEXT NOT NULL DEFAULT '',
            question TEXT NOT NULL DEFAULT '',
            selected_answer TEXT NOT NULL DEFAULT '',
            correct_answer TEXT NOT NULL DEFAULT '',
            is_correct INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS finance_game_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            state_json TEXT NOT NULL DEFAULT '{}',
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS want_need_game_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            state_json TEXT NOT NULL DEFAULT '{}',
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS decimal_intro_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            student_name TEXT NOT NULL,
            prompt TEXT NOT NULL,
            answer TEXT NOT NULL DEFAULT '',
            correct_answer TEXT NOT NULL,
            is_correct INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    ensure_columns(connection)
    connection.commit()
    return connection


def ensure_columns(connection):
    existing_columns = {
        row["name"]
        for row in connection.execute("PRAGMA table_info(itinerary_items)").fetchall()
    }
    migrations = {
        "category": "ALTER TABLE itinerary_items ADD COLUMN category TEXT NOT NULL DEFAULT ''",
        "transport": "ALTER TABLE itinerary_items ADD COLUMN transport TEXT NOT NULL DEFAULT ''",
        "duration_minutes": "ALTER TABLE itinerary_items ADD COLUMN duration_minutes INTEGER NOT NULL DEFAULT 0",
        "budget": "ALTER TABLE itinerary_items ADD COLUMN budget INTEGER NOT NULL DEFAULT 0",
    }

    for column, sql in migrations.items():
        if column not in existing_columns:
            connection.execute(sql)


def row_to_dict(row):
    return {
        "id": row["id"],
        "tripDay": row["trip_day"],
        "startTime": row["start_time"],
        "title": row["title"],
        "location": row["location"],
        "category": row["category"],
        "transport": row["transport"],
        "durationMinutes": row["duration_minutes"],
        "budget": row["budget"],
        "note": row["note"],
        "createdAt": row["created_at"],
    }


def gratitude_row_to_dict(row):
    return {
        "id": row["id"],
        "studentId": row["student_id"],
        "studentName": row["student_name"],
        "recipient": row["recipient"],
        "reason": row["reason"],
        "message": row["message"],
        "signature": row["signature"],
        "theme": row["theme"],
        "createdAt": row["created_at"],
    }


def finance_row_to_dict(row):
    return {
        "id": row["id"],
        "studentName": row["student_name"],
        "day": row["day"],
        "weekday": row["weekday"],
        "weekLabel": row["week_label"],
        "money": row["money"],
        "saved": row["saved"],
        "correctCount": row["correct_count"],
        "roll": row["roll"],
        "cardType": row["card_type"],
        "cardTitle": row["card_title"],
        "eventText": row["event_text"],
        "question": row["question"],
        "selectedAnswer": row["selected_answer"],
        "correctAnswer": row["correct_answer"],
        "isCorrect": bool(row["is_correct"]),
        "createdAt": row["created_at"],
    }


def decimal_intro_row_to_dict(row):
    return {
        "id": row["id"],
        "studentId": row["student_id"],
        "studentName": row["student_name"],
        "prompt": row["prompt"],
        "answer": row["answer"],
        "correctAnswer": row["correct_answer"],
        "isCorrect": bool(row["is_correct"]),
        "createdAt": row["created_at"],
    }


class TravelPlannerHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/travel-items":
            self.handle_list_items()
            return
        if parsed.path == "/api/gratitude-cards":
            self.handle_list_gratitude_cards()
            return
        if parsed.path == "/api/finance-records":
            self.handle_list_finance_records()
            return
        if parsed.path == "/api/finance-state":
            self.handle_get_finance_state()
            return
        if parsed.path == "/api/want-need-state":
            self.handle_get_want_need_state()
            return
        if parsed.path == "/api/decimal-intro-records":
            self.handle_list_decimal_intro_records()
            return

        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/travel-items":
            self.handle_create_item()
            return
        if parsed.path == "/api/gratitude-cards":
            self.handle_create_gratitude_card()
            return
        if parsed.path == "/api/finance-records":
            self.handle_create_finance_record()
            return
        if parsed.path == "/api/finance-state":
            self.handle_save_finance_state()
            return
        if parsed.path == "/api/want-need-state":
            self.handle_save_want_need_state()
            return
        if parsed.path == "/api/decimal-intro-records":
            self.handle_create_decimal_intro_record()
            return

        self.send_json({"error": "Not found"}, status=404)

    def do_DELETE(self):
        parsed = urlparse(self.path)
        prefix = "/api/travel-items/"
        if parsed.path.startswith(prefix):
            item_id = parsed.path.removeprefix(prefix)
            self.handle_delete_item(item_id)
            return

        card_prefix = "/api/gratitude-cards/"
        if parsed.path.startswith(card_prefix):
            card_id = parsed.path.removeprefix(card_prefix)
            self.handle_delete_gratitude_card(card_id)
            return

        finance_prefix = "/api/finance-records/"
        if parsed.path.startswith(finance_prefix):
            record_id = parsed.path.removeprefix(finance_prefix)
            self.handle_delete_finance_record(record_id)
            return

        if parsed.path == "/api/decimal-intro-records":
            self.handle_clear_decimal_intro_records()
            return

        self.send_json({"error": "Not found"}, status=404)

    def handle_list_items(self):
        with get_connection() as connection:
            rows = connection.execute(
                """
                SELECT
                    id, trip_day, start_time, title, location, category,
                    transport, duration_minutes, budget, note, created_at
                FROM itinerary_items
                ORDER BY
                    CASE WHEN trip_day = '' THEN 1 ELSE 0 END,
                    trip_day,
                    CASE WHEN start_time = '' THEN 1 ELSE 0 END,
                    start_time,
                    id
                """
            ).fetchall()

        self.send_json({"items": [row_to_dict(row) for row in rows]})

    def handle_create_item(self):
        try:
            payload = self.read_json()
        except ValueError:
            self.send_json({"error": "Invalid JSON"}, status=400)
            return

        title = str(payload.get("title", "")).strip()
        if not title:
            self.send_json({"error": "行程名稱必填"}, status=400)
            return

        values = {
            "trip_day": str(payload.get("tripDay", "")).strip(),
            "start_time": str(payload.get("startTime", "")).strip(),
            "title": title,
            "location": str(payload.get("location", "")).strip(),
            "category": str(payload.get("category", "")).strip(),
            "transport": str(payload.get("transport", "")).strip(),
            "duration_minutes": parse_non_negative_int(payload.get("durationMinutes", 0)),
            "budget": parse_non_negative_int(payload.get("budget", 0)),
            "note": str(payload.get("note", "")).strip(),
        }

        with get_connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO itinerary_items (
                    trip_day, start_time, title, location, category,
                    transport, duration_minutes, budget, note
                )
                VALUES (
                    :trip_day, :start_time, :title, :location, :category,
                    :transport, :duration_minutes, :budget, :note
                )
                """,
                values,
            )
            row = connection.execute(
                """
                SELECT
                    id, trip_day, start_time, title, location, category,
                    transport, duration_minutes, budget, note, created_at
                FROM itinerary_items
                WHERE id = ?
                """,
                (cursor.lastrowid,),
            ).fetchone()

        self.send_json({"item": row_to_dict(row)}, status=201)

    def handle_delete_item(self, item_id):
        try:
            parsed_id = int(item_id)
        except ValueError:
            self.send_json({"error": "Invalid id"}, status=400)
            return

        with get_connection() as connection:
            cursor = connection.execute("DELETE FROM itinerary_items WHERE id = ?", (parsed_id,))

        if cursor.rowcount == 0:
            self.send_json({"error": "Not found"}, status=404)
            return

        self.send_json({"ok": True})

    def handle_list_gratitude_cards(self):
        with get_connection() as connection:
            rows = connection.execute(
                """
                SELECT
                    id, student_id, student_name, recipient, reason,
                    message, signature, theme, created_at
                FROM gratitude_cards
                ORDER BY id DESC
                """
            ).fetchall()

        self.send_json({"cards": [gratitude_row_to_dict(row) for row in rows]})

    def handle_create_gratitude_card(self):
        try:
            payload = self.read_json()
        except ValueError:
            self.send_json({"error": "Invalid JSON"}, status=400)
            return

        student_name = str(payload.get("studentName", "")).strip()
        recipient = str(payload.get("recipient", "")).strip()
        message = str(payload.get("message", "")).strip()

        if not student_name or not recipient or not message:
            self.send_json({"error": "請完成姓名、收件人和卡片內容"}, status=400)
            return

        values = {
            "student_id": str(payload.get("studentId", "")).strip(),
            "student_name": student_name,
            "recipient": recipient,
            "reason": str(payload.get("reason", "")).strip(),
            "message": message,
            "signature": str(payload.get("signature", "")).strip(),
            "theme": str(payload.get("theme", "aqua")).strip() or "aqua",
        }

        with get_connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO gratitude_cards (
                    student_id, student_name, recipient, reason,
                    message, signature, theme
                )
                VALUES (
                    :student_id, :student_name, :recipient, :reason,
                    :message, :signature, :theme
                )
                """,
                values,
            )
            row = connection.execute(
                """
                SELECT
                    id, student_id, student_name, recipient, reason,
                    message, signature, theme, created_at
                FROM gratitude_cards
                WHERE id = ?
                """,
                (cursor.lastrowid,),
            ).fetchone()

        self.send_json({"card": gratitude_row_to_dict(row)}, status=201)

    def handle_delete_gratitude_card(self, card_id):
        try:
            parsed_id = int(card_id)
        except ValueError:
            self.send_json({"error": "Invalid id"}, status=400)
            return

        with get_connection() as connection:
            cursor = connection.execute("DELETE FROM gratitude_cards WHERE id = ?", (parsed_id,))

        if cursor.rowcount == 0:
            self.send_json({"error": "Not found"}, status=404)
            return

        self.send_json({"ok": True})

    def handle_list_finance_records(self):
        with get_connection() as connection:
            rows = connection.execute(
                """
                SELECT
                    id, student_name, day, weekday, week_label, money, saved,
                    correct_count, roll, card_type, card_title, event_text,
                    question, selected_answer, correct_answer, is_correct, created_at
                FROM finance_records
                ORDER BY id DESC
                LIMIT 80
                """
            ).fetchall()

        self.send_json({"records": [finance_row_to_dict(row) for row in rows]})

    def handle_create_finance_record(self):
        try:
            payload = self.read_json()
        except ValueError:
            self.send_json({"error": "Invalid JSON"}, status=400)
            return

        student_name = str(payload.get("studentName", "")).strip()
        question = str(payload.get("question", "")).strip()
        if not student_name or not question:
            self.send_json({"error": "學生與題目必填"}, status=400)
            return

        values = {
            "student_name": student_name,
            "day": parse_non_negative_int(payload.get("day", 1)) or 1,
            "weekday": str(payload.get("weekday", "")).strip(),
            "week_label": str(payload.get("weekLabel", "")).strip(),
            "money": parse_int(payload.get("money", 0)),
            "saved": parse_non_negative_int(payload.get("saved", 0)),
            "correct_count": parse_non_negative_int(payload.get("correctCount", 0)),
            "roll": parse_non_negative_int(payload.get("roll", 0)),
            "card_type": str(payload.get("cardType", "")).strip(),
            "card_title": str(payload.get("cardTitle", "")).strip(),
            "event_text": str(payload.get("eventText", "")).strip(),
            "question": question,
            "selected_answer": str(payload.get("selectedAnswer", "")).strip(),
            "correct_answer": str(payload.get("correctAnswer", "")).strip(),
            "is_correct": 1 if payload.get("isCorrect") else 0,
        }

        with get_connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO finance_records (
                    student_name, day, weekday, week_label, money, saved,
                    correct_count, roll, card_type, card_title, event_text,
                    question, selected_answer, correct_answer, is_correct
                )
                VALUES (
                    :student_name, :day, :weekday, :week_label, :money, :saved,
                    :correct_count, :roll, :card_type, :card_title, :event_text,
                    :question, :selected_answer, :correct_answer, :is_correct
                )
                """,
                values,
            )
            row = connection.execute(
                """
                SELECT
                    id, student_name, day, weekday, week_label, money, saved,
                    correct_count, roll, card_type, card_title, event_text,
                    question, selected_answer, correct_answer, is_correct, created_at
                FROM finance_records
                WHERE id = ?
                """,
                (cursor.lastrowid,),
            ).fetchone()

        self.send_json({"record": finance_row_to_dict(row)}, status=201)

    def handle_delete_finance_record(self, record_id):
        try:
            parsed_id = int(record_id)
        except ValueError:
            self.send_json({"error": "Invalid id"}, status=400)
            return

        with get_connection() as connection:
            cursor = connection.execute("DELETE FROM finance_records WHERE id = ?", (parsed_id,))

        if cursor.rowcount == 0:
            self.send_json({"error": "Not found"}, status=404)
            return

        self.send_json({"ok": True})

    def handle_get_finance_state(self):
        with get_connection() as connection:
            row = connection.execute(
                """
                SELECT state_json, updated_at
                FROM finance_game_state
                WHERE id = 1
                """
            ).fetchone()

        if not row:
            self.send_json({"state": None, "updatedAt": ""})
            return

        try:
            state = json.loads(row["state_json"])
        except json.JSONDecodeError:
            state = None

        self.send_json({"state": state, "updatedAt": row["updated_at"]})

    def handle_save_finance_state(self):
        try:
            payload = self.read_json()
        except ValueError:
            self.send_json({"error": "Invalid JSON"}, status=400)
            return

        state = payload.get("state")
        if not isinstance(state, dict):
            self.send_json({"error": "Invalid state"}, status=400)
            return

        state_json = json.dumps(state, ensure_ascii=False)
        with get_connection() as connection:
            connection.execute(
                """
                INSERT INTO finance_game_state (id, state_json, updated_at)
                VALUES (1, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    state_json = excluded.state_json,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (state_json,),
            )
            row = connection.execute(
                """
                SELECT state_json, updated_at
                FROM finance_game_state
                WHERE id = 1
                """
            ).fetchone()

        self.send_json({"state": json.loads(row["state_json"]), "updatedAt": row["updated_at"]})

    def handle_get_want_need_state(self):
        with get_connection() as connection:
            row = connection.execute(
                """
                SELECT state_json, updated_at
                FROM want_need_game_state
                WHERE id = 1
                """
            ).fetchone()

        if not row:
            self.send_json({"state": None, "updatedAt": ""})
            return

        try:
            state = json.loads(row["state_json"])
        except json.JSONDecodeError:
            state = None

        self.send_json({"state": state, "updatedAt": row["updated_at"]})

    def handle_save_want_need_state(self):
        try:
            payload = self.read_json()
        except ValueError:
            self.send_json({"error": "Invalid JSON"}, status=400)
            return

        state = payload.get("state")
        if not isinstance(state, dict):
            self.send_json({"error": "Invalid state"}, status=400)
            return

        state_json = json.dumps(state, ensure_ascii=False)
        with get_connection() as connection:
            connection.execute(
                """
                INSERT INTO want_need_game_state (id, state_json, updated_at)
                VALUES (1, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    state_json = excluded.state_json,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (state_json,),
            )
            row = connection.execute(
                """
                SELECT state_json, updated_at
                FROM want_need_game_state
                WHERE id = 1
                """
            ).fetchone()

        self.send_json({"state": json.loads(row["state_json"]), "updatedAt": row["updated_at"]})

    def handle_list_decimal_intro_records(self):
        with get_connection() as connection:
            rows = connection.execute(
                """
                SELECT
                    id, student_id, student_name, prompt, answer,
                    correct_answer, is_correct, created_at
                FROM decimal_intro_records
                ORDER BY id DESC
                LIMIT 240
                """
            ).fetchall()

        self.send_json({"records": [decimal_intro_row_to_dict(row) for row in rows]})

    def handle_create_decimal_intro_record(self):
        try:
            payload = self.read_json()
        except ValueError:
            self.send_json({"error": "Invalid JSON"}, status=400)
            return

        student_id = str(payload.get("studentId", "")).strip()
        student_name = str(payload.get("studentName", "")).strip()
        prompt = str(payload.get("prompt", "")).strip()
        correct_answer = str(payload.get("correctAnswer", "")).strip()

        if not student_id or not student_name or not prompt or not correct_answer:
            self.send_json({"error": "學生、題目與答案必填"}, status=400)
            return

        values = {
            "student_id": student_id,
            "student_name": student_name,
            "prompt": prompt,
            "answer": str(payload.get("answer", "")).strip(),
            "correct_answer": correct_answer,
            "is_correct": 1 if payload.get("isCorrect") else 0,
        }

        with get_connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO decimal_intro_records (
                    student_id, student_name, prompt, answer,
                    correct_answer, is_correct
                )
                VALUES (
                    :student_id, :student_name, :prompt, :answer,
                    :correct_answer, :is_correct
                )
                """,
                values,
            )
            row = connection.execute(
                """
                SELECT
                    id, student_id, student_name, prompt, answer,
                    correct_answer, is_correct, created_at
                FROM decimal_intro_records
                WHERE id = ?
                """,
                (cursor.lastrowid,),
            ).fetchone()

        self.send_json({"record": decimal_intro_row_to_dict(row)}, status=201)

    def handle_clear_decimal_intro_records(self):
        with get_connection() as connection:
            connection.execute("DELETE FROM decimal_intro_records")

        self.send_json({"ok": True})

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(length).decode("utf-8")
        return json.loads(raw_body or "{}")

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def parse_non_negative_int(value):
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def parse_int(value):
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


if __name__ == "__main__":
    get_connection().close()
    server = ThreadingHTTPServer(("0.0.0.0", 4174), TravelPlannerHandler)
    print("Serving AiDigital with SQLite travel planner on http://0.0.0.0:4174/")
    server.serve_forever()
